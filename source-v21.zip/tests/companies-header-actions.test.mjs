import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const source = readFileSync(new URL('../src/components/Companies.tsx', import.meta.url), 'utf8');

test('Companies does not expose a bulk-actions button, menu or dialog', () => {
  assert.doesNotMatch(source, /Bulk actions|bulkActionsOpen|availableBulkActions|selectedBulkAction|AccountantMultiSelect/);
});

test('Companies retains creation, filtering, selection and existing accountant information', () => {
  for (const marker of ['<PageHeader', '<PageActionButton', 'canCreateOrganization', 'selectedCompanyIds', 'allCompaniesSelected', 'assignedAccountantFilter', 'organizationAccountantNames', 'selectCompanySubstitutions', 'useOrganizationAccessRevision();']) {
    assert.ok(source.includes(marker), `Missing preserved functionality: ${marker}`);
  }
  assert.doesNotMatch(source, /addAccountantToOrganizations|replaceAccountantInOrganizations|setOrganizationSubstitution/);
});
