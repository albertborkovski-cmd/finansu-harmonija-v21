import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const api = {};
new Function('exports', ts.transpileModule(readFileSync(new URL('../src/lib/documentResponsibleUsers.ts', import.meta.url), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(api);
const users = [
  { id: 'one', fullName: 'Same name', email: 'first@example.test', status: 'Active' },
  { id: 'two', fullName: 'Same name', email: 'second@example.test', status: 'Enabled' },
  { id: 'three', fullName: 'Unique name', email: 'third@example.test', status: 'Active' },
  { id: 'blocked', fullName: 'Blocked user', status: 'Blocked' },
  { id: 'inactive', fullName: 'Inactive user', status: 'Inactive' },
];
test('options show active internal users, distinguish equal names and offer unassignment', () => {
  const options = api.documentResponsibleOptions(users);
  assert.deepEqual(options.map(option => option.value), ['', 'one', 'two', 'three']);
  assert.equal(options[1].label, 'Same name');
  assert.equal(options[1].description, 'first@example.test');
  assert.equal(options[2].description, 'second@example.test');
  assert.equal(options[3].label, 'Unique name');
  assert.deepEqual(api.documentResponsibleOptions([]), [{ value: '', label: '—' }]);
});
test('legacy values stay readable without guessing ambiguous identities; IDs survive user renames', () => {
  assert.equal(api.documentResponsibleSelection({ accountable_responsible: 'Same name' }, users), 'Same name');
  assert.equal(api.documentResponsibleSelection({ accountable_responsible: 'Unique name' }, users), 'three');
  assert.equal(api.documentResponsibleSelection({ accountable_responsible: 'Old name', accountable_responsible_id: 'three' }, users), 'three');
  assert.equal(api.documentResponsibleSelection({ accountable_responsible: 'Legacy name' }, users), 'Legacy name');
});
test('saving resolves the fresh directory record; unknown, blocked and unactivated users are rejected', () => {
  assert.deepEqual(api.documentResponsiblePatch('two', users), { accountable_responsible: 'Same name', accountable_responsible_id: 'two' });
  for (const id of ['unknown', 'blocked', 'inactive']) assert.throws(() => api.documentResponsiblePatch(id, users), /Internal Users/);
  assert.throws(() => api.documentResponsiblePatch('one', [{ ...users[0], status: 'Unactivated' }]), /active user/);
});
