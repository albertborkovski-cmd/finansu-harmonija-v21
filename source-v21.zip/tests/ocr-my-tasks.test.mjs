import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
function load(path, require = () => { throw Error('Unexpected import'); }) {
  const exports = {};
  new Function('exports', 'require', ts.transpileModule(source(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(exports, require);
  return exports;
}
const lifecycle = load('../src/lib/recordLifecycle.ts');
const { myOcrTasks, assignedOcrDocumentIds, requireAssignedOcrTask } = load('../src/lib/ocrMyTasks.ts', name => name === './recordLifecycle' ? lifecycle : {});
const issues = load('../src/lib/documentIssues.ts');
const access = load('../src/lib/accessControl.ts', () => lifecycle);
const companyNames = new Map([['c1', 'Company 1']]);
const me = 'worker@example.test';
const document = extra => ({ id: 'd1', company_id: 'c1', number: 'INV-1', file_case: 'INV-1.pdf', status: 'Draft', ...extra });
const work = { d1: { email: me, user: 'Worker', seconds: 30, updatedAt: '2026-11-04T10:00:00Z' } };
const allAccess = { documents: true, issues: true };
const list = (documents, tasks = new Map(), log = work, rights = allAccess, email = me) => myOcrTasks(documents, companyNames, email, tasks, log, rights);

test('My tasks includes actual OCR work and explicit assignments using email identity only', () => {
  assert.equal(list([document()]).length, 1);
  const task = { status: 'In Progress', assignedToEmail: ' WORKER@example.test ', assignedToName: 'Worker', assignedAt: '2026-11-04T09:00:00Z' };
  const assigned = list([document()], new Map([['d1', task]]), {});
  assert.equal(assigned.length, 1);
  assert.equal(assigned[0].cells.assignedAt, task.assignedAt);
  assert.equal(list([document()], new Map(), { d1: { ...work.d1, email: '', user: 'Worker' } }).length, 0);
  assert.equal(list([document({ created_by: 'Worker', accountable_responsible: 'Worker' })], new Map(), {}).length, 0);
  assert.equal(list([document()], new Map([['d1', { ...task, assignedToEmail: 'other@example.test' }]])).length, 0);
  assert.equal(list([document()], new Map(), work, allAccess, '').length, 0);
});

test('completed, confirmed, inactive, other-company and unauthorized work cannot leak into current tasks', () => {
  for (const status of ['Accepted', 'Approved', 'Completed', 'Transferred', 'Posted', 'Cancelled', 'Inactive']) assert.equal(list([document({ status })]).length, 0, status);
  assert.equal(list([document({ inactive: true })]).length, 0);
  assert.equal(list([document({ company_id: 'other-company' })]).length, 0);
  assert.equal(list([document()], new Map([['d1', { status: 'Completed' }]])).length, 0);
  assert.equal(list([document()], new Map([['d1', { status: 'In Progress', trainingStatus: 'Confirmed' }]])).length, 0);
  assert.equal(list([document()], new Map(), work, { documents: false, issues: false }).length, 0);
});

test('starting an issue assigns it to the current worker, preserves history and cannot steal another assignment', () => {
  const reported = issues.transitionDocumentIssue(document(), { type: 'report', message: 'Wrong supplier' }, 'Accountant');
  const id = reported.digitization_issues[0].id;
  const taken = issues.transitionDocumentIssue(reported, { type: 'start', issueId: id }, 'Worker', me);
  assert.equal(taken.digitization_issues[0].assignedToEmail, me);
  assert.equal(taken.digitization_issues[0].assignedToName, 'Worker');
  assert.ok(taken.digitization_issues[0].assignedAt);
  assert.equal(taken.digitization_issues[0].events.length, 2);
  assert.equal(issues.transitionDocumentIssue(taken, { type: 'start', issueId: id }, 'Worker', me), taken);
  assert.throws(() => issues.transitionDocumentIssue(taken, { type: 'start', issueId: id }, 'Other', 'other@example.test'), /another worker/);
  assert.equal(reported.digitization_issues[0].assignedToEmail, undefined);
  assert.equal(list([reported], new Map(), {}).length, 0);
  assert.equal(list([taken], new Map(), {})[0].kind, 'Document issue');
  assert.equal(list([taken], new Map(), {}, allAccess, 'other@example.test').length, 0);
  const fixed = issues.transitionDocumentIssue(taken, { type: 'resolve', issueId: id, note: 'Supplier corrected' }, 'Worker');
  assert.equal(list([fixed], new Map(), {}).length, 1);
  assert.equal(list([fixed], new Map(), {})[0].cells.status, 'Awaiting OCR');
  assert.equal(fixed.digitization_issues[0].assignedToEmail, me);
});

test('legacy in-progress issues acquire identity when explicitly taken, never through display-name inference', () => {
  const reported = issues.transitionDocumentIssue(document(), { type: 'report', message: 'Check details' }, 'Accountant');
  const id = reported.digitization_issues[0].id;
  const legacy = issues.transitionDocumentIssue(reported, { type: 'start', issueId: id }, 'Worker');
  assert.equal(list([legacy], new Map(), {}).length, 0);
  const claimed = issues.transitionDocumentIssue(legacy, { type: 'start', issueId: id }, 'Worker', me);
  assert.equal(list([claimed], new Map(), {}).length, 1);
});

test('My tasks is a Workspace submenu, inherits existing workspace rights and retains explicit restrictions', () => {
  const rights = { view: true, edit: false };
  assert.deepEqual(access.migrateDocumentIssueMenuKey({ 'ocr-workspace': rights })['ocr-workspace-my-tasks'], rights);
  const restricted = { 'ocr-workspace': rights, 'ocr-workspace-my-tasks': { view: false, edit: false } };
  assert.deepEqual(access.migrateDocumentIssueMenuKey(restricted), restricted);
  assert.match(source('../src/components/Sidebar.tsx'), /id: "ocr-workspace-my-tasks", label: "My tasks"/);
  assert.match(source('../src/components/Dashboard.tsx'), /activeMenu === "ocr-workspace-my-tasks"/);
  const page = source('../src/components/OcrMyTasksView.tsx');
  assert.match(page, /canAccessAssignedOrganization\(company, session\)/);
  assert.match(page, /requireAssignedOcrTask\(await load\(\), document\)/);
  assert.match(page, /reportedIssueId=\{editing.issue.id\}/);
  for (const component of ['ProcessedDocumentsTable', 'WorkspaceDocumentEditor', 'DocumentDetailPanel']) assert.match(page, new RegExp('<' + component + '\\b'));
  assert.doesNotMatch(page, /const COLUMNS|<div role="table"|onOpenCompanyDocuments/);
  assert.match(page, /onIssueFixed=\{close\}/);
});

test('My tasks uses the same Workspace table, controls and multi-file editor', () => {
  const workspace = source('../src/components/WorkspaceView.tsx');
  const page = source('../src/components/OcrMyTasksView.tsx');
  for (const code of [workspace, page]) {
    assert.match(code, /<ProcessedDocumentsTable/);
    assert.match(code, /embedded\s+showAllDocuments\s+selectable/);
    assert.match(code, /importActionContainer=\{workspaceHeaderActions\}/);
    assert.match(code, /selectionActionVariant="run"/);
    assert.match(code, /onEditDocument=/);
    assert.match(code, /onRunDocument=/);
    assert.match(code, /onImportDocuments=/);
    assert.match(code, /filePosition=\{documentIndex \+ 1\}/);
    assert.match(code, /fileTotal=\{documentQueue.length\}/);
    assert.match(code, /onNextFile=\{hasNextFile \?/);
  }
  assert.match(page, /documentIds=\{documentIds\}/);
  const table = source('../src/components/OcrProcessedDocumentsView.tsx');
  assert.match(table, /\.filter\(\(document\) => !documentIds \|\| documentIds.has\(document.id\)\)/);
  assert.match(table, /<OcrDocumentsWorkspace/);
  for (const component of ['SystemAddFilters', 'ColumnSettingsPanel', 'HorizontalTableScrollbar', 'TablePagination']) assert.match(table, new RegExp('<' + component + '\\b'));
});

test('Workspace task scoping deduplicates documents and rechecks exact identity and current ownership', () => {
  const reported = issues.transitionDocumentIssue(document(), { type: 'report', message: 'Wrong supplier' }, 'Accountant');
  const issueId = reported.digitization_issues[0].id;
  const taken = issues.transitionDocumentIssue(reported, { type: 'start', issueId }, 'Worker', me);
  const tasks = list([taken]);
  assert.equal(tasks.length, 2);
  assert.deepEqual([...assignedOcrDocumentIds(tasks)], ['d1']);
  assert.equal(requireAssignedOcrTask(tasks, { id: 'd1', companyId: 'c1' }).issue.id, issueId);
  assert.throws(() => requireAssignedOcrTask(tasks, { id: 'd1', companyId: 'other' }), /no longer accessible/);
  assert.throws(() => requireAssignedOcrTask(tasks, { id: 'other', companyId: 'c1' }), /no longer accessible/);
  assert.throws(() => requireAssignedOcrTask([], { id: 'd1', companyId: 'c1' }), /no longer accessible/);
  assert.equal(assignedOcrDocumentIds([]).size, 0);
});
