import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = name => readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');
const compile = name => ts.transpileModule(read(name), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const record = (code, fullName = code, status = 'Active') => ({ code, fullName, status, description: '', country: '', parentCode: '' });
function fixture() {
  const store = new Map(), types = {}, statuses = {}, reference = {}, invoice = {}, inline = {}, detail = {}, issues = {};
  const window = { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) } };
  for (const [name, exports] of [['invoiceLineTypes', types], ['documentProcessingStatus', statuses], ['generalReferenceCatalogs', reference], ['documentInlineEditing', inline], ['documentIssues', issues]])
    new Function('exports', 'window', compile(`lib/${name}.ts`))(exports, window);
  const require = name => {
    if (name === './invoiceLineTypes') return types;
    if (name === './documentProcessingStatus') return statuses;
    if (name === './documentInlineEditing') return inline;
    throw Error(name);
  };
  new Function('exports', 'window', 'require', compile('lib/invoiceCreation.ts'))(invoice, window, require);
  new Function('exports', 'require', compile('lib/documentDetailEditing.ts'))(detail, require);
  const put = (section, rows) => window.localStorage.setItem(`finansu-harmonija:organization-reference:${section}`, JSON.stringify(rows));
  return { store, types, statuses, reference, invoice, inline, detail, issues, put };
}

test('Type and Status are separate General settings menus with existing system list and forms', () => {
  for (const file of ['components/Sidebar.tsx', 'lib/accessControl.ts']) {
    const source = read(file);
    assert.match(source, /settings-organizations-type["'], label: ["']Type/);
    assert.match(source, /settings-organizations-document-status["'], label: ["']Status/);
  }
  const source = read('components/OrganizationReferenceValuesView.tsx');
  assert.match(source, /if \(section === 'Type'\) return loadInvoiceLineTypeCatalog/);
  assert.match(source, /if \(section === 'Document Status'\) return loadDocumentStatusCatalog/);
  assert.match(source, /prepareGeneralReferenceSave\(loadOrganizationReferenceRecords\(section\), draft, originalDraft.current\)/);
  assert.match(source, /useState<Set<string>>/);
});

test('create and rename persist stable Type codes and dropdown labels while retaining legacy company choices', () => {
  const f = fixture(), original = f.types.loadInvoiceLineTypeCatalog(), before = structuredClone(original);
  let next = f.reference.prepareGeneralReferenceSave(original, record('FEE', 'Delivery fee'), null);
  f.put('Type', next);
  assert.deepEqual(f.types.invoiceLineTypeOptions('a', []).at(-1), { value: 'FEE', label: 'Delivery fee' });
  const saved = f.types.loadInvoiceLineTypeCatalog().at(-1);
  next = f.reference.prepareGeneralReferenceSave(f.types.loadInvoiceLineTypeCatalog(), { ...saved, fullName: 'Shipping fee' }, saved);
  f.put('Type', next);
  assert.deepEqual(f.types.invoiceLineTypeOptions('a', []).at(-1), { value: 'FEE', label: 'Shipping fee' });
  assert.equal(f.types.prepareInvoiceLineType('a', 'Shipping fee', []).value, 'FEE');
  assert.deepEqual(original, before);
  const legacy = [{ type: f.types.invoiceLineTypeScope('a'), value: 'Private legacy type' }];
  assert.ok(f.types.invoiceLineTypeValues('a', legacy).includes('Private legacy type'));
  assert.ok(!f.types.invoiceLineTypeValues('b', legacy).includes('Private legacy type'));
});

test('inactive types are omitted, cannot be recreated through +, and reappear after activation', () => {
  const f = fixture();
  f.put('Type', [record('Service', 'Service', 'Inactive'), record('Product'), record('Code'), record('FEE', 'Fee', 'Inactive')]);
  assert.deepEqual(f.types.invoiceLineTypeValues('a', [{ type: f.types.invoiceLineTypeScope('a'), value: 'FEE' }]), ['Product', 'Code']);
  assert.throws(() => f.types.prepareInvoiceLineType('a', 'Fee', []), /inactive/);
  assert.equal(f.invoice.newInvoiceLine().type, 'Product');
  f.put('Type', [record('FEE', 'Fee')]);
  assert.deepEqual(f.types.invoiceLineTypeOptions('a', []), [{ value: 'FEE', label: 'Fee' }]);
});

test('duplicate, empty, invalid and stale catalog edits are rejected without mutating data', () => {
  const f = fixture(), rows = [record('Service'), record('Product')], before = structuredClone(rows);
  for (const draft of [record('', 'Empty'), record('service', 'Other'), record('OTHER', ' product '), record('BAD\nCODE'), record('x'.repeat(81))])
    assert.throws(() => f.reference.prepareGeneralReferenceSave(rows, draft, null));
  assert.throws(() => f.reference.prepareGeneralReferenceSave(rows, { ...rows[0], code: 'NEW' }, rows[0]), /cannot be changed/);
  assert.throws(() => f.reference.prepareGeneralReferenceSave([{ ...rows[0], fullName: 'Changed' }, rows[1]], { ...rows[0], fullName: 'New label' }, rows[0]), /has changed/);
  assert.deepEqual(rows, before);
});

test('status migration preserves legacy edits and custom rows while adding missing workflow values', () => {
  const f = fixture(); f.put('Document Status', [record('PROCESSING', 'Being processed', 'Inactive'), record('CHECK', 'Needs checking')]);
  const records = f.statuses.loadDocumentStatusCatalog();
  assert.equal(records.find(row => row.code === 'PROCESSING').fullName, 'Being processed');
  assert.equal(f.statuses.documentStatusLabel('Processing'), 'Being processed');
  assert.ok(!f.statuses.documentStatusOptions().some(option => option.value === 'Processing'));
  assert.ok(f.statuses.documentStatusOptions().some(option => option.value === 'Draft'));
  assert.ok(f.statuses.documentStatusOptions().some(option => option.value === 'custom:CHECK'));
  assert.equal(records.filter(row => row.code === 'PROCESSING').length, 1);
});

test('status names are presentation only: renaming Approved cannot remove its workflow meaning', () => {
  const f = fixture(); f.put('Document Status', [record('APPROVED', 'Verified'), record('CUSTOM', 'Approved')]);
  assert.equal(f.statuses.documentStatusLabel('Approved'), 'Verified');
  assert.ok(f.issues.isApprovedDocumentStatus('Approved'));
  assert.ok(!f.issues.isApprovedDocumentStatus('custom:CUSTOM'));
  assert.ok(!f.statuses.initialInvoiceStatusOptions().some(option => option.value === 'Approved'));
  assert.ok(f.statuses.initialInvoiceStatusOptions().some(option => option.value === 'custom:CUSTOM'));
  assert.match(f.inline.documentEditStateError({ id: 'a', status: 'Approved' }), /confirmed/);
  assert.equal(f.inline.documentEditStateError({ id: 'a', status: 'custom:CUSTOM' }), '');
  assert.match(f.inline.documentEditStateError({ id: 'a', status: 'custom:CUSTOM', accounting_posting: {} }), /Confirmed/);
});

test('a configured custom status saves into invoices and edits, and fresh deactivation prevents a new assignment', () => {
  const f = fixture(); f.put('Document Status', [record('WAITING', 'Waiting for review')]);
  const draft = { ...f.invoice.newInvoiceDraft('2026-11-04'), status: 'custom:WAITING', number: 'TEST-001', counterpartyId: 'party', lines: [{ ...f.invoice.newInvoiceLine('line'), description: 'Service', quantity: '1', price: '20', glAccount: '6300', vatClassifier: 'PVM1' }] };
  const context = { company: { id: 'a', base_currency: 'EUR' }, counterparty: { id: 'party', name: 'Test supplier' }, invoiceTypes: [{ code: 'INVOICES', fullName: 'Invoices', parentCode: '', status: 'Active' }, { code: 'INVOICE', fullName: 'Invoice', parentCode: 'INVOICES', status: 'Active' }], allowed: true, actor: 'Test', now: '2026-11-04T10:00:00Z', responsible: { accountable_responsible: '', accountable_responsible_id: '' } };
  const saved = f.invoice.prepareInvoiceDocument({ requestId: 'test-0001', draft, attachments: [] }, context);
  assert.equal(saved.status, 'custom:WAITING'); assert.equal(saved.accounting_posting, undefined);
  const document = { id: 'a', status: 'Draft' };
  assert.doesNotThrow(() => f.detail.validateDocumentDetailEdit(document, { status: 'custom:WAITING' }, f.detail.documentDetailSnapshot(document), true));
  f.put('Document Status', [record('WAITING', 'Waiting for review', 'Inactive')]);
  assert.equal(f.statuses.documentStatusLabel(saved.status), 'Waiting for review');
  assert.throws(() => f.invoice.prepareInvoiceDocument({ requestId: 'test-0002', draft, attachments: [] }, context), /valid initial/);
  assert.throws(() => f.detail.validateDocumentDetailEdit(document, { status: 'custom:WAITING' }, f.detail.documentDetailSnapshot(document), true), /valid document status/);
});

test('malformed catalogs fail closed and cannot be overwritten by settings saves', () => {
  const f = fixture();
  for (const section of ['Type', 'Document Status']) {
    const key = `finansu-harmonija:organization-reference:${section}`;
    f.store.set(key, '{broken');
    assert.throws(() => f.reference.assertGeneralReferenceStorageReadable(key), /could not be read/);
    assert.equal(f.store.get(key), '{broken');
  }
  assert.deepEqual(f.types.invoiceLineTypeValues('a', []), []);
  assert.deepEqual(f.statuses.documentStatusOptions(), []);
});
