import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(source(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {};
new Function('exports', compile('../src/lib/documentStorno.ts'))(core);
const { createDocumentStorno: reverse, documentStornoBlocker: blocked, guardPostedDocumentMutation: guard, documentPostingRows: rows, stornoPeriodError } = core;
const fixture = () => ({ id: 'doc-1', company_id: 'company-1', number: 'INV-701', status: 'Approved', currency: 'USD', total_amount: '121.00',
  accounting_posting: { id: 'posting-701', number: 'GL-701', companyId: 'company-1', documentId: 'doc-1', date: '2026-10-15', status: 'Posted', postedAt: '2026-10-15T10:00:00Z', postedBy: 'Original accountant', baseCurrency: 'EUR',
    integration: { destination: 'Local', status: 'Not sent' },
    lines: [
      { id: 'l1', account: '6000', accountName: 'Purchases', currency: 'USD', debitMinor: 10000, creditMinor: 0, baseDebitMinor: 9000, baseCreditMinor: 0, counterparty: 'Supplier', department: 'D1', costCenter: 'C1', object: 'Project 1' },
      { id: 'l2', account: '2441', accountName: 'Input VAT', currency: 'USD', debitMinor: 2100, creditMinor: 0, baseDebitMinor: 1890, baseCreditMinor: 0 },
      { id: 'l3', account: '4430', accountName: 'Trade payables', currency: 'USD', debitMinor: 0, creditMinor: 12100, baseDebitMinor: 0, baseCreditMinor: 10890 },
    ],
  },
});
const context = () => ({ allowed: true, actor: 'Reversing accountant', today: '2026-11-03', now: '2026-11-03T14:00:00Z', period: { enabled: true, cutoffDay: 25 } });
const command = doc => ({ expectedPosting: JSON.stringify(doc.accounting_posting), date: '2026-11-03', reason: 'Document booked twice.' });
const testCommand = doc => ({ expectedDocument: core.testStornoDocumentSnapshot(doc), date: '2026-11-03', reason: 'Test reversal.' });

test('test Storno needs no GL posting and keeps signed document amounts, company, reason and history after reload', () => {
  const original = { ...fixture(), accounting_posting: undefined, document_date: '2026-10-15', total_amount: '200.00', amount_without_vat: '165.29', vat: '34.71' };
  const before = structuredClone(original);
  const next = core.createTestDocumentStorno(original, testCommand(original), context());
  assert.deepEqual(original, before);
  assert.equal(next.accounting_posting, undefined); assert.equal(next.accounting_storno, undefined);
  assert.equal(next.total_amount, '200.00'); assert.equal(next.status, 'Approved');
  assert.equal(next.document_storno.mode, 'test'); assert.equal(next.document_storno.status, 'Reversed');
  assert.equal(next.document_storno.documentId, original.id); assert.equal(next.document_storno.companyId, original.company_id);
  assert.equal(next.document_storno.date, testCommand(original).date); assert.equal(next.document_storno.reason, 'Test reversal.');
  assert.equal(next.document_storno.history[0].actor, context().actor);
  assert.equal(next.document_storno.lines, undefined); assert.equal(next.document_storno.originalOperationId, undefined);
  assert.match(next.document_storno.history[0].details, /no GL entries created or changed/);
  assert.equal(core.savedTestDocumentStornoError(next), '');
  const reloaded = JSON.parse(JSON.stringify(next));
  assert.equal(core.documentStornoPresentation(reloaded).status, 'Reversed');
  assert.deepEqual(core.documentStornoPresentation(reloaded).amounts.totalAmount, { original: '200.00', reversed: '-200.00' });
  assert.deepEqual(rows(reloaded, new Set()), []);
  const negative = { ...original, total_amount: '-200.00' };
  assert.equal(core.documentStornoPresentation(core.createTestDocumentStorno(negative, testCommand(negative), context())).amounts.totalAmount.reversed, '200.00');
});

test('test Storno does not consult, generate, reverse or modify GL postings or external integration state', () => {
  for (const posting of [undefined, fixture().accounting_posting, { invalid: true }, { ...fixture().accounting_posting, integration: { destination: 'External', status: 'Transferred', externalId: 'ERP-1' } }]) {
    const original = { ...fixture(), accounting_posting: posting }, before = structuredClone(original);
    const journalBefore = rows(original, new Set());
    const next = core.createTestDocumentStorno(original, testCommand(original), context());
    assert.deepEqual(original, before);
    assert.deepEqual(next.accounting_posting, before.accounting_posting);
    assert.equal(next.accounting_storno, undefined);
    assert.deepEqual(rows(next, new Set()), journalBefore);
    assert.equal(core.documentStornoPresentation(next).status, 'Reversed');
    assert.doesNotMatch(next.document_storno.sourceSnapshot, /accounting_posting|integration|GL-701/);
  }
});

test('test Storno retains permission, confirmation, period, reason and duplicate controls', () => {
  const original = { ...fixture(), accounting_posting: undefined, document_date: '2026-10-15' };
  assert.throws(() => core.createTestDocumentStorno(original, testCommand(original), { ...context(), allowed: false }), /access/);
  const next = core.createTestDocumentStorno(original, testCommand(original), context());
  assert.throws(() => core.createTestDocumentStorno(next, testCommand(next), context()), /already/);
  assert.throws(() => core.createTestDocumentStorno({ ...original, total_amount: '300' }, testCommand(original), context()), /changed/);
  for (const patch of [{ status: 'Draft' }, { status: 'Processing' }, { inactive: true }, { total_amount: '' }, { total_amount: '0' }, { currency: '' }, { company_id: '' }, { accounting_storno: {} }])
    assert.throws(() => core.createTestDocumentStorno({ ...original, ...patch }, testCommand({ ...original, ...patch }), context()));
  for (const patch of [{ reason: '' }, { reason: 'x'.repeat(2001) }, { date: '2026-02-30' }, { date: '2026-10-01' }, { date: '2027-01-01' }])
    assert.throws(() => core.createTestDocumentStorno(original, { ...testCommand(original), ...patch }, context()));
  assert.throws(() => core.createTestDocumentStorno(original, testCommand(original), { ...context(), period: { ...context().period, closedThrough: '2026-11-03' } }), /locked/);
  for (const patch of [{ document_storno: undefined }, { document_storno: {} }, { status: 'Draft' }, { total_amount: '500' }, { company_id: 'other' }, { inactive: true }]) assert.throws(() => guard(next, patch));
  assert.throws(() => guard({}, { document_storno: next.document_storno }));
  assert.doesNotThrow(() => guard(next, structuredClone(next)));
  const invalid = { ...next, total_amount: '500' };
  assert.match(core.savedTestDocumentStornoError(invalid), /integrity/);
  assert.equal(core.documentStornoPresentation(invalid), null);
});

test('Storno requires the current Approved or Confirmed status, not another completed workflow stage', () => {
  for (const status of ['Approved', 'Confirmed', ' approved ']) {
    const doc = { ...fixture(), status, accounting_posting: undefined };
    assert.equal(core.testDocumentStornoBlocker(doc, true), '');
  }
  for (const status of ['Draft', 'New', 'Pending', 'Processing', 'Rejected', 'Paid', 'Transferred', 'Exported', 'Posted', 'Processed', 'Accepted', 'Completed', 'Reversed', 'custom:APPROVED']) {
    const doc = { ...fixture(), status, accounting_note_status: 'Approved' };
    assert.ok(core.testDocumentStornoBlocker(doc, true), status);
    assert.throws(() => core.createTestDocumentStorno(doc, testCommand(doc), context()), /confirmed|processing/);
  }
  assert.equal(core.testDocumentStornoBlocker({ ...fixture(), status: '', accounting_note_status: 'Approved' }, true), '');
});

test('unavailable Storno actions are hidden in the detail header and list, not rendered disabled', () => {
  const form = source('../src/components/DocumentStornoAction.tsx');
  assert.match(form, /eligibleDocument === eligibilityKey && !unsavedChanges/);
  assert.match(form, /!testDocumentStornoBlocker\(document, canStornoDocument\(company\)\)/);
  assert.match(form, /currentRequest !== request/);
  assert.match(form, /document-storno-changed/);
  assert.doesNotMatch(form, /disabled=\{unsavedChanges\}/);
  assert.match(source('../src/components/Documents.tsx'), /contextAction.kind !== 'storno' \|\| !contextAction.disabledReason/);
});

test('Storno swaps exact D/K and base amounts, retains dimensions and never changes the original', () => {
  const original = fixture(), snapshot = structuredClone(original);
  const next = reverse(original, command(original), context());
  assert.deepEqual(original, snapshot); assert.deepEqual(next.accounting_posting, snapshot.accounting_posting); assert.equal(next.status, 'Approved');
  const reversal = next.accounting_storno;
  assert.equal(reversal.originalOperationId, original.accounting_posting.id);
  assert.equal(reversal.date, '2026-11-03'); assert.equal(reversal.reason, 'Document booked twice.'); assert.equal(reversal.postedBy, 'Reversing accountant');
  reversal.lines.forEach((line, i) => {
    const before = original.accounting_posting.lines[i];
    assert.equal(line.originalLineId, before.id); assert.notEqual(line.id, before.id);
    for (const key of ['account', 'accountName', 'currency', 'counterparty', 'department', 'costCenter', 'object']) assert.equal(line[key], before[key]);
    assert.equal(line.debitMinor, before.creditMinor); assert.equal(line.creditMinor, before.debitMinor);
    assert.equal(line.baseDebitMinor, before.baseCreditMinor); assert.equal(line.baseCreditMinor, before.baseDebitMinor);
  });
  assert.match(reversal.history[0].details, /GL-701.*2026-11-03.*Document booked twice/);
});

test('GL journal contains both immutable posted operations and their combined effect is zero', () => {
  const doc = fixture(), next = reverse(doc, command(doc), context());
  const result = rows(next, new Set(['6000', '2441', '4430']));
  assert.equal(result.length, 6); assert.ok(result.every(row => row.posted && row.balanced));
  assert.equal(new Set(result.map(row => row.document.id)).size, 2);
  assert.match(result.at(-1).document.note, /GL-701/);
  for (const account of ['6000', '2441', '4430']) {
    const entries = result.filter(row => row.account === account);
    assert.equal(entries.reduce((sum, row) => sum + Math.round((row.debit - row.credit) * 100), 0), 0);
    assert.equal(entries.reduce((sum, row) => sum + Math.round((row.baseDebit - row.baseCredit) * 100), 0), 0);
  }
});

test('Storno displays the exact opposite document amount while retaining original totals and posting', () => {
  const doc = { ...fixture(), total_amount: '200.00', amount_without_vat: '165.29', vat: '34.71' };
  const snapshot = structuredClone(doc);
  const next = reverse(doc, command(doc), context());
  const display = core.documentStornoPresentation(next);
  assert.equal(display.status, 'Reversed');
  assert.deepEqual(display.amounts.totalAmount, { original: '200.00', reversed: '-200.00' });
  assert.deepEqual(display.amounts.amountWithoutVat, { original: '165.29', reversed: '-165.29' });
  assert.deepEqual(display.amounts.vat, { original: '34.71', reversed: '-34.71' });
  assert.equal(display.number, next.accounting_storno.number);
  assert.equal(display.date, next.accounting_storno.date);
  assert.deepEqual(doc, snapshot);
  assert.equal(next.total_amount, '200.00'); assert.equal(next.status, 'Approved');
  assert.deepEqual(next.accounting_posting, snapshot.accounting_posting);
  assert.deepEqual(core.documentStornoPresentation(JSON.parse(JSON.stringify(next))), display, 'derived status and amounts survive reload');
  assert.deepEqual(core.oppositeDocumentAmount('-200'), { original: '-200.00', reversed: '200.00' });
  assert.deepEqual(core.oppositeDocumentAmount('0,01'), { original: '0.01', reversed: '-0.01' });
  assert.deepEqual(core.oppositeDocumentAmount('1 234,56'), { original: '1234.56', reversed: '-1234.56' });
  assert.deepEqual(core.oppositeDocumentAmount('-0.00'), { original: '0.00', reversed: '0.00' });
  for (const value of ['', null, undefined, 'unknown', '1.234', Infinity, '9999999999999999999']) assert.equal(core.oppositeDocumentAmount(value), null);
});

test('Reversed state comes only from an intact saved Storno, never a chosen status, credit amount or failed operation', () => {
  const doc = fixture();
  for (const source of [doc, { ...doc, status: 'Reversed' }, { ...doc, total_amount: '-200.00' }]) assert.equal(core.documentStornoPresentation(source), null);
  const next = reverse(doc, command(doc), context());
  next.accounting_storno.lines[0].creditMinor += 1;
  assert.equal(core.documentStornoPresentation(next), null);
  const missing = { ...reverse(doc, command(doc), context()), total_amount: '' };
  assert.equal(core.documentStornoPresentation(missing).status, 'Reversed');
  assert.equal(core.documentStornoPresentation(missing).amounts.totalAmount, null, 'missing money is not fabricated as zero');
});

test('register has one-click Reversed filter, read-only derived status and original-plus-Storno amount presentation', () => {
  const list = source('../src/components/Documents.tsx');
  assert.match(list, /storno: documentStornoPresentation\(r\)/);
  assert.match(list, /return document.storno\?\.status \|\| document.status/);
  assert.match(list, /aria-label="Show reversed documents" aria-pressed=\{reversedOnly\}/);
  assert.match(list, /\.filter\(\(doc\) => !reversedOnly \|\| Boolean\(doc.storno\)\)/);
  const shortcut = list.slice(list.indexOf('const toggleReversedDocuments'), list.indexOf('const applyFilterSelection'));
  for (const text of ["setSearchQuery('')", 'setSelectedStatus(null)', 'setSelectedPeriod(null)', 'setSelectedCurrency(null)', 'setSelectedCounterparty(null)', 'setDynamicFilters', 'setAppliedRangeMin(null)', 'setAppliedRangeMax(null)']) assert.ok(shortcut.includes(text), text);
  assert.doesNotMatch(shortcut, /setSelectedIds/);
  assert.match(list, /setReversedOnly\(false\)/, 'Clear filters also resets the shortcut');
  assert.match(list, /disabled=\{Boolean\(doc.storno\) \|\| !editableCompanyIds/);
  assert.match(list, /Original: \{doc.storno.amounts\[col.key\]!\.original\}/);
  assert.match(list, /doc.storno.amounts\[col.key\]!\.reversed/);
  assert.match(list, /documentCellValue\(document, key as keyof Document\)/, 'sort and filters use the displayed signed amounts');
  assert.match(source('../src/components/DocumentStornoAction.tsx'), /aria-label="Storno amounts"/);
  assert.match(source('../src/components/DocumentStornoAction.tsx'), /amount.reversed/);
});

test('no posting is inferred from Approved status, totals or combined same-row D/K previews', () => {
  const doc = fixture(); delete doc.accounting_posting;
  assert.match(blocked(doc, true), /No confirmed GL/); assert.throws(() => reverse(doc, command(doc), context()), /No confirmed/);
  const malformed = fixture(); malformed.accounting_posting.lines[0].creditMinor = 10000;
  assert.match(blocked(malformed, true), /invalid/);
  assert.deepEqual(rows(malformed, new Set()), []);
});

test('invalid, unbalanced, mismatched-company, unposted, or incomplete original operations are rejected', () => {
  const mutations = [
    d => d.accounting_posting.status = 'Draft', d => d.accounting_posting.companyId = 'company-2', d => d.accounting_posting.documentId = 'other',
    d => d.accounting_posting.lines.pop(), d => d.accounting_posting.lines[0].debitMinor = -1,
    d => d.accounting_posting.lines[0].debitMinor = 1.5, d => d.accounting_posting.lines[0].baseDebitMinor = 1,
    d => d.accounting_posting.lines[0].baseCreditMinor = 100,
    d => d.accounting_posting.lines[0].id = 'l2', d => d.accounting_posting.lines[0].account = '',
    d => d.accounting_posting.lines[0].account = 6000, d => d.accounting_posting.lines[0].id = {},
    d => d.accounting_posting.postedBy = {}, d => d.accounting_posting.number = {},
    d => d.accounting_posting.postedBy = '', d => d.accounting_posting.baseCurrency = 'wrong',
  ];
  for (const mutate of mutations) { const doc = fixture(); mutate(doc); assert.ok(blocked(doc, true)); assert.throws(() => reverse(doc, command(doc), context())); }
});

test('mixed-currency postings are balanced in base currency and reverse without converting again', () => {
  const doc = fixture();
  doc.accounting_posting.lines[2].currency = 'EUR';
  doc.accounting_posting.lines[2].creditMinor = 10890;
  const next = reverse(doc, command(doc), context());
  assert.equal(next.accounting_storno.lines[2].debitMinor, 10890);
  assert.equal(next.accounting_storno.lines[0].creditMinor, 10000);
  assert.equal(rows(next, new Set()).length, 6);
});

test('saved reversals must retain exact source amounts, dimensions, linkage and history', () => {
  const doc = fixture();
  const valid = reverse(doc, command(doc), context());
  assert.equal(core.savedDocumentStornoError(valid), '');
  for (const mutate of [
    d => d.accounting_storno.originalOperationId = 'another-posting',
    d => d.accounting_storno.lines[0].account = '9999',
    d => d.accounting_storno.lines[0].department = 'different',
    d => d.accounting_storno.history = [],
    d => d.accounting_storno.reason = '',
  ]) {
    const next = structuredClone(valid); mutate(next);
    assert.match(core.savedDocumentStornoError(next), /integrity/);
    assert.equal(rows(next, new Set()).length, 3);
    assert.throws(() => reverse(next, command(doc), context()), /already been reversed/);
  }
});

test('duplicate reversals, stale source snapshots, revoked access, missing reasons and invalid dates are refused', () => {
  const doc = fixture(); const next = reverse(doc, command(doc), context());
  assert.throws(() => reverse(next, command(doc), context()), /already been reversed/);
  assert.throws(() => reverse(doc, { ...command(doc), expectedPosting: '{}' }, context()), /has changed/);
  assert.throws(() => reverse(doc, command(doc), { ...context(), allowed: false }), /access/);
  for (const reason of ['', '  ', 'x'.repeat(2001)]) assert.throws(() => reverse(doc, { ...command(doc), reason }, context()), /reason/);
  for (const date of ['2026-02-30', '2026-10-01', '2027-01-01', '']) assert.throws(() => reverse(doc, { ...command(doc), date }, context()));
});

test('external accounting is fail-closed, including pending, failed, unknown and transferred document flags', () => {
  for (const status of ['Pending', 'Transferred', 'Failed', 'Unknown', undefined]) {
    const doc = fixture(); doc.accounting_posting.integration.status = status;
    assert.throws(() => reverse(doc, command(doc), context()), /External accounting/);
  }
  for (const patch of [{ status: 'Transferred' }, { status: 'Exported' }, { exported_at: '2026-11-02' }, { external_posting_id: 'ERP-1' }]) {
    const doc = { ...fixture(), ...patch }; assert.throws(() => reverse(doc, command(doc), context()), /External accounting/);
  }
  const doc = fixture(); doc.accounting_posting.integration.destination = 'External';
  assert.throws(() => reverse(doc, command(doc), context()), /External accounting/);
  delete doc.accounting_posting.integration; assert.throws(() => reverse(doc, command(doc), context()), /External accounting/);
});

test('period locking checks reversal date; a closed original period can be reversed in an open period', () => {
  const doc = fixture(); doc.accounting_posting.date = '2025-01-15';
  assert.doesNotThrow(() => reverse(doc, command(doc), context()));
  assert.match(stornoPeriodError('2026-09-30', '2025-01-15', '2026-11-03', context().period), /closed/);
  assert.equal(stornoPeriodError('2026-10-15', '2025-01-15', '2026-11-25', context().period), '');
  assert.match(stornoPeriodError('2026-10-15', '2025-01-15', '2026-11-26', context().period), /closed/);
  assert.match(stornoPeriodError('2026-11-03', '2025-01-15', '2026-11-03', { enabled: false, cutoffDay: 25, closedThrough: '2026-11-03' }), /locked/);
  assert.equal(stornoPeriodError('2026-01-01', '2025-01-15', '2026-11-03', { enabled: false, cutoffDay: 25 }), '');
});

test('ordinary writes cannot erase posted history, overwrite accounting data, or inject a reversal', () => {
  const doc = fixture(), next = reverse(doc, command(doc), context());
  for (const patch of [{ accounting_posting: undefined }, { accounting_storno: undefined }, { accounting_storno: {} }, { currency: 'EUR' }, { status: 'Draft' }, { company_id: 'company-2' }, { line_items: [] }, { inactive: true }])
    assert.throws(() => guard(next, patch));
  assert.throws(() => guard({}, { accounting_posting: doc.accounting_posting }));
  assert.doesNotThrow(() => guard(next, { notes: 'Supporting note' }));
  assert.doesNotThrow(() => guard(next, structuredClone(next)));
});

function adapterFixture() {
  const storage = new Map(); const localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) };
  const permissions = { allowed: true };
  const issues = {}; new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  const api = {};
  const require = name => {
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './documentStorno') return core;
    if (name === './documentIssues') return issues;
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    if (name === './documentStornoAccess') return { canStornoDocument: () => permissions.allowed, loadStornoPeriodPolicy: () => ({ enabled: false, cutoffDay: 25 }) };
    throw new Error(name);
  };
  const fakeWindow = { localStorage, setTimeout, clearTimeout, dispatchEvent() {} };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require, fakeWindow, {}, async () => { throw new Error('Static deployment'); }, class {});
  const put = (table, value) => storage.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(value));
  const get = table => JSON.parse(storage.get(`finansu-harmonija-v4:data:${table}`));
  put('companies', [{ id: 'company-1', name: 'Company 1' }]); put('documents', [fixture()]); put('document_history', []);
  return { ...api, put, get, permissions };
}

test('actual write boundary stores only test document Storno and audit, preserves GL and rejects concurrent duplicates', async () => {
  const f = adapterFixture(), doc = fixture(), cmd = { ...testCommand(doc), date: core.accountingToday() };
  const ledger = [{ id: 'existing-gl', debit: 121, credit: 0 }]; f.put('gl_journal', ledger);
  const results = await Promise.allSettled([f.applyDocumentStorno(doc.id, doc.company_id, cmd), f.applyDocumentStorno(doc.id, doc.company_id, cmd)]);
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(f.get('documents').length, 1);
  assert.deepEqual(f.get('documents')[0].accounting_posting, doc.accounting_posting);
  assert.equal(f.get('documents')[0].accounting_storno, undefined);
  assert.equal(f.get('documents')[0].document_storno.history.length, 1);
  assert.deepEqual(f.get('gl_journal'), ledger);
  assert.deepEqual(rows(f.get('documents')[0], new Set()), rows(doc, new Set()));
  assert.equal(core.documentStornoPresentation(f.get('documents')[0]).status, 'Reversed');
  assert.equal(core.documentStornoPresentation(f.get('documents')[0]).amounts.totalAmount.reversed, '-121.00');
  assert.equal(f.get('document_history').length, 1);
  assert.equal((await f.supabase.from('documents').update({ status: 'Draft' }).eq('id', doc.id)).data, null);
  assert.equal((await f.supabase.from('documents').delete().eq('id', doc.id)).data, null);
  assert.equal((await f.supabase.from('documents').upsert({ ...doc, document_storno: undefined }, { onConflict: 'id' })).data, null);
  assert.ok(f.get('documents')[0].document_storno);
});

test('adapter saves without linked GL and reversed documents cannot be erased or edited through ordinary writes', async () => {
  const f = adapterFixture(), doc = { ...fixture(), accounting_posting: undefined };
  f.put('documents', [doc]);
  await f.applyDocumentStorno(doc.id, doc.company_id, { ...testCommand(doc), date: core.accountingToday() });
  const saved = f.get('documents')[0];
  assert.equal(saved.accounting_posting, undefined); assert.equal(saved.accounting_storno, undefined);
  assert.equal(saved.document_storno.mode, 'test');
  assert.equal((await f.supabase.from('documents').update({ status: 'Draft' }).eq('id', doc.id)).data, null);
  assert.equal((await f.supabase.from('documents').delete().eq('id', doc.id)).data, null);
  assert.deepEqual(f.get('documents')[0], saved);
});

test('write boundary rechecks company scope and permissions without partial writes', async () => {
  const f = adapterFixture(), doc = fixture(), cmd = { ...testCommand(doc), date: core.accountingToday() };
  f.permissions.allowed = false;
  await assert.rejects(f.applyDocumentStorno(doc.id, doc.company_id, cmd), /access/);
  f.permissions.allowed = true;
  await assert.rejects(f.applyDocumentStorno(doc.id, 'company-2', cmd), /no longer/);
  assert.equal(f.get('documents')[0].accounting_storno, undefined); assert.equal(f.get('documents')[0].document_storno, undefined); assert.equal(f.get('document_history').length, 0);
});

test('write boundary rejects a document whose current status is no longer approved', async () => {
  const f = adapterFixture(), doc = fixture();
  f.put('documents', [{ ...doc, status: 'Transferred' }]);
  await assert.rejects(f.applyDocumentStorno(doc.id, doc.company_id, { ...testCommand(doc), date: core.accountingToday() }), /confirmed document/);
  assert.equal(f.get('documents')[0].document_storno, undefined);
  assert.equal(f.get('document_history').length, 0);
});

test('Storno form uses document snapshot and amounts only, without a GL selector or posting preview', () => {
  const form = source('../src/components/DocumentStornoAction.tsx');
  assert.match(form, /expectedDocument: testStornoDocumentSnapshot\(document\)/);
  assert.match(form, /testDocumentStornoBlocker\(document, allowed\)/);
  assert.match(form, /Test Storno only/);
  assert.match(form, /No GL entries are created or changed/);
  assert.doesNotMatch(form, /document\?\.accounting_posting|expectedPosting|reversePostedLines|postedOperationError|Original D|Storno D|Reverse GL operation|GL account/);
});

test('single-document row and detail actions share Storno; no bulk Storno or automatic OCR/export', () => {
  const detail = source('../src/components/DocumentDetailPanel.tsx');
  assert.match(detail, /<DocumentStornoAction documentId=\{doc.id\} companyId=\{doc.companyId\}/);
  const list = source('../src/components/Documents.tsx');
  assert.match(list, /<DocumentStornoDialog documentId=\{rowActionDocument.documentId\} companyId=\{rowActionDocument.companyId\}/);
  assert.doesNotMatch(list, /applyDocumentStorno|selectedIds[^\n]*Storno/);
  assert.doesNotMatch(source('../src/lib/documentStorno.ts'), /runOcr|fetch\(|importMenuRecords/);
  assert.match(source('../src/components/CompanyGlJournalView.tsx'), /documentPostingRows/);
});

test('permission check uses fresh per-object role actions and fails closed on invalid configuration', () => {
  let session = { email: 'a@test.local', roleNames: ['Accountant'] };
  let edit = true, view = true, scope = true, active = true;
  const store = new Map(); const localStorage = { getItem: key => store.get(key) ?? null };
  const access = {};
  const require = name => {
    if (name === './accessControl') return { canEditMenu: () => edit, canViewMenu: () => view, isSystemAdministratorRole: name => name === 'Administrator', parseSession: () => session };
    if (name === './currentUser') return { AUTH_SESSION_KEY: 'session' };
    if (name === './linkedSettingsData') return { canAccessAssignedOrganization: () => scope };
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => active && edit && scope, canViewCompanyDocuments: () => active && view && scope };
    if (name === './recordLifecycle') return { isInactiveRecord: row => row.inactive };
    throw new Error(name);
  };
  new Function('exports', 'require', 'window', compile('../src/lib/documentStornoAccess.ts'))(access, require, { localStorage });
  const roleKey = 'finansu-harmonija:v7:settings:internal:roles';
  const configure = actions => store.set(roleKey, JSON.stringify([{ name: 'Accountant', actionPermissions: JSON.stringify({ documents: actions }) }]));
  configure(['READ', 'UPDATE', 'CREATE']); assert.equal(access.canStornoDocument({ id: 'c1' }), true);
  configure(['READ', 'UPDATE']); assert.equal(access.canStornoDocument({ id: 'c1' }), false);
  configure(['READ', 'UPDATE', 'CREATE']); edit = false; assert.equal(access.canStornoDocument({ id: 'c1' }), false);
  assert.equal(access.canViewStornoDocument({ id: 'c1' }), true);
  edit = true; scope = false; assert.equal(access.canStornoDocument({ id: 'c1' }), false);
  assert.equal(access.canViewStornoDocument({ id: 'c1' }), false);
  scope = true; view = false; assert.equal(access.canStornoDocument({ id: 'c1' }), false);
  view = true; store.set(roleKey, 'bad json'); assert.equal(access.canStornoDocument({ id: 'c1' }), false);
  store.set(roleKey, '[]'); session = { ...session, roleNames: ['Administrator'] }; assert.equal(access.canStornoDocument({ id: 'c1' }), true);
  active = false; assert.equal(access.canStornoDocument({ id: 'c1' }), false); assert.equal(access.canViewStornoDocument({ id: 'c1' }), false);
  active = true;
  session = null; assert.equal(access.canStornoDocument({ id: 'c1' }), false);
  const prefix = 'finansu-harmonija:v12:operation-date-validation:';
  store.set(`${prefix}assignments`, JSON.stringify({ c1: 'operation-date-early' }));
  assert.deepEqual(access.loadStornoPeriodPolicy('c1', localStorage), { enabled: true, cutoffDay: 20 });
  store.set(`${prefix}templates`, '[]'); assert.throws(() => access.loadStornoPeriodPolicy('c1', localStorage), /unavailable/);
  store.set(`${prefix}templates`, '{'); assert.throws(() => access.loadStornoPeriodPolicy('c1', localStorage));
});
