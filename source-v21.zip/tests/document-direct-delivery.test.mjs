import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const issues = {}, exportsCore = {}, delivery = {}, direct = {}, examples = {};
new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
new Function('exports', compile('../src/lib/documentExport.ts'))(exportsCore);
new Function('exports', compile('../src/lib/documentTestingExamples.ts'))(examples);
new Function('exports', 'require', compile('../src/lib/documentTestDelivery.ts'))(delivery, name => {
  if (name === './documentIssues') return issues;
  throw Error(name);
});
new Function('exports', 'require', compile('../src/lib/documentDirectDelivery.ts'))(direct, name => {
  if (name === './documentExport') return exportsCore;
  if (name === './documentTestDelivery') return delivery;
  throw Error(name);
});
const documents = examples.createDocumentTestingExamples('alice');
const company = { id: 'alice', name: 'Alice Stone', primary_export_format: 'Rivilė', accounting_destination_id: 'agnum' };
const prepare = (rows = documents, companies = [company], ids = [documents[0].id], expected = 'rivile', scope = 'alice') =>
  direct.prepareDirectDocumentDelivery(rows, companies, ids, scope, expected, 'direct-test-001');

test('Primary export format overrides the old saved destination and sends exactly the selected IDs', () => {
  const ids = [documents[2].id, documents[0].id, documents[2].id];
  const request = prepare(documents, [company], ids);
  assert.equal(request.destinationId, 'rivile');
  assert.equal(request.destinationSource, 'primary-export-format');
  assert.equal(request.companyId, 'alice');
  assert.equal(request.scenario, 'accepted');
  assert.deepEqual(request.ids, [documents[2].id, documents[0].id]);
  assert.deepEqual(Object.keys(request.snapshots), request.ids);
  assert.equal(request.snapshots[documents[0].id], delivery.documentTestDeliverySnapshot(documents[0]));
});

test('missing and stale Primary export formats produce inline errors, never setup dialogs or old defaults', () => {
  const noDestination = { ...company, primary_export_format: '' };
  assert.throws(() => direct.prepareDirectDocumentDelivery(documents, [noDestination], [documents[0].id], 'alice', undefined, 'direct-test-001'), /Set an active Primary export format/);
  assert.throws(() => prepare(documents, [noDestination]), /Set an active Primary export format/);
  assert.throws(() => prepare(documents, [{ ...company, primary_export_format: 'Agnum' }]), /Primary export format has changed/);
  assert.throws(() => prepare(documents, [{ ...company, counterparties_settings: JSON.stringify({ exportIntegrations: [{ id: 'rivile', name: 'Rivilė', active: false }] }) }]), /Set an active Primary export format/);
  assert.equal(prepare(documents, [{ ...company, primary_export_format: 'B1' }], [documents[0].id], 'b1').destinationId, 'b1');
});

test('fresh selection and company scope are required', () => {
  assert.throws(() => prepare(documents, [company], []), /Select at least one/);
  assert.throws(() => prepare(documents, [company], ['removed']), /no longer available/);
  assert.throws(() => prepare(documents, []), /company is no longer available/);
  const other = { ...documents[0], id: 'other-doc', company_id: 'other' };
  assert.throws(() => prepare([...documents, other], [company], [other.id]), /no longer available/);
  assert.throws(() => prepare([...documents, other], [company], [documents[0].id, other.id], 'rivile', ''), /one company/);
});

test('direct delivery keeps validation and reports only this request, with explicit simulation wording', () => {
  const selected = [documents[0], documents[10]];
  const request = prepare(documents, [company], selected.map(row => row.id));
  const records = selected.map(row => ({ number: row.number, testDeliveries: [
    { ...delivery.createDocumentTestDelivery(row, request, 'Rivilė', 'Accountant', 'now'), requestId: 'old-request' },
    delivery.createDocumentTestDelivery(row, request, 'Rivilė', 'Accountant', 'now'),
  ] }));
  assert.deepEqual(records.map(row => row.testDeliveries[1].outcome), ['Accepted', 'Blocked']);
  const notice = direct.directDocumentDeliveryNotice(records, request.requestId);
  assert.equal(notice.error, true);
  assert.match(notice.message, /Test send to Rivilė · 1 accepted · 1 blocked/);
  assert.match(notice.message, /No real transfer/);
  assert.ok(notice.message.includes(documents[10].number));
  assert.match(notice.message, /Resolve.*issue/);
});

test('successful sends show a compact test notice, and absent receipts cannot claim success', () => {
  const request = prepare();
  const records = [{ number: documents[0].number, testDeliveries: [delivery.createDocumentTestDelivery(documents[0], request, 'Rivilė', 'Accountant', 'now')] }];
  assert.deepEqual(direct.directDocumentDeliveryNotice(records, request.requestId), { error: false, message: 'Test send to Rivilė completed · 1 document. No real transfer.' });
  assert.deepEqual(direct.directDocumentDeliveryNotice(records, 'missing'), { error: true, message: 'No delivery result received. Check document history before trying again.' });
});

test('Documents actions send directly from company settings, while file export remains separate', () => {
  const source = read('../src/components/Documents.tsx');
  assert.match(source, /onClick=\{\(\) => void sendDocuments\(\[\.\.\.selectedIds\], primaryDestination\?\.value\)\}/);
  assert.match(source, /onClick=\{\(\) => void sendDocuments\(\[doc\.id\]/);
  assert.match(source, /if \(directTransferPending\.current \|\| delivery\) return/);
  const sendFunction = source.slice(source.indexOf('async function sendDocuments('), source.indexOf('async function sendDocuments(') + 1300);
  assert.match(sendFunction, /await persistDocumentDelivery\(command\)/);
  assert.doesNotMatch(sendFunction, /setDelivery\(/);
  assert.doesNotMatch(source, /ariaLabel="Change accounting system"|setDelivery\(\{ mode: 'transfer'/);
  assert.match(source, /\['documents', 'companies'\]\.includes/);
  assert.match(source, /onClick=\{\(\) => setDelivery\(\{ mode: 'export', ids: \[\.\.\.selectedIds\] \}\)\}/);
  assert.match(source, /role=\{transferNotice\.error \? 'alert' : 'status'\}/);
  assert.doesNotMatch(source, /Open transfer details/);
});
