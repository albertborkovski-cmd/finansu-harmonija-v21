import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(read(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const storno = {}, actions = {}, approval = {}, issues = {};
new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
new Function('exports', 'require', compile('../src/lib/documentRowActions.ts'))(actions, () => storno);
new Function('exports', 'require', compile('../src/lib/documentApproval.ts'))(approval, name => name === './documentStorno' ? storno : actions);
new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
const source = { id: 'approved-1', company_id: 'company-1', number: 'INV-120', status: 'Approved', document_type: 'INVOICES',
  operation_date: '2026-11-01', document_date: '2026-11-01', total_amount: '121.00', currency: 'EUR', line_items: [{ id: 'line-1', total: '121' }] };
const context = { allowed: true, today: '2026-11-09', period: { enabled: true, cutoffDay: 25 }, hasCorrections: false,
  id: 'cancel-1', actor: 'Accountant', now: '2026-11-09T10:00:00Z' };
const command = document => ({ expectedSnapshot: actions.documentActionSnapshot(document), reason: 'Correct supplier details' });

test('Cancel approval is available only for an eligible confirmed document', () => {
  for (const status of ['Approved', 'Confirmed']) assert.equal(approval.cancelDocumentApprovalBlocker({ ...source, status }, context), '');
  for (const status of ['Draft', 'Pending', 'Processing', 'Transferred', 'Exported', 'Paid', 'Reversed'])
    assert.ok(approval.cancelDocumentApprovalBlocker({ ...source, status }, context));
  for (const patch of [{ accounting_posting: {} }, { accounting_storno: {} }, { document_storno: {} }, { document_deletion: {} },
    { inactive: true }, { active: false }, { is_active: false }, { exported_at: '2026-11-02' }, { transferred: true },
    { external_document_id: 'external-1' }, { transfer_status: 'Pending' }, { export_status: 'Failed' },
    { accounting_note_status: 'Transferred' }, { corrected_by_document_id: 'credit-1' }, { operation_date: '', document_date: '' },
    { digitization_issues: [{ status: 'Awaiting OCR' }] }]) assert.ok(approval.cancelDocumentApprovalBlocker({ ...source, ...patch }, context), JSON.stringify(patch));
  assert.ok(approval.cancelDocumentApprovalBlocker(source, { ...context, allowed: false }));
  assert.ok(approval.cancelDocumentApprovalBlocker(source, { ...context, hasCorrections: true }));
  assert.ok(approval.cancelDocumentApprovalBlocker(source, { ...context, period: { enabled: false, cutoffDay: 25, closedThrough: '2026-11-30' } }));
  assert.ok(approval.cancelDocumentApprovalBlocker({ ...source, operation_date: '2026-09-15' }, context));
  assert.equal(approval.cancelDocumentApprovalBlocker({ ...source, accounting_test_deliveries: [{ outcome: 'Accepted' }], exported: false }, context), '');
});

test('cancellation prepares Draft and immutable audit without changing lines, amounts or original metadata', () => {
  const document = { ...source, accounting_note_status: 'Confirmed', approved_by: 'Original approver' };
  const original = structuredClone(document);
  const { patch, event } = approval.prepareDocumentApprovalCancellation(document, command(document), context);
  assert.deepEqual(document, original);
  assert.deepEqual(patch, { status: 'Draft', accounting_note_status: 'Draft' });
  assert.equal(event.fromStatus, 'Approved'); assert.equal(event.fromAccountingStatus, 'Confirmed');
  assert.equal(event.actor, 'Accountant'); assert.equal(event.reason, 'Correct supplier details');
  assert.equal(event.action, 'Approval cancelled'); assert.equal(event.toStatus, 'Draft');
  assert.throws(() => approval.prepareDocumentApprovalCancellation(document, { ...command(document), expectedSnapshot: '{}' }, context), /changed/);
  assert.throws(() => approval.prepareDocumentApprovalCancellation(document, { ...command(document), reason: 'x'.repeat(2001) }, context), /2,000/);
});

function fixture(document = { ...source, operation_date: storno.accountingToday(), document_date: storno.accountingToday() }) {
  const store = new Map(); let allowed = true, closed = false;
  const api = {};
  const require = name => {
    if (name === './currentUser') return { getCurrentUserName: () => 'Accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './documentApproval') return approval;
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => allowed };
    if (name === './documentStornoAccess') return { loadStornoPeriodPolicy: () => ({ enabled: false, cutoffDay: 25, ...(closed ? { closedThrough: '2099-01-01' } : {}) }) };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Isolated fixture'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', [document]); put('companies', [{ id: document.company_id, name: 'Test company' }]); put('document_history', [{ id: 'created', document_id: document.id }]);
  return { ...api, document, put, get, revoke: () => { allowed = false; }, lock: () => { closed = true; } };
}

test('write command returns the original to Draft with audit and reactivates unresolved issue protection', async () => {
  const f = fixture();
  const original = { ...f.document, digitization_issues: [{ id: 'issue-1', status: 'Open', blocksApproval: false, events: [] }] };
  f.put('documents', [original, { ...original, id: 'other', company_id: 'other-company' }]);
  const saved = await f.cancelDocumentApproval(original.id, original.company_id, command(original));
  assert.equal(saved.id, original.id); assert.equal(saved.status, 'Draft');
  assert.deepEqual(saved.line_items, original.line_items); assert.equal(saved.total_amount, original.total_amount);
  assert.equal(saved.digitization_issues[0].blocksApproval, true);
  assert.equal(saved.approval_cancellation_history[0].actor, 'Accountant');
  assert.equal(f.get('document_history').length, 2);
  assert.equal(f.get('document_history')[1].action, 'Approval cancelled');
  assert.equal(f.get('documents')[1].status, 'Approved');
  assert.equal((await f.supabase.from('documents').select('*').eq('id', original.id)).data[0].status, 'Draft');
  const reloaded = fixture(saved);
  assert.deepEqual((await reloaded.supabase.from('documents').select('*')).data[0].approval_cancellation_history, saved.approval_cancellation_history);
  assert.ok((await f.supabase.from('documents').update({ approval_cancellation_history: [] }).eq('id', saved.id)).error);
  assert.ok((await f.supabase.from('documents').update({ status: 'Approved' }).eq('id', saved.id)).error);
});

test('fresh scope, permissions, period, transfer, corrections and snapshot are rechecked before cancellation', async () => {
  for (const change of [f => f.revoke(), f => f.lock(),
    f => f.put('documents', [{ ...f.document, status: 'Transferred' }]),
    f => f.put('documents', [{ ...f.document, number: 'CHANGED' }]),
    f => f.put('documents', [{ ...f.document, accounting_posting: {} }]),
    f => f.put('documents', [{ ...f.document, document_deletion: { at: 'now' } }]),
    f => f.put('documents', [f.document, { id: 'credit', company_id: source.company_id, correction_of_document_id: source.id }]),
  ]) {
    const f = fixture(); change(f); const before = structuredClone(f.get('documents'));
    await assert.rejects(f.cancelDocumentApproval(f.document.id, f.document.company_id, command(f.document)));
    assert.deepEqual(f.get('documents'), before); assert.equal(f.get('document_history').length, 1);
  }
  const f = fixture();
  await assert.rejects(f.cancelDocumentApproval(f.document.id, 'other-company', command(f.document)), /company/);
  const results = await Promise.allSettled([1, 2].map(() => f.cancelDocumentApproval(f.document.id, f.document.company_id, command(f.document))));
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(f.get('documents')[0].approval_cancellation_history.length, 1);
});

test('ordinary status edits cannot bypass the cancellation workflow', async () => {
  const f = fixture();
  for (const status of ['Draft', 'Pending', 'Correcting', '']) assert.ok((await f.supabase.from('documents').update({ status }).eq('id', source.id)).error);
  assert.equal(f.get('documents')[0].status, 'Approved');
});

test('Actions opens a system confirmation for both imported documents and manual invoices', () => {
  const menu = read('../src/components/DocumentActionsMenu.tsx'), dialog = read('../src/components/DocumentRowActionDialog.tsx');
  const documents = read('../src/components/Documents.tsx'), invoice = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.match(menu, /loaded.cancelApproval && <button/);
  assert.match(menu, /onAction\('cancel-approval'\)/);
  assert.match(menu, /cancelDocumentApprovalBlocker/);
  assert.match(dialog, /Cancel approval and return this document to Draft for correction/);
  assert.match(dialog, /Reason \(optional\)/);
  assert.match(dialog, /await cancelDocumentApproval\(documentId, companyId/);
  assert.match(dialog, /onClick=\{onClose\}>Cancel<\/button>/);
  assert.match(documents, /onUpdated=\{document => \{ setViewDoc\(null\); setOpenDoc\(mapRow\(document\)\)/);
  assert.match(invoice, /documentManagementActions\?\.\(\{ unsavedChanges: !readOnly && hasChanges, busy: busy \|\| loading \}\)/);
  assert.match(dialog, /role="dialog" aria-modal="true"/);
});
