import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
function load(path, dependencies = {}) {
  const api = {};
  new Function('exports', 'require', ts.transpileModule(source(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(api, name => {
    if (!(name in dependencies)) throw new Error(`Unexpected dependency ${name}`);
    return dependencies[name];
  });
  return api;
}
const delivery = load('../src/lib/documentExport.ts');
const api = load('../src/lib/documentAccountingExport.ts', { './documentExport': delivery });
const company = { id: 'alice', name: 'Alice & Stone', apiKey: 'company-secret' };
const line = { id: 'line-1', expense: '4430', subtotal: '100.00', vat: '21.00', total: '121.00', vatClass: 'PVM1', privateValue: 'private-line' };
const documents = [
  { id: 'a', company_id: 'alice', number: 'INV-1', document_type: 'Purchase', client_counterparty: '<Amber & "Co">', currency: 'EUR', total_amount: '121.00', summary_line_items: [line], line_items: [{ product: 'Service', qty: '1', price: '100' }], notes: 'Note\u0001', image_url: 'private-file-url', apiKey: 'document-secret', accounting_test_deliveries: [{ actor: 'private-audit' }] },
  { id: 'b', company_id: 'alice', number: 'INV-2', summary_line_items: [{ ...line, id: 'line-2' }, { ...line, id: 'line-3' }] },
  { id: 'c', company_id: 'other', number: 'OTHER-1' },
];
const at = '2026-11-04T10:00:00.000Z';

test('system selection creates XML previews for Rivilė and Agnum, JSON for Rivilė API', () => {
  for (const destination of ['rivile', 'agnum']) {
    const file = api.buildDocumentAccountingExport(documents, ['a'], company, destination, at);
    assert.match(file.filename, /TEST-documents-2026-11-04\.xml$/);
    assert.equal(file.mime, 'application/xml;charset=utf-8');
    assert.match(file.content, /^<\?xml version="1.0" encoding="UTF-8"\?>/);
    assert.ok(file.content.includes(`<Destination id="${destination}">`));
    assert.match(file.content, /mode="test" importReady="false"/);
    assert.match(file.content, /<Documents count="1">/);
    assert.match(file.content, /&lt;Amber &amp; &quot;Co&quot;&gt;/);
    assert.doesNotMatch(file.content, /\u0001/);
  }
  const file = api.buildDocumentAccountingExport(documents, ['a'], company, 'rivile-api', at);
  assert.match(file.filename, /Rivilė-API-TEST.*\.json$/);
  const data = JSON.parse(file.content);
  assert.equal(data.destination.id, 'rivile-api');
  assert.equal(data.mode, 'test');
  assert.equal(data.importReady, false);
  assert.equal(data.schema, 'finansu-harmonija.accounting-export-preview.v1');
});

test('exact selection includes all accounting allocations regardless of visible columns and never changes source records', () => {
  const before = structuredClone(documents);
  const file = api.buildDocumentAccountingExport(documents, ['b', 'a', 'b'], company, 'rivile-api', at);
  const result = JSON.parse(file.content);
  assert.deepEqual(result.documents.map(row => row.id), ['b', 'a']);
  assert.equal(result.documents[0].accountingAllocations.length, 2);
  assert.equal(result.documents[1].accountingAllocations[0].expense, '4430');
  assert.equal(result.documents[1].documentLines[0].product, 'Service');
  assert.equal(result.documents[1].total_amount, '121.00');
  assert.deepEqual(documents, before);
});

test('only allowlisted accounting fields are exported, never endpoints, credentials, attachments or audit records', () => {
  for (const destination of ['rivile', 'agnum', 'rivile-api']) {
    const file = api.buildDocumentAccountingExport(documents, ['a'], company, destination, at);
    assert.doesNotMatch(file.content, /private-|secret|apiKey|image_url|accounting_test_deliveries/);
  }
});

test('fresh selection and destination validation prevents missing, cross-company or disabled exports', () => {
  assert.throws(() => api.buildDocumentAccountingExport(documents, [], company, 'rivile'), /Select/);
  assert.throws(() => api.buildDocumentAccountingExport(documents, ['missing'], company, 'rivile'), /no longer/);
  assert.throws(() => api.buildDocumentAccountingExport(documents, ['a', 'c'], company, 'rivile'), /no longer/);
  assert.throws(() => api.buildDocumentAccountingExport(documents, ['a'], company, 'unknown'), /no longer available/);
  const disabled = { ...company, counterparties_settings: JSON.stringify({ exportIntegrations: [{ id: 'rivile', name: 'Rivilė', active: false }] }) };
  assert.throws(() => api.buildDocumentAccountingExport(documents, ['a'], disabled, 'rivile'), /no longer available/);
});

test('custom active destinations also have an explicitly marked JSON test file, without leaking integration config', () => {
  const custom = { ...company, counterparties_settings: JSON.stringify({ exportIntegrations: [{ id: 'custom', name: 'Custom ERP', apiUrl: 'private-endpoint', apiKey: 'secret' }] }) };
  const file = api.buildDocumentAccountingExport(documents, ['a'], custom, 'custom', at);
  const payload = JSON.parse(file.content);
  assert.deepEqual(payload.destination, { id: 'custom', name: 'Custom ERP' });
  assert.equal(payload.importReady, false);
  assert.doesNotMatch(file.content, /private-|secret/);
});
