import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

function load(name) {
  const source = readFileSync(new URL(`../src/lib/${name}.ts`, import.meta.url), 'utf8');
  const output = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  const exports = {}; new Function('exports', output)(exports); return exports;
}
const examples = load('documentTestingExamples');
const inline = load('documentInlineEditing');
const issues = load('documentIssues');
const storno = load('documentStorno');
const documents = examples.createDocumentTestingExamples('alice-stone');
const minor = value => Math.round(Number(value) * 100);
const sum = (rows, key) => rows.reduce((total, row) => total + minor(row[key]), 0);

test('20 synthetic documents have stable unique identities and belong only to the requested company', () => {
  assert.equal(documents.length, 20);
  assert.equal(new Set(documents.map(row => row.id)).size, 20);
  assert.equal(new Set(documents.map(row => row.number)).size, 20);
  assert.deepEqual(documents.map(row => row.number), Array.from({ length: 20 }, (_, i) => `TEST-V20-${String(i + 1).padStart(3, '0')}`));
  assert.ok(documents.every(row => row.company_id === 'alice-stone' && row.notes.startsWith('Synthetic V20 test document')));
  assert.deepEqual(examples.createDocumentTestingExamples('alice-stone'), documents);
  assert.throws(() => examples.createDocumentTestingExamples(''));
  assert.throws(() => examples.createDocumentTestingExamples('alice-stone', 'invalid'));
});

test('header, OCR product lines and accounting allocations reconcile to the cent, including credit and discounts', () => {
  for (const row of documents) {
    assert.equal(minor(row.amount_without_vat) + minor(row.vat), minor(row.total_amount), row.number);
    for (const lines of [row.line_items, row.summary_line_items]) {
      assert.equal(sum(lines, 'subtotal'), minor(row.amount_without_vat), row.number);
      assert.equal(sum(lines, 'vat'), minor(row.vat), row.number);
      assert.equal(sum(lines, 'total'), minor(row.total_amount), row.number);
      for (const line of lines) {
        assert.equal(minor(line.price) * Number(line.qty) - minor(line.discount), minor(line.subtotal), row.number);
        assert.equal(minor(line.subtotal) + minor(line.vat), minor(line.total), row.number);
      }
    }
  }
  assert.ok(Number(documents[7].total_amount) < 0);
  assert.ok(Number(documents[8].total_amount) < 0);
  assert.equal(sum(documents[14].line_items, 'discount'), 8250);
});

test('examples test allocation counts independently of product counts and keep protected states locked', () => {
  assert.equal(documents[1].line_items.length, 12);
  assert.equal(inline.documentAllocationCount(documents[1]), 1);
  assert.equal(inline.documentInlineEditError(documents[1], 'expenseAccount', true), '');
  assert.equal(documents[2].line_items.length, 1);
  assert.equal(inline.documentAllocationCount(documents[2]), 3);
  assert.match(inline.documentInlineEditError(documents[2], 'expenseAccount', true), /accounting allocations/);
  assert.equal(inline.documentInlineEditError(documents[2], 'note', true), '');
  assert.deepEqual([...new Set(documents.map(row => row.currency))].sort(), ['EUR', 'GBP', 'USD']);
  assert.ok(new Set(documents.map(row => row.status)).size >= 8);
  assert.equal(documents.filter(row => !inline.documentEditStateError(row)).length, 17);
  for (const row of documents.slice(17)) assert.notEqual(inline.documentEditStateError(row), '');
});

test('reported issue blocks approval, confirmed posting is balanced and can be reversed only through Storno', () => {
  const issue = documents[10];
  assert.throws(() => issues.guardDocumentMutation(issue, { status: 'Approved' }, 'Test'), /Resolve/);
  const posted = documents[17];
  assert.equal(storno.postedOperationError(posted.accounting_posting, posted), '');
  assert.equal(storno.documentStornoBlocker(posted, true), '');
  assert.notEqual(storno.documentStornoBlocker(posted, false), '');
  assert.equal(posted.accounting_posting.integration.status, 'Not sent');
});

test('adding the batch never overwrites existing records or recreates edited/deleted examples', () => {
  const existing = [{ id: 'real-document', notes: 'Keep me' }];
  const before = structuredClone(existing);
  assert.equal(examples.missingDocumentTestingExamples(existing, 'alice-stone').length, 20);
  assert.deepEqual(existing, before);
  const editedExample = { ...documents[2], notes: 'User changes' };
  assert.deepEqual(examples.missingDocumentTestingExamples([...existing, editedExample], 'alice-stone'), []);
  assert.equal(examples.missingDocumentTestingExamples(documents, 'another-company').length, 20);
  assert.equal(editedExample.notes, 'User changes');
});
