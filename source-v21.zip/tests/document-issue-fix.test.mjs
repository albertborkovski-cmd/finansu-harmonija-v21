import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(source(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const load = (file, require = () => { throw Error('Unexpected import'); }) => {
  const result = {};
  new Function('exports', 'require', compile(file))(result, require);
  return result;
};
const issues = load('../src/lib/documentIssues.ts');
const inline = load('../src/lib/documentInlineEditing.ts');
const statuses = load('../src/lib/documentProcessingStatus.ts');
const details = load('../src/lib/documentDetailEditing.ts', name => name === './documentInlineEditing' ? inline : statuses);

function fixture() {
  const storage = new Map();
  const permissions = { edit: true, worker: true };
  const api = {};
  const require = name => {
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './documentIssues') return issues;
    if (name === './documentDetailEditing') return details;
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => permissions.edit };
    if (name === './documentIssueAccess') return { canReviewDocumentIssues: () => permissions.worker, canAccessIssueOrganization: company => company.id === 'actual-company' };
    if (name === './documentStorno') return load('../src/lib/documentStorno.ts');
    if (name === './currentUser') return { getCurrentUserName: () => 'MESO Worker' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} },
    {}, async () => { throw Error('Isolated static test'); }, class {});
  const put = (table, rows) => storage.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(storage.get(`finansu-harmonija-v4:data:${table}`));
  const document = issues.transitionDocumentIssue({ id: 'test-document', company_id: 'actual-company', number: 'TEST-1', status: 'Draft', notes: 'Wrong value' }, { type: 'report', message: 'Please correct the note' }, 'Accountant');
  put('documents', [document]); put('document_history', []); put('companies', [{ id: 'actual-company', name: 'Actual company' }]);
  return { ...api, permissions, document, get, put };
}

function actions(f, visits, save = true) {
  return {
    ...(save ? { saveChanges: async () => {
      await f.applyDocumentDetailEdit(f.document.id, f.document.company_id, { notes: 'Correct value' }, details.documentDetailSnapshot(f.document), 'Corrected document note');
      return true;
    } } : {}),
    fixIssue: () => f.applyDocumentIssueAction(f.document.id, f.document.company_id, {
      type: 'resolve', issueId: f.document.digitization_issues[0].id, note: 'Note verified against the original document',
    }),
    onFixed: document => visits.push({ companyId: document.company_id, document }),
  };
}

test('Fix issue saves corrections and audit, then returns the document to OCR without releasing approval', async () => {
  const f = fixture(), visits = [];
  assert.equal(await issues.saveAndFixDocumentIssue(actions(f, visits)), true);
  const saved = f.get('documents')[0];
  assert.equal(saved.notes, 'Correct value');
  assert.equal(saved.status, 'Processing');
  assert.equal(saved.ocr_rerun_request.status, 'Pending integration');
  assert.equal(saved.ocr_rerun_request.documentId, saved.id);
  assert.equal(saved.ocr_rerun_request.companyId, saved.company_id);
  assert.equal(saved.ocr_rerun_requests.length, 1);
  assert.equal(issues.documentIssueStatusLabel(issues.documentIssueStatus(saved)), 'Awaiting OCR');
  assert.equal(issues.hasBlockingDocumentIssue(saved), true);
  assert.equal(visits.length, 1);
  assert.equal(visits[0].companyId, 'actual-company');
  assert.deepEqual(visits[0].document, saved);
  const report = saved.digitization_issues[0];
  assert.equal(report.resolvedAt, undefined);
  assert.equal(report.resolution, undefined);
  assert.ok(report.correctedAt);
  assert.equal(report.ocrRequestId, saved.ocr_rerun_request.id);
  assert.equal(report.correctionNote, 'Note verified against the original document');
  assert.ok(report.events.some(event => event.changes?.some(change => change.field === 'notes' && change.after === 'Correct value')));
  assert.equal(report.events.at(-1).actor, 'MESO Worker');
  assert.equal(report.events.at(-1).action, 'Returned to OCR');
  assert.throws(() => issues.guardDocumentMutation(saved, { status: 'Approved' }, 'Accountant'), /Resolve/);
});

test('failed or rejected save never fixes the report or navigates', async () => {
  const f = fixture(), visits = [];
  assert.equal(await issues.saveAndFixDocumentIssue({ ...actions(f, visits), saveChanges: async () => false }), false);
  f.permissions.edit = false;
  await assert.rejects(issues.saveAndFixDocumentIssue(actions(f, visits)), /access/);
  assert.equal(f.get('documents')[0].notes, 'Wrong value');
  assert.equal(issues.documentIssueStatus(f.get('documents')[0]), 'Open');
  assert.equal(visits.length, 0);
});

test('revoked worker permission retains saved corrections but does not release or navigate', async () => {
  const f = fixture(), visits = [];
  f.permissions.worker = false;
  await assert.rejects(issues.saveAndFixDocumentIssue(actions(f, visits)), /Only MESO Worker/);
  assert.equal(f.get('documents')[0].notes, 'Correct value');
  assert.equal(issues.hasBlockingDocumentIssue(f.get('documents')[0]), true);
  assert.equal(visits.length, 0);
});

test('already-saved corrections can be queued; other reports remain open and duplicate hand-offs are idempotent', async () => {
  const f = fixture(), visits = [];
  f.put('documents', [issues.transitionDocumentIssue(f.document, { type: 'report', message: 'Another issue' }, 'Accountant')]);
  await issues.saveAndFixDocumentIssue(actions(f, visits, false));
  const saved = f.get('documents')[0];
  assert.equal(saved.digitization_issues[0].status, 'Awaiting OCR');
  assert.equal(saved.digitization_issues[1].status, 'Open');
  assert.equal(issues.documentIssueStatusLabel(issues.documentIssueStatus(saved)), 'Open');
  assert.equal(issues.hasBlockingDocumentIssue(saved), true);
  assert.throws(() => issues.guardDocumentMutation(saved, { status: 'Approved' }, 'Accountant'), /Resolve/);
  await issues.saveAndFixDocumentIssue(actions(f, visits, false));
  assert.deepEqual(f.get('documents')[0], saved);
  assert.equal(visits.length, 2);
});

test('UI replaces Report issue only in issue editing and keeps the Document issues route mounted', () => {
  const detail = source('../src/components/DocumentDetailPanel.tsx');
  assert.match(detail, /reportedIssueId \? <SaveButton/);
  assert.match(detail, /Fix issue/);
  assert.match(detail, /saveChanges: hasUnsavedChanges \? handleSaveChanges : undefined/);
  assert.match(detail, /fixingIssueRef.current/);
  assert.match(detail, /disabled=\{readOnly \|\| fixingIssue\}/);
  assert.doesNotMatch(source('../src/components/DocumentIssueQueue.tsx'), /onOpenCompanyDocuments|openCompany\(/);
  assert.doesNotMatch(source('../src/components/OcrDocumentIssuesView.tsx'), /onOpenCompanyDocuments/);
  assert.match(source('../src/components/Dashboard.tsx'), /activeMenu === "ocr-workspace-document-issues"\)\s*return <OcrDocumentIssuesView \/>/);
  assert.match(source('../src/components/DocumentIssueDialog.tsx'), /documentIssueStatusLabel\(status\)/);
  assert.match(source('../src/components/Documents.tsx'), /issueStatus: documentIssueStatusLabel\(documentIssueStatus\(r\)\)/);
});

test('successful Fix issue closes the document and refreshes the current list without resetting filters or navigating', async () => {
  const queue = source('../src/components/DocumentIssueQueue.tsx');
  const tree = ts.createSourceFile('DocumentIssueQueue.tsx', queue, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let handler;
  const visit = node => {
    if (ts.isJsxAttribute(node) && node.name.getText(tree) === 'onIssueFixed') handler = node.initializer.expression;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(handler && ts.isArrowFunction(handler));
  const events = [];
  const onFixed = new Function('setEditing', 'load', 'setQueuedNotice', `return (${handler.getText(tree)});`)(
    value => events.push(['editing', value]),
    () => { events.push(['refresh']); return Promise.resolve(); },
    message => { assert.match(message, /Awaiting OCR/); assert.match(message, /remain blocked/); },
  );
  const f = fixture();
  await issues.saveAndFixDocumentIssue({ ...actions(f, []), onFixed });
  assert.equal(issues.documentIssueStatusLabel(issues.documentIssueStatus(f.get('documents')[0])), 'Awaiting OCR');
  assert.deepEqual(events, [['editing', null], ['refresh']]);
});
