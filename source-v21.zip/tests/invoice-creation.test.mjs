import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
import { createRequire } from 'node:module';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(read(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {}, responsible = {}, statuses = {}, lineTypes = {}, storage = new Map();
new Function('exports', compile('../src/lib/documentProcessingStatus.ts'))(statuses);
new Function('exports', compile('../src/lib/invoiceLineTypes.ts'))(lineTypes);
new Function('exports', 'window', 'require', compile('../src/lib/invoiceCreation.ts'))(core, { localStorage: { getItem: key => storage.get(key) ?? null } }, name => {
  if (name === './documentProcessingStatus') return statuses;
  if (name === './invoiceLineTypes') return lineTypes;
  if (name === './documentResponsibleUsers') return responsible;
  throw Error(name);
});
new Function('exports', compile('../src/lib/documentResponsibleUsers.ts'))(responsible);
const forms = {}, inline = {}, detail = {};
new Function('exports', compile('../src/lib/documentInlineEditing.ts'))(inline);
new Function('exports', 'require', compile('../src/lib/documentDetailEditing.ts'))(detail, name => name === './documentInlineEditing' ? inline : statuses);
new Function('exports', 'require', compile('../src/lib/invoiceDocumentForm.ts'))(forms, name => ({ './invoiceCreation': core, './documentInlineEditing': inline, './documentDetailEditing': detail })[name]);
const copies = {};
new Function('exports', 'require', compile('../src/lib/invoiceCopy.ts'))(copies, name => ({ './invoiceCreation': core, './invoiceDocumentForm': forms })[name]);
const creditNotes = {}, rowActions = {}, creditStorno = {};
new Function('exports', compile('../src/lib/documentStorno.ts'))(creditStorno);
new Function('exports', 'require', compile('../src/lib/documentRowActions.ts'))(rowActions, () => creditStorno);
new Function('exports', 'require', compile('../src/lib/invoiceCreditNote.ts'))(creditNotes, name => ({
  './invoiceCreation': core, './invoiceCopy': copies, './documentRowActions': rowActions, './documentStorno': creditStorno,
})[name]);
const company = { id: 'company-a', name: 'Test company A', base_currency: 'EUR' };
const counterparty = { id: 'party-a', name: 'Test supplier A', company_code: 'TEST-001' };
const invoiceTypes = [
  { code: 'INVOICES', fullName: 'Invoices', parentCode: '', status: 'Active' },
  ...[['INVOICE', 'Invoice'], ['VAT_INVOICE', 'VAT invoice'], ['CREDIT_INVOICE', 'Credit invoice'], ['DEBIT_INVOICE', 'Debit invoice'], ['ADVANCE_INVOICE', 'Advance invoice'], ['VAT_ADVANCE_INVOICE', 'VAT advance invoice'], ['OTHER_INVOICE_DOCUMENT', 'Other document (insurance policies, receipts, permits, declarations, notices, etc.)']]
    .map(([code, fullName]) => ({ code, fullName, parentCode: 'INVOICES', status: 'Active' })),
];
const context = { company, counterparty, invoiceTypes, allowed: true, actor: 'Test accountant', now: '2026-11-04T10:00:00Z', responsible: { accountable_responsible: '', accountable_responsible_id: '' } };
const warehouseDomain = {}, extras = {};
new Function('exports', compile('../src/lib/warehouse.ts'))(warehouseDomain);
let storedWarehouse = null, canViewWarehouse = true, warehouseLoads = 0;
new Function('exports', 'require', 'localStorage', compile('../src/lib/invoiceLineExtras.ts'))(extras, name => {
  if (name === './invoiceCreation') return core;
  if (name === './warehouse') return warehouseDomain;
  if (name === './warehouseStore') return { warehousePermissions: () => ({ view: canViewWarehouse }), warehouseStorageKey: id => id, loadWarehouse: () => { warehouseLoads++; return storedWarehouse; } };
  throw Error(name);
}, { getItem: () => storedWarehouse ? '{}' : null });
function command(patch = {}) {
  return { requestId: 'test-invoice-0001', attachments: [], draft: { ...core.newInvoiceDraft('2026-11-04'), number: 'TEST-INV-001', counterpartyId: counterparty.id,
    lines: [{ ...core.newInvoiceLine('line-1'), description: 'Test service', quantity: '2', price: '50', glAccount: '6300', vatClassifier: 'PVM1' }], ...patch } };
}

const creditSource = { id: 'source-purchase', company_id: company.id, number: 'PUR-2026-001', document_type: 'INVOICES', document_subtype: 'VAT_INVOICE',
  type: 'Purchase', document_purpose: 'Office supplies', status: 'Approved', counterparty_id: counterparty.id, client_counterparty: counterparty.name,
  counterparty_code: counterparty.company_code, total_amount: '121.00', currency: 'EUR', document_date: '2026-10-01' };

test('credit document choices isolate company and Purchase/Sale and exclude invalid originals', () => {
  const sale = { ...creditSource, id: 'source-sale', type: 'Sale', document_purpose: 'Sale' };
  const rows = [creditSource, sale, { ...creditSource, id: 'other-company', company_id: 'other' },
    ...[{ inactive: true }, { active: false }, { is_active: false }, { status: 'Inactive' }, { status: 'Cancelled' },
      { accounting_storno: {} }, { document_storno: { mode: 'test' } }, { document_type: 'CONTRACTS' }, { document_subtype: 'CREDIT_INVOICE' },
      { total_amount: '-121' }, { total_amount: '0' }, { total_amount: 'Infinity' }, { number: '' }, { type: 'Unknown' }]
      .map((patch, index) => ({ ...creditSource, ...patch, id: `excluded-${index}` }))];
  const before = structuredClone(rows);
  assert.deepEqual(core.invoiceCreditSources(rows, company.id, 'Purchase').map(row => row.id), [creditSource.id]);
  assert.deepEqual(core.invoiceCreditSources(rows, company.id, 'Sale').map(row => row.id), [sale.id]);
  assert.deepEqual(core.invoiceCreditSources(rows, '', 'Purchase'), []);
  assert.deepEqual(rows, before);
  assert.deepEqual(core.invoiceCreditSources([{ ...creditSource, type: '', document_purpose: 'Purchase', total_amount: '1 234,56' }], company.id, 'Purchase').map(row => row.id), [creditSource.id]);
});

test('changing the purpose or leaving Credit clears the original selection without changing line data', () => {
  const draft = command({ kind: 'CREDIT_INVOICE', creditSourceDocumentId: creditSource.id }).draft;
  assert.equal(core.updateInvoiceClassification(draft, { purpose: 'Sale' }).creditSourceDocumentId, '');
  assert.equal(core.updateInvoiceClassification(draft, { kind: 'INVOICE' }).creditSourceDocumentId, '');
  assert.equal(core.updateInvoiceClassification(draft, { purpose: 'Purchase' }).creditSourceDocumentId, creditSource.id);
  assert.equal(core.updateInvoiceClassification(draft, { kind: 'Credit note' }).creditSourceDocumentId, creditSource.id);
  assert.deepEqual(core.updateInvoiceClassification(draft, { purpose: 'Sale' }).lines, draft.lines);
});

test('credit source selection uses the matching company counterparty and saves a durable link with audit, not a settlement', () => {
  assert.equal(core.invoiceCreditCounterparty(creditSource, [counterparty]).id, counterparty.id);
  assert.equal(core.invoiceCreditCounterparty({ ...creditSource, counterparty_id: 'legacy' }, [counterparty]).id, counterparty.id);
  assert.equal(core.invoiceCreditCounterparty(creditSource, [{ id: 'other', name: counterparty.name }]), undefined);
  for (const purpose of ['Purchase', 'Sale']) {
    const source = { ...creditSource, type: purpose, document_purpose: purpose }, before = structuredClone(source);
    const saved = core.prepareInvoiceDocument(command({ purpose, kind: 'CREDIT_INVOICE', creditSourceDocumentId: source.id }), { ...context, documents: [source] });
    assert.equal(saved.correction_of_document_id, source.id);
    assert.equal(saved.correction_kind, 'Credit note');
    assert.equal(saved.correction_history[0].originalDocumentId, source.id);
    assert.equal(saved.correction_history[0].actor, context.actor);
    assert.match(saved.correction_history[0].details, /PUR-2026-001/);
    assert.equal(saved.total_amount, '-121.00');
    assert.equal(saved.status, 'Draft');
    assert.equal(saved.accounting_posting, undefined);
    assert.equal(saved.reconciliation, undefined);
    assert.deepEqual(source, before);
  }
});

test('saving a selected credit original revalidates purpose, company, existence, active state and counterparty', () => {
  const input = command({ kind: 'CREDIT_INVOICE', creditSourceDocumentId: creditSource.id });
  assert.throws(() => core.prepareInvoiceDocument(input, context), /no longer available/);
  for (const patch of [{ company_id: 'other' }, { type: 'Sale' }, { inactive: true }, { total_amount: '-1' }, { document_subtype: 'CREDIT_INVOICE' }]) {
    assert.throws(() => core.prepareInvoiceDocument(input, { ...context, documents: [{ ...creditSource, ...patch }] }), /no longer available/);
  }
  assert.throws(() => core.prepareInvoiceDocument({ ...input, draft: { ...input.draft, kind: 'INVOICE' } }, { ...context, documents: [creditSource] }), /no longer available/);
  assert.throws(() => core.prepareInvoiceDocument(input, { ...context, documents: [{ ...creditSource, counterparty_id: 'other', counterparty_code: 'OTHER' }] }), /counterparty must match/);
  assert.equal(core.prepareInvoiceDocument(command({ kind: 'CREDIT_INVOICE' }), context).correction_of_document_id, undefined);
});

test('credit selector uses the system dropdown, company-scoped load, and appears only for credit invoices', () => {
  const form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.match(form, /supabase\.from\('documents'\)\.select\('\*'\)\.eq\('company_id', companyId\)/);
  assert.match(form, /\{isCreditInvoiceKind\(draft.kind\) &&/);
  assert.match(form, /<SearchableSelect ariaLabel=\{creditNoteSourceDocumentId \? 'Original invoice' : 'Document to reconcile'\}/);
  assert.match(form, /invoiceCreditSources\(documents, companyId, draft.purpose\)/);
  assert.match(form, /updateInvoiceClassification\(previous, \{ purpose: value \}\)/);
  assert.match(form, /updateInvoiceClassification\(previous, \{ kind: value \}\)/);
  assert.match(form, /onChange=\{selectCreditDocument\}/);
});

test('accounting-currency columns use document FX, cent-rounded net amounts and credit signs without changing inputs', () => {
  const input = command({ currency: 'USD', exchangeRate: '0,92' });
  input.draft.lines[0].discount = '10';
  const before = structuredClone(input);
  assert.deepEqual(extras.invoiceAccountingCurrency(input.draft.lines[0], input.draft, 'EUR'), { amount: 8280, unitPrice: 46 });
  assert.deepEqual(input, before);
  assert.equal(extras.invoiceAccountingCurrency(input.draft.lines[0], { ...input.draft, kind: 'CREDIT_INVOICE' }, 'EUR').amount, -8280);
  assert.equal(extras.invoiceAccountingCurrency(input.draft.lines[0], { ...input.draft, currency: 'EUR', exchangeRate: '' }, 'EUR').amount, 9000);
  for (const exchangeRate of ['', '0', '-1', 'NaN', '1e2', '0x10']) assert.equal(extras.invoiceAccountingCurrency(input.draft.lines[0], { ...input.draft, exchangeRate }, 'EUR'), null);
  assert.equal(extras.invoiceAccountingCurrency({ ...input.draft.lines[0], price: '' }, input.draft, 'EUR'), null);
});

test('warehouse options require actual company-scoped available data and do not seed examples', () => {
  storedWarehouse = null; warehouseLoads = 0; canViewWarehouse = true;
  assert.equal(extras.loadInvoiceWarehouse(company), null);
  assert.equal(warehouseLoads, 0);
  storedWarehouse = warehouseDomain.createWarehouseExamples(company.id);
  canViewWarehouse = false;
  assert.equal(extras.loadInvoiceWarehouse(company), null);
  assert.equal(warehouseLoads, 0);
  canViewWarehouse = true;
  assert.equal(extras.loadInvoiceWarehouse(company), storedWarehouse);
  const productLines = [{ ...command().draft.lines[0], type: 'Product', itemCode: storedWarehouse.items[0].code }];
  const keys = ['warehouseId', 'stockQuantity', 'costPrice', 'costAmount', 'profit'];
  for (const data of [null, warehouseDomain.emptyWarehouse(company.id), warehouseDomain.createWarehouseExamples('another-company')]) {
    const snapshot = extras.invoiceWarehouseSnapshot(data, company.id, '2026-11-04', 'EUR');
    assert.ok(keys.every(key => !extras.invoiceWarehouseColumnAvailable(key, snapshot)));
  }
  const beforePostings = extras.invoiceWarehouseSnapshot(storedWarehouse, company.id, '2026-09-01', 'EUR');
  assert.equal(extras.invoiceWarehouseColumnAvailable('warehouseId', beforePostings, productLines), true);
  assert.equal(extras.invoiceWarehouseColumnAvailable('stockQuantity', beforePostings, productLines), false);
  const current = extras.invoiceWarehouseSnapshot(storedWarehouse, company.id, '2026-11-04', 'EUR');
  assert.ok(keys.every(key => extras.invoiceWarehouseColumnAvailable(key, current, productLines)));
  for (const lines of [[], [{ ...productLines[0], type: 'Service' }], [{ ...productLines[0], itemCode: 'unknown-product' }]]) assert.ok(keys.every(key => !extras.invoiceWarehouseColumnAvailable(key, current, lines)), 'service-only or non-stocked invoices have no warehouse fields');
  const unsupportedBase = extras.invoiceWarehouseSnapshot(storedWarehouse, company.id, '2026-11-04', 'USD');
  assert.equal(extras.invoiceWarehouseColumnAvailable('stockQuantity', unsupportedBase, productLines), true);
  assert.equal(extras.invoiceWarehouseColumnAvailable('costPrice', unsupportedBase, productLines), false);
  const inactive = structuredClone(storedWarehouse); inactive.locations.forEach(row => { row.inactive = true; });
  const unavailable = extras.invoiceWarehouseSnapshot(inactive, company.id, '2026-11-04', 'EUR');
  assert.ok(keys.every(key => !extras.invoiceWarehouseColumnAvailable(key, unavailable)));
});

test('stock and cost values match product and warehouse, use posting date and never create movements', () => {
  const store = warehouseDomain.createWarehouseExamples(company.id), before = structuredClone(store);
  const snapshot = extras.invoiceWarehouseSnapshot(store, company.id, '2026-11-04', 'EUR');
  const input = command({ purpose: 'Sale', currency: 'USD', exchangeRate: '0.92' });
  const line = { ...input.draft.lines[0], type: 'Product', itemCode: store.items[0].code, warehouseId: store.locations[0].id };
  const balance = snapshot.balances.find(row => row.itemId === store.items[0].id && row.warehouseId === line.warehouseId);
  const result = extras.invoiceLineStock(line, input.draft, snapshot, 'EUR');
  assert.equal(result.stockQuantity, balance.quantity);
  assert.equal(result.costPrice, balance.unitCost);
  assert.equal(result.costAmount, Math.round(balance.unitCost * 2 * 100));
  assert.equal(result.profit, 9200 - result.costAmount);
  assert.equal(extras.invoiceLineStock(line, { ...input.draft, purpose: 'Purchase' }, snapshot, 'EUR').profit, null);
  const credit = extras.invoiceLineStock(line, { ...input.draft, kind: 'CREDIT_INVOICE' }, snapshot, 'EUR');
  assert.equal(credit.profit, -result.profit);
  for (const patch of [{ itemCode: 'unknown' }, { warehouseId: 'other-company' }, { itemCode: '' }]) assert.equal(extras.invoiceLineStock({ ...line, ...patch }, input.draft, snapshot, 'EUR'), null);
  assert.equal(extras.invoiceLineStock({ ...line, type: 'Service' }, input.draft, snapshot, 'EUR'), null);
  assert.deepEqual(store, before);
});

test('optional item code and warehouse persist on both line views and cannot reference another company or inactive warehouse', () => {
  const warehouse = warehouseDomain.createWarehouseExamples(company.id), input = command();
  input.draft.lines[0] = { ...input.draft.lines[0], type: 'Product', itemCode: ` ${warehouse.items[0].code} `, warehouseId: warehouse.locations[0].id, code: 'KEEP-DOC-NUMBER' };
  input.draft.allocations = [{ ...input.draft.lines[0] }];
  const saved = core.prepareInvoiceDocument(input, { ...context, warehouse });
  for (const row of [saved.line_items[0], saved.summary_line_items[0]]) {
    assert.equal(row.item_code, warehouse.items[0].code);
    assert.equal(row.stock_item_id, warehouse.items[0].id);
    assert.equal(row.warehouse_id, warehouse.locations[0].id);
    assert.equal(row.code, 'KEEP-DOC-NUMBER');
    assert.equal(row.line_number, 1);
    assert.equal(row.cost_amount, undefined, 'derived stock and pricing values are not stale persisted amounts');
  }
  for (const other of [null, warehouseDomain.createWarehouseExamples('another-company'), { ...warehouse, locations: warehouse.locations.map(row => ({ ...row, inactive: true })) }]) assert.throws(() => core.prepareInvoiceDocument(input, { ...context, warehouse: other }), /active Warehouse/);
  assert.match(read('../src/lib/supabase.ts'), /warehouse: loadInvoiceWarehouse\(company\)/, 'save re-reads current warehouse references');
  input.draft.lines[0].type = 'Service';
  assert.throws(() => core.prepareInvoiceDocument(input, { ...context, warehouse }), /stocked Product/);
});

test('totals hide zero discounts and duplicate currency summaries, converting only foreign-currency totals', () => {
  const draft = command().draft;
  assert.deepEqual(core.invoiceTotalsPresentation(draft, 'EUR'), { rows: [{ label: 'Subtotal excl. VAT', amount: 10000 }, { label: 'VAT amount', amount: 2100 }], amountDue: 12100, accounting: null });
  const discounted = { ...draft, currency: 'USD', exchangeRate: '0.92', lines: [{ ...draft.lines[0], discount: '10' }] };
  const result = core.invoiceTotalsPresentation(discounted, 'EUR');
  assert.deepEqual(result.rows, [{ label: 'Subtotal excl. VAT', amount: 10000 }, { label: 'Discount', amount: -1000 }, { label: 'VAT amount', amount: 1890 }]);
  assert.equal(result.accounting.total, 10019);
  assert.equal(result.amountDue, 10890);
  assert.equal(core.invoiceTotalsPresentation({ ...discounted, kind: 'CREDIT_INVOICE' }, 'EUR').accounting.total, -10019);
  assert.equal(core.invoiceTotalsPresentation({ ...discounted, exchangeRate: '' }, 'EUR').accounting.total, null);
  assert.equal(core.invoiceTotalsPresentation({ ...discounted, includeVatInDebt: false }, 'EUR').amountDue, 9000);
});

test('rendered totals contain one main summary and only a foreign-currency extra total', () => {
  const view = {}, require = createRequire(import.meta.url);
  const compiled = ts.transpileModule(read('../src/components/invoices/InvoiceTotalsSummary.tsx'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX } }).outputText;
  new Function('exports', 'require', compiled)(view, name => name === '../../lib/invoiceCreation' ? core : require(name));
  const render = draft => renderToStaticMarkup(createElement(view.default, { draft, baseCurrency: 'EUR' }));
  const local = render(command().draft);
  assert.ok(local.includes('Subtotal excl. VAT') && local.includes('VAT amount') && local.includes('Amount due'));
  assert.ok(!local.includes('Discount') && !local.includes('Accounting currency total'));
  const foreign = render(command({ currency: 'USD', exchangeRate: '0.92' }).draft);
  assert.equal((foreign.match(/Subtotal excl. VAT/g) || []).length, 1);
  assert.equal((foreign.match(/Accounting currency total/g) || []).length, 1);
  assert.ok(foreign.includes('111.32 EUR'));
});

test('additional dimensions are company-specific and only expose configured, nonduplicate document fields', () => {
  const lookups = [
    { type: 'object_project::company::company-a', value: 'PROJECT-1' },
    { type: 'analytical_series::company::company-a', value: 'AN-1' },
    { type: 'main_analytical_account::company::company-a', value: '6202' },
    { type: 'related_contract::company::company-a', value: 'CONTRACT-1' },
    { type: 'related_contract::company::company-a', value: 'OFF', inactive: true },
    { type: 'department_code::company::company-a', value: 'OPS' },
    { type: 'object_project::company::company-b', value: 'OTHER-COMPANY' },
  ];
  assert.equal(core.invoiceDocumentAnalytics(company.id, [], command().draft).length, 0);
  const fields = core.invoiceDocumentAnalytics(company.id, lookups, command().draft);
  assert.deepEqual(fields.map(field => field.label), ['Object / Project', 'Analytical series', 'Main analytical account', 'Related contract']);
  assert.ok(!JSON.stringify(fields).includes('OTHER-COMPANY') && !JSON.stringify(fields).includes('OFF'));
  const kept = core.invoiceDocumentAnalytics(company.id, [], { ...command().draft, analyticalSeries: 'Retain my selection' });
  assert.equal(kept[0].options[1].value, 'Retain my selection');
});

test('sales manager and document analytics persist separately; purchases omit sales-only metadata', async () => {
  const input = command({ purpose: 'Sale', customerManagerId: 'internal-a', language: 'LT', analyticalSeries: 'AN-1', mainAnalyticalAccount: '6202', relatedContract: 'CONTRACT-1', project: 'PROJECT-1' });
  const saved = await fixture().createInvoiceDocument(company.id, input);
  assert.equal(saved.invoice_customer_manager_id, 'internal-a');
  assert.equal(saved.invoice_customer_manager, 'Test accountant');
  assert.equal(saved.invoice_language, 'LT');
  assert.equal(saved.analytical_series, 'AN-1');
  assert.equal(saved.main_analytical_account, '6202');
  assert.equal(saved.related_contract, 'CONTRACT-1');
  assert.equal(saved.object_project, 'PROJECT-1');
  assert.equal(saved.line_items[0].analytical_series, '', 'document analytics are not copied into lines');
  const purchase = await fixture().createInvoiceDocument(company.id, { ...input, draft: { ...input.draft, purpose: 'Purchase' } });
  assert.equal(purchase.invoice_customer_manager_id, '');
  assert.equal(purchase.invoice_customer_manager, '');
  assert.equal(purchase.invoice_language, '');
  const blocked = fixture(); blocked.deactivateUser();
  await assert.rejects(blocked.createInvoiceDocument(company.id, input), /active user/);
  await assert.rejects(fixture().createInvoiceDocument(company.id, { ...input, draft: { ...input.draft, language: 'INVALID' } }), /Invoice language/);
});

test('additional and attachments start collapsed, with one notes field, sales-only fields and preview controls', () => {
  const form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.match(form, /new Set\(\['basic', 'parties', 'dates', 'defaults', 'lines', 'totals'\]\)/);
  const additional = form.slice(form.indexOf('<Section number={7}'), form.indexOf('<Section number={8}'));
  assert.match(additional, /draft\.purpose === 'Sale'.*<>/);
  assert.ok(additional.includes('Customer manager') && additional.includes('Invoice language') && additional.includes('Accountable / Responsible person'));
  assert.deepEqual([...additional.matchAll(/<Field label="([^"]+)"/g)].map(match => match[1]), ['Accountable / Responsible person', 'Customer manager', 'Invoice language']);
  assert.ok(!additional.includes('documentAnalytics'));
  for (const label of ['Order No.', 'Series', 'Invoice date', 'Operation date', 'GL account', 'VAT classifier', 'Notes']) assert.ok(!additional.includes(`label="${label}"`));
  assert.equal((form.match(/<textarea aria-label="Notes"/g) || []).length, 1);
  assert.ok(form.includes('Upload attachment') && form.includes('Preview attachment') && form.includes('InvoiceAttachmentPreview'));
  const preview = read('../src/components/invoices/InvoiceAttachmentPreview.tsx');
  assert.match(preview, /URL\.revokeObjectURL/);
  assert.match(preview, /event\.stopPropagation\(\)/);
  assert.match(preview, /file\.type === 'application\/pdf'.*<iframe.*<img/);
});

test('amounts use line-level cent rounding, percentages and discounts, not percentage multiples', () => {
  const line = command().draft.lines[0];
  assert.deepEqual(core.invoiceLineAmounts(line), { valid: true, gross: 10000, discount: 0, net: 10000, vat: 2100, total: 12100 });
  assert.deepEqual(core.invoiceLineAmounts({ ...line, quantity: '2', price: '750', discount: '5' }), { valid: true, gross: 150000, discount: 7500, net: 142500, vat: 29925, total: 172425 });
  assert.equal(core.invoiceLineAmounts({ ...line, quantity: '1', price: '0,05', vatRate: '21' }).total, 6);
  assert.equal(core.invoiceLineAmounts({ ...line, vatRate: '0' }).vat, 0);
  for (const patch of [{ quantity: '0' }, { quantity: '-1' }, { price: '' }, { price: '-2' }, { price: 'NaN' }, { discount: '101' }, { vatRate: '101' }, { price: '999999999999999999999999' }]) assert.equal(core.invoiceLineAmounts({ ...line, ...patch }).valid, false);
});

test('Document lines controls support monetary discount and VAT corrections, resetting manual VAT after base edits', () => {
  const line = { ...command().draft.lines[0], discountAmount: '10', vatAmount: '18.91' };
  assert.deepEqual(core.invoiceLineAmounts(line), { valid: true, gross: 10000, discount: 1000, net: 9000, vat: 1891, total: 10891 });
  for (const patch of [{ price: '60' }, { quantity: '3' }, { vatRate: '9' }, { discountAmount: '5' }]) assert.equal(core.updateInvoiceLine(line, patch).vatAmount, undefined);
  assert.equal(core.updateInvoiceLine(line, { department: 'OPS' }).vatAmount, '18.91');
  assert.equal(core.invoiceLineAmounts({ ...line, discountAmount: '101' }).valid, false);
  assert.equal(core.invoiceLineAmounts({ ...line, vatAmount: '-1' }).valid, false);
});

test('the single invoice table offers five optional pricing columns and Description follows Code / Name', () => {
  const design = {};
  new Function('exports', compile('../src/components/documentLineDesign.ts'))(design);
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx');
  const compiled = ts.transpileModule(editor, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX } }).outputText;
  const defaults = new Function('exports', 'require', `${compiled}\nreturn defaults;`)({}, path => path === '../documentLineDesign' ? design : {});
  const header = editor.match(/role="columnheader" key=\{column.key\} className="([^"]+)"/);
  assert.ok(header, 'all columns use one static header class');
  assert.match(header[1], /\bpx-2\b/, 'headers share the input text inset');
  const labels = ['Discount %', 'Discount amount', 'Unit price incl. VAT', 'Discounted unit price', 'Amount after discount excl. VAT'];
  {
    const columns = defaults();
    assert.equal(new Set(columns.map(column => column.key)).size, columns.length, 'no duplicate discount columns');
    for (const label of labels) {
      const column = columns.find(column => column.label === label);
      assert.ok(column, label);
      assert.equal(column.visible, false, `${label} is opt-in through Column settings`);
    }
    const visible = columns.filter(column => column.visible).map(column => column.label);
    assert.equal(columns[0].key, 'systemId', 'System ID comes first in Column settings');
    assert.equal(visible[0], 'System ID', 'System ID is the first visible data column');
    assert.equal(columns.filter(column => column.key === 'systemId').length, 1);
    assert.ok(!columns.some(column => column.key === 'code' || column.label === 'Document Number'), 'Document Number is absent from the table and Column settings');
    assert.equal(visible[visible.indexOf('Code / Name') + 1], 'Description');
    assert.ok(!columns.some(column => column.label === 'Discount'), 'replace the generic Discount column, do not duplicate it');
  }
  assert.match(editor, /if \(key === 'vatRate' \|\| key === 'discount'\).*<input/);
  assert.match(editor, /if \(key === 'unitPriceInclVat' \|\| key === 'discountedUnitPrice' \|\| key === 'amountAfterDiscountExclVat'\).*<output/);
});

test('optional pricing derives discounted prices without changing authoritative rounded line totals', () => {
  const line = { ...command().draft.lines[0], quantity: '2', price: '750', discount: '5' };
  const before = structuredClone(line);
  assert.deepEqual(core.invoiceLinePricing(line), { discountPercent: 5, unitPriceInclVat: 907.5, discountedUnitPrice: 712.5, amountAfterDiscountExclVat: 1425 });
  assert.deepEqual(line, before);
  assert.equal(core.invoiceLineAmounts(line).total, 172425);
  assert.equal(core.invoiceLinePricing({ ...line, vatRate: '0' }).unitPriceInclVat, 750);
  assert.equal(core.invoiceLinePricing({ ...line, discount: '100' }).discountedUnitPrice, 0);
  assert.equal(core.invoiceLinePricing({ ...line, price: '0', discountAmount: '0' }).discountPercent, 0);
  const fractional = core.invoiceLinePricing({ ...line, quantity: '1.5', price: '10', discount: '10' });
  assert.equal(fractional.discountedUnitPrice, 9);
  assert.equal(fractional.amountAfterDiscountExclVat, 13.5);
  const small = { ...line, quantity: '3', price: '0.05', discount: '0', discountAmount: '0.01' };
  assert.equal(core.invoiceLineAmounts(small).net, 14);
  assert.ok(Math.abs(core.invoiceLinePricing(small).discountedUnitPrice - 0.04666666666666667) < 1e-12);
  for (const patch of [{ price: '' }, { quantity: '0' }, { discount: '101' }, { discountAmount: '1501' }]) assert.equal(core.invoiceLinePricing({ ...line, ...patch }), null);
});

test('the invoice table exposes grouped optional metadata, currency and conditional warehouse columns, hidden by default', () => {
  const design = {};
  new Function('exports', compile('../src/components/documentLineDesign.ts'))(design);
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx');
  const compiled = ts.transpileModule(editor, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX } }).outputText;
  const defaults = new Function('exports', 'require', `${compiled}\nreturn defaults;`)({}, path => path === '../documentLineDesign' ? design : {});
  const columns = defaults();
  const groups = {
    'Items / Services': ['Line No.', 'Item / Service code', 'Unit of measure', 'Barcode', 'Product group'],
    'Prices / Discounts': ['Discount %', 'Discount amount', 'Unit price incl. VAT', 'Discounted unit price', 'Amount after discount excl. VAT'],
    'Accounting / Analytics': ['Line note / Comment', 'Analytical series', 'Main analytical account', 'Employee / Responsible person', 'Center', 'Related contract'],
    'Currency': ['Amount in accounting currency', 'Unit price in accounting currency'],
    'Warehouse / Cost': ['Warehouse', 'Stock quantity', 'Cost price', 'Cost amount', 'Profit'],
  };
  for (const [group, labels] of Object.entries(groups)) for (const label of labels) {
    const matches = columns.filter(column => column.label === label);
    assert.equal(matches.length, 1, `${label} appears once`);
    assert.equal(matches[0].visible, false, `${label} is opt-in`);
    assert.equal(matches[0].group, group);
  }
  assert.equal(new Set(columns.map(column => column.key)).size, columns.length);
  assert.equal(columns[columns.findIndex(column => column.key === 'name') + 1].key, 'description');
  assert.match(editor, /availableColumns = columns\.filter.*invoiceWarehouseColumnAvailable/);
  assert.match(editor, /key === 'responsibleId'.*responsibleOptions/);
  assert.match(editor, /key === 'mainAnalyticalAccount'.*glOptions/);
  assert.match(read('../src/components/invoices/CreateInvoiceForm.tsx'), /responsibleOptions=\{users\}/);
});

test('Summary metadata persists separately from description and invoice series, including line-level responsible users', async () => {
  const input = command({ responsibleId: '' });
  input.draft.allocations = [{ ...input.draft.lines[0], barcode: '0123456789012', description: 'Accounting allocation', series: 'INV',
    lineNote: '  Internal allocation comment  ', analyticalSeries: '  ANA-2026  ', mainAnalyticalAccount: '  6202  ', responsibleId: 'internal-a', costCenter: 'CENTER-A', relatedContract: '  CONTRACT-2026-01  ' }];
  const f = fixture(), saved = await f.createInvoiceDocument(company.id, input);
  const row = saved.summary_line_items[0];
  assert.equal(row.barcode, '0123456789012');
  assert.equal(row.description, 'Accounting allocation');
  assert.equal(row.line_note, 'Internal allocation comment');
  assert.equal(row.series, 'INV');
  assert.equal(row.analytical_series, 'ANA-2026');
  assert.equal(row.main_analytical_account, '6202');
  assert.equal(row.accountable_responsible_id, 'internal-a');
  assert.equal(row.accountable_responsible, 'Test accountant');
  assert.equal(row.center, 'CENTER-A');
  assert.equal(row.related_contract, 'CONTRACT-2026-01');
  assert.equal(saved.line_items[0].line_note, '');
  assert.equal(saved.line_items[0].accountable_responsible_id, '');
  assert.equal(saved.accountable_responsible_id, '');
  assert.equal(saved.total_amount, '121.00');
  assert.deepEqual(f.get('documents').at(-1).summary_line_items[0], row);
  const split = core.splitInvoiceLines(input.draft.lines, input.draft.allocations, 'equal', {});
  for (const key of ['barcode', 'lineNote', 'analyticalSeries', 'mainAnalyticalAccount', 'responsibleId', 'costCenter', 'relatedContract']) assert.equal(split[0][key], input.draft.allocations[0][key]);
  assert.deepEqual(core.invoiceLineAmounts(core.updateInvoiceLine(input.draft.lines[0], { lineNote: 'Note' })), core.invoiceLineAmounts(input.draft.lines[0]));
});

test('line responsible person inherits the document default, permits explicit clearing and rejects inactive or unknown users', async () => {
  const inherited = await fixture().createInvoiceDocument(company.id, command({ responsibleId: 'internal-a' }));
  assert.equal(inherited.summary_line_items[0].accountable_responsible_id, 'internal-a');
  const clear = command({ responsibleId: 'internal-a' });
  clear.draft.allocations = [{ ...clear.draft.lines[0], responsibleId: '' }];
  const cleared = await fixture().createInvoiceDocument(company.id, clear);
  assert.equal(cleared.summary_line_items[0].accountable_responsible_id, '');
  assert.equal(cleared.line_items[0].accountable_responsible_id, 'internal-a');
  for (const responsibleId of ['external-person', 'missing', null, 0]) {
    const input = command(); input.draft.allocations = [{ ...input.draft.lines[0], responsibleId }];
    await assert.rejects(fixture().createInvoiceDocument(company.id, input), /Internal Users|Responsible person/);
  }
  const blocked = fixture(), input = command();
  input.draft.allocations = [{ ...input.draft.lines[0], responsibleId: 'internal-a' }];
  blocked.deactivateUser();
  await assert.rejects(blocked.createInvoiceDocument(company.id, input), /active user/);
  assert.equal(blocked.get('documents').length, 1);
});

test('invalid Summary note and reference values cannot be persisted', () => {
  for (const [key, label, length] of [['lineNote', 'Line note', 2000], ['analyticalSeries', 'Analytical series', 100], ['mainAnalyticalAccount', 'Main analytical account', 100], ['relatedContract', 'Related contract', 200]]) {
    for (const value of [null, 123, 'x'.repeat(length + 1)]) {
      const input = command(); input.draft.allocations = [{ ...input.draft.lines[0], [key]: value }];
      assert.throws(() => core.prepareInvoiceDocument(input, context), new RegExp(label));
    }
  }
});

test('editing discount percent or amount replaces the other basis and recalculates VAT once', () => {
  const original = { ...command().draft.lines[0], vatAmount: '20.99' };
  const percent = core.updateInvoiceLine(original, { discount: '10' });
  assert.equal(percent.discountAmount, undefined);
  assert.equal(percent.vatAmount, undefined);
  assert.equal(core.invoiceLineAmounts(percent).discount, 1000);
  assert.equal(core.invoiceLineAmounts(percent).vat, 1890);
  const amount = core.updateInvoiceLine(percent, { discountAmount: '25' });
  assert.equal(amount.discount, '0');
  assert.equal(core.invoiceLinePricing(amount).discountPercent, 25);
  assert.equal(core.invoiceLineAmounts(amount).net, 7500);
  assert.equal(core.invoiceLineAmounts(amount).vat, 1575);
  const backToPercent = core.updateInvoiceLine(amount, { discount: '5' });
  assert.equal(backToPercent.discountAmount, undefined);
  assert.equal(core.invoiceLineAmounts(backToPercent).net, 9500);
  assert.equal(core.invoiceLinePricing(backToPercent).discountedUnitPrice, 47.5);
  const changedQuantity = core.updateInvoiceLine(amount, { quantity: '4' });
  assert.equal(core.invoiceLinePricing(changedQuantity).discountPercent, 12.5);
  assert.equal(core.invoiceLineAmounts(changedQuantity).discount, 2500);
  assert.equal(original.vatAmount, '20.99');
});

test('optional discount inputs persist their totals for invoices, credit notes and Summary allocations', async () => {
  const input = command();
  input.draft.lines[0] = core.updateInvoiceLine(input.draft.lines[0], { discount: '10' });
  input.draft.allocations = [{ ...input.draft.lines[0], description: 'Allocated service' }];
  const saved = await fixture().createInvoiceDocument(company.id, input);
  assert.equal(saved.line_items[0].discount, '10.00');
  assert.equal(saved.line_items[0].discount_rate, '10');
  assert.equal(saved.summary_line_items[0].subtotal, '90.00');
  assert.equal(saved.total_amount, '108.90');
  const amountInput = command({ kind: 'CREDIT_INVOICE' });
  amountInput.draft.lines[0] = core.updateInvoiceLine(amountInput.draft.lines[0], { discountAmount: '25' });
  const credit = core.prepareInvoiceDocument(amountInput, context);
  assert.equal(credit.line_items[0].discount, '-25.00');
  assert.equal(credit.line_items[0].subtotal, '-75.00');
  assert.equal(credit.total_amount, '-90.75');
  assert.equal(core.invoiceLinePricing(amountInput.draft.lines[0]).unitPriceInclVat, 60.5);
});

test('Description and a row-level Include VAT in debt checkbox are visible in both line views', () => {
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx');
  const form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.match(editor, /key: 'name', label: 'Code \/ Name'[^\n]+\n\s*\{ key: 'description', label: 'Description', width: 170, visible: true \}/);
  assert.match(editor, /column.key === 'vatPct'.*key: 'includeVatInDebt', label: 'Include VAT in debt', width: 150, visible: true/);
  assert.match(editor, /if \(key === 'includeVatInDebt'\).*type="checkbox".*checked=\{invoiceLineIncludesVatInDebt\(line, draft.includeVatInDebt\)\}/);
  assert.match(editor, /includeVatInDebt: event.target.checked/);
  assert.match(form, /amountDue = invoiceAmountDue\(draft\)/);
  assert.match(read('../src/components/invoices/InvoiceTotalsSummary.tsx'), /format\(totals.amountDue, draft.currency\)/);
});

test('line VAT-in-debt overrides inherit the default until changed and never change VAT or invoice totals', () => {
  const draft = command().draft;
  const original = { ...draft.lines[0], vatAmount: '20.99' };
  assert.equal(core.invoiceLineIncludesVatInDebt(original, true), true);
  assert.equal(core.invoiceLineIncludesVatInDebt(original, false), false);
  const excluded = core.updateInvoiceLine(original, { description: 'Travel expense', includeVatInDebt: false });
  assert.equal(excluded.vatAmount, '20.99');
  assert.deepEqual(core.invoiceLineAmounts(excluded), core.invoiceLineAmounts(original));
  assert.equal(core.invoiceLineIncludesVatInDebt(excluded, true), false);
  assert.equal(core.invoiceLineIncludesVatInDebt({ ...original, includeVatInDebt: true }, false), true);
  draft.lines = [excluded, { ...original, id: 'line-2', includeVatInDebt: true }];
  assert.equal(core.invoiceAmountDue(draft), 22099);
  assert.equal(core.invoiceTotals(draft).total, 24198);
  assert.equal(core.invoiceAmountDue({ ...draft, includeVatInDebt: false }), 22099);
  assert.equal(core.invoiceAmountDue({ ...draft, kind: 'CREDIT_INVOICE' }), -22099);
  const zeroVat = { ...original, vatRate: '0', vatAmount: undefined };
  assert.equal(core.invoiceAmountDue({ ...draft, lines: [zeroVat], includeVatInDebt: false }), 10000);
});

test('Summary debt uses its accounting allocations and Split preserves per-line descriptions and VAT choices', () => {
  const draft = command().draft;
  draft.allocations = [
    { ...draft.lines[0], id: 'a1', description: 'Office allocation', quantity: '1', price: '40', includeVatInDebt: false },
    { ...draft.lines[0], id: 'a2', description: 'Sales allocation', quantity: '1', price: '60', includeVatInDebt: true },
  ];
  assert.equal(core.invoiceAllocationError(draft), '');
  assert.equal(core.invoiceAmountDue(draft), 11260);
  assert.equal(core.invoiceTotals(draft).total, 12100);
  const split = core.splitInvoiceLines(draft.lines, draft.allocations, 'equal', {});
  assert.deepEqual(split.map(line => line.includeVatInDebt), [false, true]);
  assert.deepEqual(split.map(line => line.description), ['Office allocation', 'Sales allocation']);
  assert.equal(core.invoiceAmountDue({ ...draft, allocations: split }), 11050);
});

test('saving persists each line description and VAT-in-debt choice, including explicit false', async () => {
  const f = fixture();
  const input = command({ includeVatInDebt: false });
  input.draft.lines = [
    { ...input.draft.lines[0], name: 'CODE-A', description: '  First description  ', includeVatInDebt: true },
    { ...input.draft.lines[0], id: 'line-2', name: 'CODE-B', description: 'Second description' },
  ];
  const saved = await f.createInvoiceDocument(company.id, input);
  for (const key of ['line_items', 'summary_line_items']) {
    assert.deepEqual(saved[key].map(line => line.description), ['First description', 'Second description']);
    assert.deepEqual(saved[key].map(line => line.include_vat_in_debt), [true, false]);
    assert.deepEqual(f.get('documents').at(-1)[key].map(line => line.include_vat_in_debt), [true, false]);
  }
  assert.equal(saved.amount_due, '221.00');
  assert.equal(saved.total_amount, '242.00');
  assert.equal(saved.vat, '42.00');
  assert.equal(saved.include_vat_in_debt, false);
  const separate = command();
  separate.draft.allocations = [{ ...separate.draft.lines[0], description: 'Separate accounting description', includeVatInDebt: false }];
  const prepared = core.prepareInvoiceDocument(separate, context);
  assert.equal(prepared.line_items[0].include_vat_in_debt, true);
  assert.equal(prepared.summary_line_items[0].include_vat_in_debt, false);
  assert.equal(prepared.summary_line_items[0].description, 'Separate accounting description');
  assert.equal(prepared.amount_due, '100.00');
  assert.throws(() => core.prepareInvoiceDocument(command({ includeVatInDebt: 'false' }), context), /Include VAT in debt/);
  for (const includeVatInDebt of ['false', null, 0]) {
    assert.throws(() => core.prepareInvoiceDocument(command({ lines: [{ ...command().draft.lines[0], includeVatInDebt }] }), context), /Include VAT in debt/);
  }
});

test('Summary allocations remain independent from Quantity and preserve accounting dimensions on save', () => {
  const input = command({ department: 'DEFAULT', project: 'PROJECT', costCenter: 'CENTER' });
  const source = { ...input.draft.lines[0], barcode: 'TEST-BARCODE', productGroup: 'Services', series: 'LINE' };
  input.draft.lines = [source];
  input.draft.allocations = [
    { ...source, id: 'a1', quantity: '1', price: '40', department: 'OPS', project: 'P1', costCenter: 'C1', glAccount: '6300' },
    { ...source, id: 'a2', quantity: '1', price: '60', department: 'SALES', project: 'P2', costCenter: 'C2', glAccount: '6202' },
  ];
  assert.equal(core.invoiceAllocationError(input.draft), '');
  const saved = core.prepareInvoiceDocument(input, context);
  assert.equal(saved.line_items.length, 1); assert.equal(saved.summary_line_items.length, 2);
  assert.equal(saved.line_items[0].barcode, 'TEST-BARCODE'); assert.equal(saved.line_items[0].productGroup, 'Services');
  assert.equal(saved.summary_line_items[0].department, 'OPS'); assert.equal(saved.summary_line_items[1].expense, '6202');
  assert.equal(saved.summary_line_items[1].object, 'P2'); assert.equal(saved.summary_line_items[1].center, 'C2');
  assert.equal(saved.total_amount, '121.00'); assert.equal(saved.expense_account, '');
  assert.throws(() => core.prepareInvoiceDocument({ ...input, draft: { ...input.draft, allocations: [{ ...source, price: '51' }] } }, context), /Summary amounts/);
  assert.throws(() => core.prepareInvoiceDocument({ ...input, draft: { ...input.draft, allocations: [] } }, context), /Summary lines/);
  const credit = core.prepareInvoiceDocument({ ...input, draft: { ...input.draft, kind: 'CREDIT_INVOICE' } }, context);
  assert.equal(credit.summary_line_items[0].subtotal, '-40.00'); assert.equal(credit.summary_line_items[1].vat, '-12.60');
  assert.equal(credit.total_amount, '-121.00');
});

test('Split supports equal, percentage and amount modes with exact cents and rejects invalid or mixed-rate splits', () => {
  const source = command().draft.lines;
  const targets = ['a', 'b', 'c'].map(id => ({ ...source[0], id, department: id }));
  for (const [mode, values] of [['equal', {}], ['percent', { a: '33.33', b: '33.33', c: '33.34' }], ['amount', { a: '10', b: '20', c: '70' }]]) {
    const before = structuredClone(source), split = core.splitInvoiceLines(source, targets, mode, values);
    assert.deepEqual(source, before);
    assert.equal(split.reduce((sum, line) => sum + core.invoiceLineAmounts(line).net, 0), 10000);
    assert.equal(split.reduce((sum, line) => sum + core.invoiceLineAmounts(line).vat, 0), 2100);
    assert.deepEqual(split.map(row => row.department), ['a', 'b', 'c']);
    assert.equal(core.invoiceAllocationError({ ...command().draft, allocations: split }), '');
  }
  assert.throws(() => core.splitInvoiceLines(source, targets, 'percent', { a: '30', b: '30', c: '30' }), /100%/);
  assert.throws(() => core.splitInvoiceLines(source, targets, 'amount', { a: '10', b: '20', c: '60' }), /equal/);
  assert.throws(() => core.splitInvoiceLines(source, targets, 'amount', { a: '-1', b: '20', c: '81' }), /non-negative/);
  assert.throws(() => core.splitInvoiceLines([...source, { ...source[0], vatRate: '9' }], targets, 'equal', {}), /Different VAT rates/);
  const small = [{ ...source[0], quantity: '1', price: '0.05', vatRate: '21' }];
  const split = core.splitInvoiceLines(small, targets, 'equal', {});
  assert.equal(split.reduce((sum, row) => sum + core.invoiceLineAmounts(row).total, 0), 6);
  const mixed = command({ lines: [source[0], { ...source[0], id: 'zero', vatRate: '0' }] }).draft;
  mixed.allocations = [{ ...source[0], price: '100', vatAmount: '21' }];
  assert.match(core.invoiceAllocationError(mixed), /each VAT rate/);
});

test('Quantity Split accepts new destinations with the default quantity 1 and a blank price', () => {
  const priced = { ...core.newInvoiceLine('priced'), name: 'Consulting', price: '100' };
  const blank = { ...core.newInvoiceLine('destination'), name: 'Second allocation', department: 'SALES' };
  assert.equal(blank.quantity, '1');
  const source = [priced, blank], before = structuredClone(source);
  for (const [mode, values] of [['equal', {}], ['percent', { priced: '25', destination: '75' }], ['amount', { priced: '40', destination: '60' }]]) {
    const result = core.splitInvoiceLines(source, source, mode, values, { allowUnpricedTargets: true });
    assert.equal(result.reduce((sum, row) => sum + core.invoiceLineAmounts(row).net, 0), 10000);
    assert.equal(result.reduce((sum, row) => sum + core.invoiceLineAmounts(row).vat, 0), 2100);
    assert.ok(result.every(row => row.quantity === '1' && core.invoiceLineAmounts(row).valid));
    assert.equal(result[1].name, blank.name);
    assert.equal(result[1].department, blank.department);
  }
  assert.deepEqual(source, before);
  const repeated = core.splitInvoiceLines(source, source, 'equal', {}, { allowUnpricedTargets: true });
  assert.deepEqual(core.splitInvoiceLines(repeated, repeated, 'equal', {}, { allowUnpricedTargets: true }), repeated);
  // A blank destination's default VAT must not override the actual source's rate.
  const lowerRate = [{ ...priced, vatRate: '9' }, blank];
  assert.ok(core.splitInvoiceLines(lowerRate, lowerRate, 'equal', {}, { allowUnpricedTargets: true }).every(row => row.vatRate === '9'));
  // Blank rows can appear before or after the priced source.
  assert.equal(core.splitInvoiceLines([blank, priced], [blank, priced], 'equal', {}, { allowUnpricedTargets: true })[0].price, '50.00');
});

test('Split reports the actual invalid field without weakening Summary or save validation', () => {
  const priced = { ...core.newInvoiceLine('priced'), price: '100' }, blank = core.newInvoiceLine('blank');
  assert.throws(() => core.splitInvoiceLines([blank], [blank], 'equal', {}, { allowUnpricedTargets: true }), /Enter a Price on at least one Quantity line/);
  assert.throws(() => core.splitInvoiceLines([priced, blank], [priced, blank], 'equal', {}), /Quantity line 2: enter a valid Price/);
  assert.throws(() => core.splitInvoiceLines([priced, blank], [priced], 'equal', {}, { allowUnpricedTargets: true }), /Quantity line 2: enter a valid Price/);
  for (const [patch, message] of [
    [{ quantity: '0' }, /Quantity greater than zero/], [{ quantity: '' }, /Quantity greater than zero/],
    [{ price: 'invalid' }, /valid Price/], [{ price: '-1' }, /valid Price/],
    [{ discount: '101' }, /Discount %/], [{ vatRate: '' }, /VAT %/],
    [{ discountAmount: '1' }, /Discount amount/], [{ vatAmount: '-1' }, /VAT amount/],
    [{ vatAmount: '21' }, /enter a Price before splitting a line with a VAT amount/],
  ]) {
    const source = [priced, { ...blank, ...patch }];
    assert.throws(() => core.splitInvoiceLines(source, source, 'equal', {}, { allowUnpricedTargets: true }), message);
  }
  assert.equal(core.invoiceLineAmounts(blank).valid, false, 'blank prices are still invalid outside the split destinations');
  const input = command(); input.draft.lines.push(blank);
  assert.throws(() => core.prepareInvoiceDocument(input, context));
});

test('Invoice lines uses one editable table without Summary / Quantity switches and keeps existing controls', () => {
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx'), form = read('../src/components/invoices/CreateInvoiceForm.tsx'), design = read('../src/components/documentLineDesign.ts');
  assert.match(form, /<InvoiceLinesEditor readOnly=\{readOnly\} draft=\{draft\} setDraft=\{setDraft\}/);
  for (const label of ['Document lines', 'Split', 'Add line', 'Column settings', 'Amount', 'Total Amount', 'VAT Classifier', 'Product group', 'Department', 'Object', 'Center']) assert.ok((editor + design).includes(label), label);
  assert.doesNotMatch(editor, /Document line view|setMode|mode === 'summary'|Summary \(|Quantity \(/);
  assert.match(editor, /const rows = allocation \? draft.allocations \|\| draft.lines : draft.lines;/);
  assert.match(editor, /useState\(defaults\)/);
  assert.match(editor, /role="table" aria-label="Invoice lines"/);
  assert.match(editor, /const label = `Invoice line/);
  assert.match(design, /h-\[26px\]/); assert.match(editor, /bg-\[#F8FDFF\]/);
  assert.match(editor, /max-h-\[360px\].*overflow-auto/); assert.match(editor, /documentLineHeaderClass\} sticky top-0/);
  assert.match(editor, /system-table-row-actions/); assert.match(editor, /portalMenu/);
  assert.match(editor, /key === 'net' \|\| key === 'total'.*<output/);
  assert.match(editor, /splitInvoiceLines\(draft.lines/);
  assert.match(editor, /allowUnpricedTargets: true/);
});

test('Split uses a compact aligned table with a fixed allocation column for any number of lines', () => {
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx');
  const panel = editor.slice(editor.indexOf('{showSplit && <section'), editor.indexOf('{showColumns && <div'));
  assert.match(panel, /aria-label="Split allocations"/);
  assert.match(panel, /role="table"/);
  assert.equal((panel.match(/grid-cols-\[64px_minmax\(0,1fr\)_192px\]/g) || []).length, 2, 'header and all rows use identical fixed tracks');
  assert.match(panel, /!max-h-\[280px\] overflow-auto/);
  assert.match(panel, /role="row" className="sticky top-0/);
  assert.match(panel, /role="rowgroup">\{rows\.map/);
  assert.match(panel, /row\.name \|\| row\.description \|\| '—'/);
  assert.match(panel, /<HorizontalTableScrollbar scrollRef=\{splitTable\} fixed=\{false\} expandable=\{false\}/);
  assert.match(panel, /<PageActionButton onClick=\{applySplit\}>Apply/);
  assert.doesNotMatch(panel, /sm:grid-cols-2|lg:grid-cols-3|<table\b/);
});

test('invoice row design shares the actual Edit geometry, without native table resize handles or dividers', () => {
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx'), detail = read('../src/components/DocumentDetailPanel.tsx'), appearance = {};
  new Function('exports', compile('../src/components/documentLineDesign.ts'))(appearance);
  for (const component of [editor, detail]) {
    assert.match(component, /from ['"]\.\.?\/documentLineDesign['"]/);
    assert.match(component, /documentLineRowClass/);
    assert.match(component, /documentLineInputClass/);
    assert.match(component, /documentQuantityColumns/);
  }
  assert.match(detail, /documentSummaryColumns/);
  assert.deepEqual(appearance.documentSummaryColumns.map(column => column.w), [110, 80, 90, 90, 80, 70, 110, 130, 100, 90, 80, 90, 110, 110]);
  assert.match(appearance.documentLineRowClass, /gap-\[2px\].*rounded-lg.*p-\[5px\]/);
  assert.doesNotMatch(editor, /<table\b|<th\b|<td\b/);
  assert.match(editor, /role="table"/); assert.match(editor, /role="columnheader"/);
  assert.match(editor, /data-document-lines-appearance="edit"/);
});

test('purchase and sale drafts retain common register classification, company, allocations and audit', () => {
  for (const purpose of ['Purchase', 'Sale']) {
    const input = command({ purpose, series: 'TEST', orderNo: 'ORD-1', department: 'ADMIN', costCenter: 'OFFICE', project: 'P1', notes: 'Testing only' });
    const before = structuredClone(input);
    const result = core.prepareInvoiceDocument(input, context);
    assert.deepEqual(input, before);
    assert.equal(result.company_id, company.id);
    assert.equal(result.document_type, 'INVOICES'); assert.equal(result.document_subtype, 'INVOICE');
    assert.equal(result.type, purpose); assert.equal(result.document_purpose, purpose); assert.equal(result.status, 'Draft');
    assert.equal(result.amount_without_vat, '100.00'); assert.equal(result.vat, '21.00'); assert.equal(result.total_amount, '121.00');
    assert.equal(result.line_items[0].expense, '6300'); assert.equal(result.summary_line_items[0].department, 'ADMIN');
    assert.notEqual(result.summary_line_items[0].id, result.line_items[0].id);
    assert.equal(result.creation_history[0].actor, context.actor); assert.equal(result.created_by, context.actor);
    assert.equal(result.counterparty_id, counterparty.id); assert.equal(result.order_no, 'ORD-1');
    assert.equal(result.accounting_posting, undefined); assert.equal(result.accounting_storno, undefined);
  }
});

test('multiple allocations preserve accounting dimensions and credit notes reverse totals without negative prices', () => {
  const input = command({ kind: 'CREDIT_INVOICE', glAccount: '6000', vatClassifier: 'PVM1' });
  input.draft.lines.push({ ...core.newInvoiceLine('line-2'), description: 'Second service', price: '10', vatRate: '0' });
  const result = core.prepareInvoiceDocument(input, context);
  assert.equal(result.total_amount, '-131.00'); assert.equal(result.vat, '-21.00');
  assert.equal(result.expense_account, ''); assert.equal(result.vat_classifier, ''); assert.equal(result.vat_percent, '');
  assert.equal(result.line_items[0].qty, '-2'); assert.equal(result.line_items[0].price, '50');
  assert.equal(result.summary_line_items[1].expense, '6000'); assert.equal(result.summary_line_items.length, 2);
  const debit = core.prepareInvoiceDocument(command({ kind: 'DEBIT_INVOICE' }), context);
  assert.equal(debit.total_amount, '121.00');
});

test('validation checks rights, counterparty, dates, currency, exchange rate and line values', () => {
  assert.throws(() => core.prepareInvoiceDocument(command(), { ...context, allowed: false }), /access/);
  for (const patch of [{ number: '' }, { counterpartyId: 'other-company-party' }, { purpose: 'Invalid' }, { kind: 'Invalid' }, { invoiceDate: '2026-02-30' }, { operationDate: 'bad-date' }, { dueDate: '2026-11-03' }, { currency: 'bad' }, { currency: 'USD', exchangeRate: '0' }, { currency: 'USD', exchangeRate: '' }, { lines: [] }, { notes: 'x'.repeat(10001) }]) assert.throws(() => core.prepareInvoiceDocument(command(patch), context));
  assert.throws(() => core.prepareInvoiceDocument({ ...command(), requestId: '' }, context));
  assert.throws(() => core.prepareInvoiceDocument(command({ lines: [{ ...command().draft.lines[0], description: '' }] }), context), /name or description/);
  assert.equal(core.prepareInvoiceDocument(command({ exchangeRate: '0' }), context).exchange_rate, '1');
  assert.equal(core.prepareInvoiceDocument(command({ currency: 'USD', exchangeRate: '0.91' }), context).exchange_rate, '0.91');
  assert.equal(core.invoiceDueDate('2026-12-25', '14'), '2027-01-08');
  assert.equal(core.invoiceDueDate('2026-02-30', '14'), '');
});

test('counterparties are company-scoped without fallback; attachments preserve all files and reject active markup', () => {
  storage.set(core.invoiceCounterpartiesKey(company.id), JSON.stringify([counterparty]));
  assert.deepEqual(core.loadInvoiceCounterparties(company.id), [counterparty]);
  assert.deepEqual(core.loadInvoiceCounterparties('other-company'), []);
  storage.set(core.invoiceCounterpartiesKey('malformed'), '{}');
  assert.throws(() => core.loadInvoiceCounterparties('malformed'));
  const input = command();
  input.attachments = [{ name: 'a.pdf', type: 'application/pdf', size: 10, url: 'data:application/pdf;base64,QUJD' }, { name: 'b.png', type: 'image/png', size: 10, url: 'data:image/png;base64,QUJD' }];
  const saved = core.prepareInvoiceDocument(input, context);
  assert.equal(saved.invoice_attachments.length, 2); assert.equal(saved.file_case, 'a.pdf');
  assert.equal(saved.image_url, input.attachments[0].url);
  assert.throws(() => core.prepareInvoiceDocument({ ...input, attachments: [{ ...input.attachments[0], url: 'data:image/svg+xml,<svg />' }] }, context), /Attach/);
});

function fixture() {
  const store = new Map(), api = {}, issues = {}, storno = {};
  let allowed = true, parties = [counterparty], users = [{ id: 'internal-a', fullName: 'Test accountant', status: 'Active' }], types = structuredClone(invoiceTypes), failedTable = '';
  const browser = { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => { if (failedTable && key.endsWith(`:${failedTable}`)) throw Error('Storage full'); store.set(key, value); } }, setTimeout, clearTimeout, dispatchEvent() {} };
  const configuredLineTypes = {}, configuredStatuses = {}, configuredCore = {}, referenceCatalogs = {};
  new Function('exports', 'window', compile('../src/lib/documentProcessingStatus.ts'))(configuredStatuses, browser);
  new Function('exports', 'window', compile('../src/lib/invoiceLineTypes.ts'))(configuredLineTypes, browser);
  new Function('exports', 'window', compile('../src/lib/generalReferenceCatalogs.ts'))(referenceCatalogs, browser);
  new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
  const require = name => {
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './invoiceCreation') return { ...configuredCore, loadInvoiceCounterparties: id => id === company.id ? parties : [] };
    if (name === './invoiceLineExtras') return { loadInvoiceWarehouse: () => null };
    if (name === './invoiceLineTypes') return configuredLineTypes;
    if (name === './documentProcessingStatus') return configuredStatuses;
    if (name === './generalReferenceCatalogs') return referenceCatalogs;
    if (name === './documentRowActionAccess') return { canCreateCompanyDocument: () => allowed, documentActionRights: () => ({ create: allowed }) };
    if (name === './invoiceCreditNote') return creditNotes;
    if (name === './documentStornoAccess') return { loadStornoPeriodPolicy: () => ({ enabled: false, cutoffDay: 25 }) };
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => allowed };
    if (name === './invoiceDocumentForm') return forms;
    if (name === './linkedSettingsData') return { loadLinkedDirectoryUsers: audience => audience === 'Internal users' ? users : [] };
    if (name === './documentResponsibleUsers') return responsible;
    if (name === '../components/OrganizationReferenceValuesView') return { loadOrganizationReferenceRecords: section => section === 'Document type' ? types : [] };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './currentUser') return { getCurrentUserName: () => context.actor };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { isInactiveRecord: row => row.inactive === true, removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'window', 'require', compile('../src/lib/invoiceCreation.ts'))(configuredCore, browser, require);
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require, browser, {}, async () => { throw Error('Local fixture only'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('companies', [company]); put('documents', [{ id: 'keep-original', company_id: company.id, number: 'ORIGINAL' }]); put('document_history', []); put('lookup_values', []);
  return { ...api, put, get, configuredLineTypes, configuredStatuses, setCatalog: (section, rows) => store.set(`finansu-harmonija:organization-reference:${section}`, JSON.stringify(rows)), setTypes: value => { types = value; }, revoke: () => { allowed = false; }, deactivateParty: () => { parties = [{ ...counterparty, inactive: true }]; }, deactivateUser: () => { users = [{ ...users[0], status: 'Blocked' }]; }, failWrite: (table = 'documents') => { failedTable = table; } };
}

test('document form selection uses manual provenance, never status or the existence of a PDF', () => {
  const manual = { source: 'Manual', document_type: 'INVOICES', image_url: 'saved.pdf', status: 'Approved' };
  assert.equal(forms.usesManualInvoiceForm(manual), true);
  for (const source of ['Upload', 'Email', 'Import', 'OCR', 'API', '']) assert.equal(forms.usesManualInvoiceForm({ ...manual, source, status: 'Manual' }), false);
  assert.equal(forms.usesManualInvoiceForm({ ...manual, entry_method: 'import' }), false);
  assert.equal(forms.usesManualInvoiceForm({ ...manual, document_type: 'ACCOUNTING_NOTE' }), false);
});

const copyContext = () => ({ companyId: company.id, baseCurrency: 'EUR', today: '2026-11-09', counterparties: [counterparty],
  invoiceOptions: core.invoiceTypeOptions(invoiceTypes), users: [{ value: 'internal-a', label: 'Test accountant' }],
  newId: (() => { let id = 0; return () => `copy-line-${++id}`; })() });

test('Create credit note opens a fresh linked draft for approved imported and manual invoices', () => {
  for (const source of ['Manual', 'Upload', 'Email']) for (const purpose of ['Purchase', 'Sale']) {
    const original = { ...core.prepareInvoiceDocument(command({ purpose }), context), source, status: 'Approved', accounting_posting: { id: 'original-posting' } };
    const before = structuredClone(original), draft = creditNotes.invoiceCreditNoteFromDocument(original, { ...copyContext(), allowed: true });
    assert.equal(draft.kind, 'CREDIT_INVOICE'); assert.equal(draft.status, 'Draft');
    assert.equal(draft.creditSourceDocumentId, original.id); assert.equal(draft.purpose, purpose);
    assert.equal(draft.number, ''); assert.equal(draft.series, '');
    assert.equal(draft.invoiceDate, '2026-11-09'); assert.equal(draft.operationDate, '2026-11-09');
    assert.equal(draft.counterpartyId, counterparty.id); assert.equal(draft.lines.length, 1);
    assert.equal(core.invoiceTotals(draft).total, -12100);
    assert.equal(draft.accounting_posting, undefined);
    draft.lines[0].description = 'Editable credit line';
    assert.deepEqual(original, before);
  }
});

test('credit note creation rejects ineligible invoices, changed originals, invalid dates and missing reason', () => {
  const original = { ...core.prepareInvoiceDocument(command(), context), status: 'Approved' };
  const create = (source = original, extra = {}) => creditNotes.invoiceCreditNoteFromDocument(source, { ...copyContext(), allowed: true, ...extra });
  for (const patch of [{ status: 'Draft' }, { inactive: true }, { document_storno: {} }, { total_amount: '-121.00' }, { document_type: 'ACCOUNTING_NOTE' }, { company_id: 'another-company' }, { document_deletion: {} }]) assert.throws(() => create({ ...original, ...patch }));
  assert.throws(() => create(original, { allowed: false }), /access/);
  assert.throws(() => create(original, { invoiceOptions: [] }), /Credit invoice type/);
  const draft = create(), intent = { documentId: original.id, expectedSnapshot: rowActions.documentActionSnapshot(original), reason: 'Returned goods' };
  const checkContext = { companyId: company.id, allowed: true, today: '2026-11-09', period: { enabled: false, cutoffDay: 25 } };
  assert.doesNotThrow(() => creditNotes.validateCreditNoteCreation(original, intent, draft, checkContext));
  assert.throws(() => creditNotes.validateCreditNoteCreation({ ...original, number: 'changed' }, intent, draft, checkContext), /original invoice changed/);
  assert.throws(() => creditNotes.validateCreditNoteCreation(original, { ...intent, reason: ' ' }, draft, checkContext), /reason/);
  assert.throws(() => creditNotes.validateCreditNoteCreation(original, intent, { ...draft, kind: 'INVOICE' }, checkContext), /credit type/);
  assert.throws(() => creditNotes.validateCreditNoteCreation(original, intent, { ...draft, creditSourceDocumentId: '' }, checkContext), /original invoice link/);
  assert.throws(() => creditNotes.validateCreditNoteCreation(original, intent, { ...draft, invoiceDate: '2026-11-10' }, checkContext), /future/);
  assert.throws(() => creditNotes.validateCreditNoteCreation(original, intent, draft, { ...checkContext, period: { enabled: false, cutoffDay: 25, closedThrough: '2026-11-09' } }), /locked/);
});

test('saving a credit-note draft preserves original, records link/reason/audit, and is idempotent', async () => {
  const f = fixture(), original = { ...core.prepareInvoiceDocument(command(), context), source: 'Email', status: 'Approved', accounting_posting: { id: 'approved-posting' } };
  f.put('documents', [original]);
  const draft = creditNotes.invoiceCreditNoteFromDocument(original, { ...copyContext(), today: creditStorno.accountingToday(), allowed: true });
  draft.number = 'CREDIT-001';
  const input = { requestId: 'credit-note-test-001', draft, attachments: [], creditNoteSource: {
    documentId: original.id, expectedSnapshot: rowActions.documentActionSnapshot(original), reason: 'Returned goods',
  } };
  const saved = await f.createInvoiceDocument(company.id, input);
  assert.equal(saved.status, 'Draft'); assert.equal(saved.document_subtype, 'CREDIT_INVOICE');
  assert.equal(saved.total_amount, '-121.00'); assert.equal(saved.correction_of_document_id, original.id);
  assert.equal(saved.correction_reason, 'Returned goods'); assert.match(saved.correction_history[0].details, /Returned goods/);
  assert.equal(saved.source, 'Manual'); assert.equal(saved.accounting_posting, undefined);
  assert.deepEqual(f.get('documents').find(row => row.id === original.id), original);
  assert.equal(f.get('document_history')[0].original_document_id, original.id);
  assert.equal((await f.createInvoiceDocument(company.id, input)).id, saved.id);
  assert.equal(f.get('documents').length, 2);
  f.put('documents', [{ ...original, status: 'Draft' }]);
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'credit-note-changed' }), /original invoice changed/);
  f.put('documents', [original]); f.deactivateParty();
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'credit-note-inactive-party' }), /active counterparty/);
  f.revoke();
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'credit-note-revoked' }), /Create access/);
});

test('Documents row and both editor Actions route credit notes directly to the shared invoice form', () => {
  const docs = read('../src/components/Documents.tsx'), form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.match(docs, /kind === 'correction' && documentCorrectionKind\(document.inlineSource\) === 'Credit note'/);
  assert.equal((docs.match(/onAction=\{kind => openDocumentAction\(activeDocument, kind\)\}/g) || []).length, 2);
  assert.match(docs, /onClick=\{\(\) => openDocumentAction\(doc, contextAction.kind\)\}/);
  assert.match(docs, /creditNoteSourceDocumentId=\{creditNoteSource.documentId\}/);
  assert.match(form, /creditNoteSourceDocumentId \? 'Create credit note' : 'Create new invoice'/);
  assert.match(form, /'Original invoice' : 'Document to reconcile'/);
  assert.match(form, /creditNoteSource: \{ documentId: creditNoteSourceDocumentId, expectedSnapshot: creditSourceSnapshot.current, reason: creditNoteReason \}/);
});

test('legacy credit sources retain their counterparty snapshot without creating or modifying master data', async () => {
  const f = fixture(), original = { ...core.prepareInvoiceDocument(command(), context), status: 'Approved',
    counterparty_id: 'legacy-supplier', counterparty_code: 'LEGACY-001', client_counterparty: 'Legacy supplier' };
  f.put('documents', [original]);
  const parties = forms.invoiceFormCounterparties(original, [counterparty]);
  const draft = creditNotes.invoiceCreditNoteFromDocument(original, { ...copyContext(), counterparties: parties,
    today: creditStorno.accountingToday(), allowed: true });
  assert.equal(draft.counterpartyId, 'legacy-supplier');
  const saved = await f.createInvoiceDocument(company.id, { requestId: 'credit-note-legacy-001', draft: { ...draft, number: 'LEGACY-CREDIT-001' }, attachments: [],
    creditNoteSource: { documentId: original.id, expectedSnapshot: rowActions.documentActionSnapshot(original), reason: 'Return' } });
  assert.equal(saved.counterparty_id, 'legacy-supplier'); assert.equal(saved.client_counterparty, 'Legacy supplier');
  assert.deepEqual(f.get('documents').find(row => row.id === original.id), original);
  assert.equal(f.get('companies').length, 1);
});

test('Copy creates an editable invoice draft from imported and manual documents without inheriting lifecycle state', () => {
  for (const source of ['Upload', 'Manual', 'Email']) {
    const input = command({ purpose: 'Sale', series: 'SALE', orderNo: 'ORDER-1', notes: 'Keep this note', responsibleId: 'internal-a' });
    const original = { ...core.prepareInvoiceDocument(input, { ...context, responsibleUsers: [{ id: 'internal-a', fullName: 'Test accountant', status: 'Active' }], responsible: { accountable_responsible: 'Test accountant', accountable_responsible_id: 'internal-a' } }),
      source, status: 'Approved', accounting_posting: { id: 'posting' }, accounting_storno: { id: 'storno' },
      document_storno: { id: 'storno-test' }, accounting_test_deliveries: [{ id: 'test-send' }], digitization_issues: [{ status: 'Open' }],
      approval_cancellation_history: [{ action: 'Approval cancelled' }], image_url: 'source.pdf',
      correction_of_document_id: 'original-credit', invoice_attachments: [{ url: 'original.pdf' }] };
    const before = structuredClone(original), draft = copies.invoiceCopyFromDocument(original, copyContext());
    assert.equal(draft.status, 'Draft'); assert.equal(draft.number, ''); assert.equal(draft.kind, 'INVOICE');
    assert.equal(draft.purpose, 'Sale'); assert.equal(draft.series, 'SALE'); assert.equal(draft.orderNo, 'ORDER-1');
    assert.equal(draft.counterpartyId, counterparty.id); assert.equal(draft.responsibleId, 'internal-a');
    assert.equal(draft.notes, 'Keep this note'); assert.equal(draft.creditSourceDocumentId, '');
    assert.deepEqual(core.invoiceTotals(draft), core.invoiceTotals(input.draft));
    assert.equal(draft.lines[0].id, 'copy-line-1'); assert.equal(draft.lines[0].allocationId, undefined);
    for (const field of ['id', 'source', 'accounting_posting', 'document_storno', 'accounting_storno', 'digitization_issues', 'accounting_test_deliveries', 'approval_cancellation_history', 'created_at', 'image_url', 'invoice_attachments']) assert.equal(draft[field], undefined);
    draft.lines[0].description = 'Changed only in copy';
    draft.lines[0].accountingDefaultOverrides.department = false;
    assert.deepEqual(original, before);
  }
});

test('Copy keeps allocations, line values and credit signs, normalizes legacy dates, and requires active options', () => {
  const input = command({ kind: 'CREDIT_INVOICE', purpose: 'Purchase' });
  // Use explicit allocations independently from the OCR quantity lines.
  const original = core.prepareInvoiceDocument({ ...input, draft: { ...input.draft, allocations: [
    { ...input.draft.lines[0], id: 'alloc-1', quantity: '1', department: 'SALES', includeVatInDebt: false },
    { ...input.draft.lines[0], id: 'alloc-2', quantity: '1', department: 'ADMIN' },
  ] } }, context);
  original.document_date = '04.11.2026'; original.operation_date = '05.11.2026'; original.due_end_date = '18.11.2026';
  const draft = copies.invoiceCopyFromDocument(original, copyContext());
  assert.equal(draft.invoiceDate, '2026-11-04'); assert.equal(draft.operationDate, '2026-11-05'); assert.equal(draft.dueDate, '2026-11-18');
  assert.equal(draft.kind, 'CREDIT_INVOICE'); assert.equal(draft.lines.length, 1); assert.equal(draft.allocations.length, 2);
  assert.equal(draft.allocations[0].department, 'SALES'); assert.equal(draft.allocations[0].includeVatInDebt, false);
  assert.equal(new Set([...draft.lines, ...draft.allocations].map(row => row.id)).size, 3);
  assert.equal(core.invoiceTotals(draft).total, -12100);
  assert.equal(copies.invoiceCopyFromDocument({ ...original, document_subtype: '', document_type: 'VAT invoice', type: 'Income', document_purpose: 'Services' }, copyContext()).purpose, 'Sale');
  assert.equal(copies.invoiceCopyFromDocument({ ...original, document_subtype: '', document_type: 'VAT invoice' }, copyContext()).kind, 'VAT_INVOICE');
  const unavailable = copies.invoiceCopyFromDocument(original, { ...copyContext(), counterparties: [], users: [], invoiceOptions: [] });
  assert.equal(unavailable.counterpartyId, ''); assert.equal(unavailable.kind, ''); assert.equal(unavailable.responsibleId, '');
  assert.throws(() => copies.invoiceCopyFromDocument({ ...original, company_id: 'different-company' }, copyContext()), /company/);
  assert.throws(() => copies.invoiceCopyFromDocument({ ...original, document_deletion: { at: 'now' } }, copyContext()), /company/);
});

test('saving a copy creates a new Manual invoice and audit, leaving source, posting and source history unchanged', async () => {
  const f = fixture(), original = { ...core.prepareInvoiceDocument(command(), context), source: 'Email', status: 'Approved', accounting_posting: { id: 'confirmed-posting' } };
  f.put('documents', [original]);
  const draft = copies.invoiceCopyFromDocument(original, copyContext()); draft.number = 'COPY-NEW-001';
  const input = { requestId: 'copied-invoice-001', draft, attachments: [], copySourceDocumentId: original.id };
  const saved = await f.createInvoiceDocument(company.id, input);
  assert.notEqual(saved.id, original.id); assert.equal(saved.source, 'Manual'); assert.equal(saved.entry_method, 'manual');
  assert.equal(forms.usesManualInvoiceForm(saved), true); assert.equal(saved.status, 'Draft');
  assert.equal(saved.copied_from_document_id, original.id); assert.equal(saved.accounting_posting, undefined);
  assert.equal(saved.correction_of_document_id, undefined); assert.equal(saved.image_url, null);
  assert.match(saved.creation_history[0].details, /Copied from/);
  assert.deepEqual(f.get('documents').find(row => row.id === original.id), original);
  assert.equal(f.get('document_history').length, 1);
  assert.equal((await f.createInvoiceDocument(company.id, input)).id, saved.id);
  f.put('documents', [{ ...original, company_id: 'other-company' }]);
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'copied-moved-001' }), /copy source/);
  f.put('documents', [{ ...original, document_deletion: { at: 'now' } }]);
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'copied-deleted-001' }), /copy source/);
  f.put('documents', [original]); f.revoke();
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'copied-denied-001' }), /Create access/);
});

test('list and document-card Copy open the shared Create invoice form without the legacy copy modal', () => {
  const docs = read('../src/components/Documents.tsx'), form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.doesNotMatch(docs, /CreateDocumentModal|setShowCreateModal|presetCreateDocumentType/);
  assert.match(docs, /duplicateSource && <CreateInvoiceForm key=\{`copy:\$\{duplicateSource.id\}`\}/);
  assert.match(docs, /companyId=\{duplicateSource.companyId\}/);
  assert.match(docs, /copySourceDocumentId=\{duplicateSource.id\}/);
  assert.equal((docs.match(/onDuplicate=\{record => \{ closeDocument\(\); setDuplicateSource\(mapRow\(record\)\); \}\}/g) || []).length, 2);
  assert.match(form, /row.id === copySourceDocumentId && row.company_id === companyId/);
  assert.match(form, /setDraft\(invoiceCopyFromDocument\(copySource/);
  assert.match(form, /setAttachments\(\[\]\)/);
  assert.match(form, /if \(documentId\) await updateInvoiceDocument/);
  assert.match(form, /else await createInvoiceDocument/);
});

test('saved manual invoice round-trips values, signs, stable row IDs, explicit defaults and attachments', () => {
  for (const kind of ['INVOICE', 'CREDIT_INVOICE']) {
    const input = command({ kind, purpose: 'Sale', language: 'LT', department: 'ADMIN', costCenter: 'HQ', vatClassifier: 'PVM1' });
    input.draft.lines = [core.updateInvoiceLine({ ...input.draft.lines[0], name: 'SVC-1', description: 'Accounting service', discount: '5',
      includeVatInDebt: false, lineNote: 'Line note', analyticalSeries: 'ANA', mainAnalyticalAccount: '2410', relatedContract: 'AGREEMENT-1', itemCode: 'SVC', barcode: '0123' }, { department: 'SALES' })];
    input.attachments = [{ name: 'invoice.pdf', type: 'application/pdf', size: 3, url: 'data:application/pdf;base64,QUJD' }];
    const saved = core.prepareInvoiceDocument(input, context);
    const hydrated = forms.invoiceFormFromDocument(saved, [counterparty], 'EUR');
    assert.equal(hydrated.draft.allocations, undefined);
    assert.equal(hydrated.draft.department, 'ADMIN'); assert.equal(hydrated.draft.lines[0].department, 'SALES');
    assert.equal(hydrated.draft.lines[0].quantity, '2'); assert.equal(hydrated.draft.language, 'LT');
    assert.deepEqual(hydrated.attachments, input.attachments);
    const prepared = core.prepareInvoiceDocument({ ...input, ...hydrated }, { ...context, existingDocument: saved });
    const patch = forms.invoiceDocumentEditPatch(saved, prepared, hydrated.draft);
    for (const field of ['amount_without_vat', 'vat', 'total_amount', 'amount_due', 'document_subtype']) assert.equal(patch[field], saved[field], field);
    assert.equal(patch.line_items[0].id, saved.line_items[0].id); assert.equal(patch.summary_line_items[0].id, saved.summary_line_items[0].id);
    for (const field of ['line_note', 'analytical_series', 'main_analytical_account', 'related_contract', 'item_code', 'barcode', 'department', 'include_vat_in_debt']) assert.equal(patch.line_items[0][field], saved.line_items[0][field], field);
    for (const protectedField of ['id', 'company_id', 'source', 'entry_method', 'created_at', 'created_by', 'creation_history', 'creation_request_id', 'receive_date']) assert.ok(!(protectedField in patch), protectedField);
  }
});

test('existing separate accounting allocations remain visible and editable without being collapsed into item rows', () => {
  const input = command();
  input.draft.allocations = [
    { ...input.draft.lines[0], id: 'alloc-a', quantity: '1', price: '40', department: 'A', glAccount: '6300' },
    { ...input.draft.lines[0], id: 'alloc-b', quantity: '1', price: '60', department: 'B', glAccount: '6202' },
  ];
  const saved = core.prepareInvoiceDocument(input, context);
  const hydrated = forms.invoiceFormFromDocument(saved, [counterparty], 'EUR');
  assert.equal(hydrated.draft.lines.length, 1); assert.equal(hydrated.draft.allocations.length, 2);
  hydrated.draft.allocations[1].department = 'C';
  const prepared = core.prepareInvoiceDocument({ ...input, ...hydrated }, { ...context, existingDocument: saved });
  const patch = forms.invoiceDocumentEditPatch(saved, prepared, hydrated.draft);
  assert.equal(patch.summary_line_items[1].id, saved.summary_line_items[1].id);
  assert.equal(patch.summary_line_items[1].department, 'C'); assert.equal(patch.total_amount, saved.total_amount);
  hydrated.draft.lines[0].price = '100';
  assert.throws(() => core.prepareInvoiceDocument({ ...input, ...hydrated }, { ...context, existingDocument: saved }), /Summary amounts/);
});

test('manual invoice edit persists in the same register record with retained issue history, creation metadata and no GL write', async () => {
  const f = fixture(), created = await f.createInvoiceDocument(company.id, command());
  const original = { ...created, custom_metadata: 'retain', detail_edit_history: [{ id: 'older-edit' }],
    digitization_issues: [{ id: 'issue-a', status: 'Resolved', events: [] }] };
  f.put('documents', [f.get('documents')[0], original]); f.put('gl_journal_entries', [{ id: 'gl-original' }]);
  const hydrated = forms.invoiceFormFromDocument(original, [counterparty], 'EUR');
  hydrated.draft.orderNo = 'CHANGED-ORDER'; hydrated.draft.lines[0] = core.updateInvoiceLine(hydrated.draft.lines[0], { price: '75' });
  const updated = await f.updateInvoiceDocument(original.id, company.id, { requestId: 'edit-invoice-0001', ...hydrated }, forms.invoiceDocumentSnapshot(original));
  assert.equal(f.get('documents').length, 2); assert.equal(updated.id, original.id); assert.equal(updated.order_no, 'CHANGED-ORDER');
  assert.equal(updated.total_amount, '181.50'); assert.equal(updated.source, 'Manual');
  assert.equal(updated.line_items[0].id, original.line_items[0].id); assert.equal(updated.summary_line_items[0].id, original.summary_line_items[0].id);
  assert.deepEqual(updated.creation_history, original.creation_history); assert.equal(updated.created_at, original.created_at); assert.equal(updated.custom_metadata, 'retain');
  assert.deepEqual(updated.digitization_issues, original.digitization_issues); assert.equal(updated.detail_edit_history.length, 2);
  assert.equal(f.get('document_history').at(-1).action, 'Updated'); assert.deepEqual(f.get('gl_journal_entries'), [{ id: 'gl-original' }]);
  await assert.rejects(f.updateInvoiceDocument(original.id, company.id, { requestId: 'edit-invoice-0002', ...hydrated }, forms.invoiceDocumentSnapshot(original)), /changed/);
});

test('manual invoice edit rechecks permission, company, origin, locked state, unresolved issues and concurrent writes', async () => {
  for (const variant of ['permission', 'company', 'import', 'approved', 'reversed', 'stale', 'issue', 'ocr']) {
    const f = fixture(), original = await f.createInvoiceDocument(company.id, command());
    const hydrated = forms.invoiceFormFromDocument(original, [counterparty], 'EUR'); hydrated.draft.notes = 'Changed';
    let record = original, companyId = company.id;
    if (variant === 'permission') f.revoke();
    if (variant === 'company') companyId = 'other';
    if (variant === 'import') record = { ...original, entry_method: 'import', source: 'Upload' };
    if (variant === 'approved') record = { ...original, status: 'Approved' };
    if (variant === 'reversed') record = { ...original, document_storno: { mode: 'test' } };
    if (variant === 'stale') record = { ...original, notes: 'Edited elsewhere' };
    if (variant === 'issue' || variant === 'ocr') record = { ...original, digitization_issues: [{ id: 'issue-a', status: variant === 'ocr' ? 'Awaiting OCR' : 'Open', blocksApproval: true, events: [] }] };
    if (variant === 'issue') hydrated.draft.status = 'Approved';
    f.put('documents', [record]);
    const expected = forms.invoiceDocumentSnapshot(variant === 'stale' ? original : record);
    await assert.rejects(f.updateInvoiceDocument(record.id, companyId, { requestId: 'edit-blocked-001', ...hydrated }, expected));
    assert.deepEqual(f.get('documents'), [record]);
  }
});

test('edit and view route by origin to the same respective form, with read-only fields and working section controls', () => {
  const documents = read('../src/components/Documents.tsx'), form = read('../src/components/invoices/CreateInvoiceForm.tsx'), editor = read('../src/components/invoices/InvoiceLinesEditor.tsx');
  assert.match(documents, /const activeDocument = openDoc \|\| viewDoc/);
  assert.match(documents, /usesManualInvoiceForm\(activeDocument.inlineSource\)/);
  assert.match(documents, /documentId=\{activeDocument.id\} mode=\{activeDocumentReadOnly \? 'view' : 'edit'\}/);
  assert.match(documents, /readOnly=\{activeDocumentReadOnly\}\s+doc=\{activeDocument\}/);
  assert.doesNotMatch(documents, /viewDoc && \(\s*<CreateDocumentModal/);
  assert.match(form, /if \(readOnly \|\| pending.current/);
  assert.match(form, /<ReadOnlyContext.Provider value=\{readOnly\}/);
  assert.match(form, /<fieldset disabled=\{readOnly\}/);
  assert.match(editor, /<fieldset disabled=\{readOnly\}/);
  assert.match(form, /if \(documentId\) await updateInvoiceDocument/);
  assert.match(form, /draft.allocations &&/);
  assert.match(form, /onToggle=\{\(\) => toggle\('additional'\)\}/);
  assert.match(form, /choices\.unshift\(\{ value, label: value, disabled: true \}\)/);
  assert.match(editor, /choices\.unshift\(\{ value, label: value, disabled: true \}\)/);
  const imported = read('../src/components/DocumentDetailPanel.tsx');
  assert.match(imported, /<\/fieldset>\s*\{\/\* View navigation stays available/);
  assert.match(imported, /<\/fieldset>\s*<\/div>\s*<HorizontalTableScrollbar/);
});

test('legacy manual invoices keep their original file when extra attachments are added', () => {
  const input = command();
  const original = { ...core.prepareInvoiceDocument(input, context), file_case: 'Original.pdf', image_url: '/files/original.pdf', invoice_attachments: [] };
  const form = forms.invoiceFormFromDocument(original, [counterparty], 'EUR');
  const newFile = { name: 'Extra.pdf', type: 'application/pdf', size: 8, url: 'data:application/pdf;base64,JVBERi0x' };
  const prepared = core.prepareInvoiceDocument({ ...input, ...form, attachments: [newFile] }, { ...context, existingDocument: original });
  const patch = forms.invoiceDocumentEditPatch(original, prepared, form.draft);
  assert.equal(patch.image_url, undefined);
  assert.equal(patch.file_case, undefined);
  const saved = { ...original, ...patch };
  assert.equal(forms.invoiceSourceAttachment(saved).name, 'Original.pdf');
  assert.equal(forms.invoiceSourceAttachment(saved).url, '/files/original.pdf');
  assert.equal(saved.invoice_attachments[0].name, 'Extra.pdf');
  assert.equal(forms.invoiceSourceAttachment(prepared), null);
});

test('invoice adapter validates the fresh credit source, persists its ID and leaves original documents unchanged', async () => {
  const f = fixture(), original = structuredClone(creditSource);
  f.put('documents', [original]);
  const input = command({ kind: 'CREDIT_INVOICE', creditSourceDocumentId: original.id });
  const saved = await f.createInvoiceDocument(company.id, input);
  assert.equal(saved.correction_of_document_id, original.id);
  assert.equal(f.get('documents').find(row => row.id === original.id).total_amount, original.total_amount);
  assert.deepEqual(f.get('documents')[0], original);
  assert.equal(f.get('document_history')[0].original_document_id, original.id);
  assert.equal((await f.createInvoiceDocument(company.id, input)).id, saved.id);
  assert.equal(f.get('documents').length, 2);
  f.put('documents', [{ ...original, type: 'Sale' }]);
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'test-credit-stale' }), /no longer available/);
  assert.equal(f.get('documents').length, 1);
});

test('line types keep system defaults, isolate companies and omit inactive, duplicate or malformed options', () => {
  const type = lineTypes.invoiceLineTypeScope(company.id);
  const records = [{ type, value: 'Transport' }, { type, value: ' service ' }, { type, value: 'TRANSPORT' },
    { type: lineTypes.invoiceLineTypeScope('other-company'), value: 'Other company only' },
    ...[{ inactive: true }, { active: false }, { is_active: false }, { status: 'Inactive' }].map(flags => ({ type, value: 'Disabled', ...flags })),
    ...['', 'x'.repeat(81), 'Bad\nname', null].map(value => ({ type, value }))];
  assert.deepEqual(lineTypes.invoiceLineTypeValues(company.id, records), ['Service', 'Product', 'Code', 'Transport']);
  assert.deepEqual(lineTypes.prepareInvoiceLineType(company.id, '  transport ', records), { type, value: 'Transport', create: false });
  assert.deepEqual(lineTypes.prepareInvoiceLineType(company.id, '  Custom   fee ', records), { type, value: 'Custom fee', create: true });
  assert.throws(() => lineTypes.prepareInvoiceLineType(company.id, 'Disabled', records), /inactive/);
  for (const value of ['', ' ', null, 'x'.repeat(81), 'Bad\nname', 'Bad\u007fname']) assert.throws(() => lineTypes.normalizeInvoiceLineType(value));
  assert.throws(() => lineTypes.prepareInvoiceLineType('', 'Custom', []), /company/);
});

test('creating line types persists the shared Type catalog, avoids duplicates and preserves legacy references', async () => {
  const f = fixture(), existing = { id: 'unrelated', type: 'department_code', value: 'OPS' };
  f.put('lookup_values', [existing]);
  const [first, second] = await Promise.all([f.createInvoiceLineType(company.id, '  Transport  fee '), f.createInvoiceLineType(company.id, 'transport fee')]);
  assert.deepEqual(first, second); assert.equal(first.value, 'Transport fee');
  assert.deepEqual(f.get('lookup_values'), [existing]);
  assert.equal(f.configuredLineTypes.loadInvoiceLineTypeCatalog().at(-1).code, 'Transport fee');
  await f.createInvoiceLineType(company.id, ' SERVICE ');
  assert.equal(f.configuredLineTypes.loadInvoiceLineTypeCatalog().length, 4);
  assert.deepEqual(f.configuredLineTypes.invoiceLineTypeValues('other-company', f.get('lookup_values')), ['Service', 'Product', 'Code', 'Transport fee']);
  assert.deepEqual(f.configuredLineTypes.invoiceLineTypeValues(company.id, f.get('lookup_values')), ['Service', 'Product', 'Code', 'Transport fee']);
});

test('creating types rechecks permissions, company and storage without overwriting existing references', async () => {
  for (const block of [f => f.revoke(), f => f.put('companies', []), f => f.put('companies', [{ ...company, inactive: true }]), f => f.failWrite('Type')]) {
    const f = fixture(), original = [{ type: 'other', value: 'Keep' }]; f.put('lookup_values', original); block(f);
    await assert.rejects(f.createInvoiceLineType(company.id, 'Custom'));
    assert.deepEqual(f.get('lookup_values'), original);
  }
  const f = fixture(); f.put('lookup_values', { malformed: true });
  await assert.rejects(f.createInvoiceLineType(company.id, 'Custom'), /Reference values/);
  assert.deepEqual(f.get('lookup_values'), { malformed: true });
});

test('custom line types save into both Quantity and Summary and are checked against fresh company options', async () => {
  const f = fixture(); await f.createInvoiceLineType(company.id, 'Transport fee');
  const input = command(); input.draft.lines[0].type = 'Transport fee';
  const saved = await f.createInvoiceDocument(company.id, input);
  assert.equal(saved.line_items[0].line_type, 'Transport fee');
  assert.equal(saved.summary_line_items[0].line_type, 'Transport fee');
  assert.equal(f.get('documents').at(-1).line_items[0].line_type, 'Transport fee');
  for (const records of [[], [{ type: lineTypes.invoiceLineTypeScope('other-company'), value: 'Transport fee' }], [{ type: lineTypes.invoiceLineTypeScope(company.id), value: 'Transport fee', inactive: true }]]) {
    const fresh = fixture(); fresh.put('lookup_values', records);
    await assert.rejects(fresh.createInvoiceDocument(company.id, input), /active Type/);
    assert.equal(fresh.get('documents').length, 1);
  }
});

test('Type is a visible invoice column and its create dialog reuses system dropdown and buttons', () => {
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx'), picker = read('../src/components/invoices/InvoiceLineTypeSelect.tsx');
  assert.match(editor, /\{ key: 'type', label: 'Type', width: 170, visible: true \}/);
  assert.match(editor, /requiredKeys.add\('type'\)/);
  assert.match(editor, /type: value, catalogId: '', .*value !== 'Product'.*warehouseId: ''/);
  assert.match(picker, /<SearchableSelect.*portalMenu/);
  assert.match(picker, /menuAction=\{\{ label: 'Create line type'/);
  assert.doesNotMatch(picker, /Create type for|<Plus/);
  assert.match(picker, /<SaveButton/);
  assert.match(picker, /onCreate\(name\); onChange\(created\)/);
  assert.match(picker, /event.target === event.currentTarget/); assert.match(picker, /event.key === 'Escape'/);
  assert.match(picker, /if \(pending.current\) return/);
});

test('Code / Name is free text in the single invoice table, replacing Product without a catalog picker', () => {
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx');
  assert.match(editor, /key: 'type', label: 'Type', width: 170, visible: true \},\s*\{ key: 'name', label: 'Code \/ Name', width: 190, visible: true \}/);
  assert.match(editor, /const \[columns, setColumns\] = useState\(defaults\)/);
  assert.equal([...editor.matchAll(/key: 'name'/g)].length, 1);
  assert.match(editor, /if \(key === 'name'\) return <input[^\n]+type="text"[^\n]+value=\{line.name\}/);
  assert.match(editor, /name: event.target.value, catalogId: ''/);
  assert.match(editor, /invoiceQuantityColumns = documentQuantityColumns.filter\(column => column.key !== 'product'\)/);
  assert.doesNotMatch(editor, /chooseCatalog|key: 'catalogId'|catalog.filter/);
  assert.doesNotMatch(read('../src/components/invoices/CreateInvoiceForm.tsx'), /loadWarehouse|catalog=\{catalog\}/);
});

test('free-text Code / Name persists in Quantity and Summary without changing accounting values', async () => {
  const f = fixture(), input = command();
  const original = { ...input.draft.lines[0], code: 'LINE-DOC-01', catalogId: 'old-catalog-item', description: '' };
  const changed = core.updateInvoiceLine(original, { name: 'ABC-42 / Custom service – November', catalogId: '' });
  for (const key of ['code', 'quantity', 'price', 'vatRate', 'glAccount', 'vatClassifier', 'unit']) assert.equal(changed[key], original[key]);
  input.draft.lines = [changed];
  input.draft.allocations = [{ ...changed, id: 'allocation-1', name: 'Administration allocation' }];
  const saved = await f.createInvoiceDocument(company.id, input);
  assert.equal(saved.line_items[0].product, 'ABC-42 / Custom service – November');
  assert.equal(saved.summary_line_items[0].product, 'Administration allocation');
  assert.equal(saved.line_items[0].code, 'LINE-DOC-01');
  assert.equal(saved.total_amount, '121.00');
  assert.equal(f.get('documents').at(-1).line_items[0].product, 'ABC-42 / Custom service – November');
});

test('save command adds one shared-register invoice and history, is idempotent and leaves other documents intact', async () => {
  const f = fixture(), input = command({ responsibleId: 'internal-a' });
  const original = structuredClone(f.get('documents')[0]);
  const [saved, repeated] = await Promise.all([f.createInvoiceDocument(company.id, input), f.createInvoiceDocument(company.id, input)]);
  assert.equal(saved.id, repeated.id); assert.equal(f.get('documents').length, 2);
  assert.deepEqual(f.get('documents')[0], original);
  assert.equal(f.get('documents')[1].status, 'Draft'); assert.equal(f.get('documents')[1].document_type, 'INVOICES');
  assert.equal(saved.accountable_responsible_id, 'internal-a'); assert.equal(saved.accountable_responsible, 'Test accountant');
  assert.equal(f.get('document_history').length, 1); assert.equal(f.get('document_history')[0].document_id, saved.id);
  await assert.rejects(f.createInvoiceDocument(company.id, { ...input, requestId: 'test-invoice-0002' }), /already exists/);
});

test('save persists two Summary allocations for one Quantity line and rejects unmatched allocations atomically', async () => {
  const f = fixture(), input = command();
  input.draft.allocations = core.splitInvoiceLines(input.draft.lines, ['first', 'second'].map(id => ({ ...input.draft.lines[0], id, department: id })), 'equal', {});
  const saved = await f.createInvoiceDocument(company.id, input);
  assert.equal(saved.line_items.length, 1); assert.equal(saved.summary_line_items.length, 2);
  assert.equal(f.get('documents')[1].summary_line_items[1].department, 'second');
  const next = command({ number: 'TEST-INV-002', allocations: [{ ...input.draft.lines[0], price: '1' }] });
  next.requestId = 'test-invoice-0002';
  await assert.rejects(f.createInvoiceDocument(company.id, next), /Summary amounts/);
  assert.equal(f.get('documents').length, 2); assert.equal(f.get('document_history').length, 1);
});

test('new invoice status is selected, persisted and audited without claiming payment, posting or transfer', async () => {
  assert.equal(core.newInvoiceDraft('2026-11-04').status, 'Draft');
  assert.deepEqual(core.INVOICE_CREATION_STATUSES, statuses.DOCUMENT_PROCESSING_STATUSES.filter(status => !['Paid', 'Processing', 'Transferred'].includes(status)));
  for (const status of core.INVOICE_CREATION_STATUSES) {
    const f = fixture();
    const saved = await f.createInvoiceDocument(company.id, command({ status }));
    assert.equal(saved.status, status);
    assert.equal(f.get('documents').at(-1).status, status);
    assert.equal(saved.creation_history[0].status, status);
    assert.equal(f.get('document_history')[0].action, status === 'Draft' ? 'Invoice draft created' : 'Invoice created');
    assert.match(f.get('document_history')[0].details, new RegExp(`Status: ${status}$`));
    assert.equal(saved.accounting_posting, undefined);
    assert.equal(saved.transferred_at, undefined);
  }
  for (const status of ['', undefined, 'Unknown', 'Overdue', 'Paid', 'Processing', 'Transferred', 'Approved', 'Posted']) {
    const f = fixture();
    await assert.rejects(f.createInvoiceDocument(company.id, command({ status })), /valid initial invoice status/);
    assert.equal(f.get('documents').length, 1);
    assert.equal(f.get('document_history').length, 0);
  }
  const f = fixture(); f.revoke();
  await assert.rejects(f.createInvoiceDocument(company.id, command({ status: 'Pending' })), /Create access/);
  assert.equal(f.get('documents').length, 1);
});

test('invoice header has a system status dropdown and save label follows the selected status', () => {
  const form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  const header = form.split('<header')[1].split('</header>')[0];
  assert.match(header, /<Field label="Status"><SearchableSelect ariaLabel="Invoice status" value=\{draft.status\} options=\{statusOptions\}/);
  assert.match(header, /update\('status', value\)/);
  assert.match(header, /disabled=\{readOnly \|\| busy \|\| loading \|\| !company\}/);
  assert.match(header, /portalMenu menuClassName="!z-\[5200\]"/);
  assert.match(form, /draft.status === 'Draft' \? 'Save draft' : 'Save invoice'/);
});

test('save rechecks current permissions, company, counterparty and internal-user status and handles storage failure', async () => {
  for (const block of [f => f.revoke(), f => f.deactivateParty(), f => f.deactivateUser(), f => f.put('companies', [{ ...company, inactive: true }]), f => f.failWrite()]) {
    const f = fixture(); block(f);
    await assert.rejects(f.createInvoiceDocument(company.id, command({ responsibleId: 'internal-a' })));
    assert.equal(f.get('documents').length, 1);
  }
  await assert.rejects(fixture().createInvoiceDocument('different-company', command()), /access/);
});

test('Invoices owns creation UI; the shared Documents register retains classification and access filtering', () => {
  const documents = read('../src/components/Documents.tsx'), form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.doesNotMatch(documents, /Create document manually|Create accounting note/);
  assert.match(documents, /documentTypeFilter === 'invoice' && companyId && !allCompanies && canCreateInvoice/);
  assert.match(documents, /Create invoice/); assert.match(documents, /<CreateInvoiceForm/);
  assert.match(documents, /filter\(document => allCompanies \|\| canViewCompanyDocuments/);
  assert.match(read('../src/components/invoices/InvoicesView.tsx'), /documentTypeFilter="invoice"/);
  for (const name of ['Basic information', 'Seller / Buyer information', 'Dates', 'Accounting defaults', 'Invoice lines', 'Document totals', 'Additional information', 'Attachments and notes']) assert.ok(form.includes(`title="${name}"`));
  assert.match(form, /createInvoiceDocument\(companyId/); assert.match(form, /Save draft/);
  assert.match(form, /loadCompanyGeneralLedgerAccountHierarchy\(companyId/);
  assert.match(form, /documentResponsibleOptions\(loadLinkedDirectoryUsers\('Internal users'\)\)/);
  assert.match(form, /<Field label="Invoice" required><Select label="Invoice" value=\{draft.kind\} options=\{invoiceOptions\}/);
  assert.match(form, /invoiceTypeOptions\(loadOrganizationReferenceRecords\('Document type'\)\)/);
  assert.doesNotMatch(form, /Invoice kind|\['Invoice', 'Credit note', 'Debit note'\]/);
});

test('Create invoice uses the shared system Back button and preserves save-time disabling', () => {
  const form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  const back = read('../src/components/BackNavigationButton.tsx');
  assert.match(form, /<BackNavigationButton label="Back" disabled=\{busy\} onClick=\{onClose\} \/>/);
  assert.doesNotMatch(form, /icon=\{<ArrowLeft/);
  assert.match(back, /disabled = false/);
  assert.match(back, /disabled=\{disabled\}/);
  assert.match(back, /type="button"/);
  assert.match(back, /aria-label=\{label\}/);
});

test('Accounting defaults starts expanded and contains only the four requested system fields', () => {
  const form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.match(form, /useState\(new Set\(\['basic', 'parties', 'dates', 'defaults', 'lines', 'totals'\]\)\)/);
  const section = form.split('<Section number={4}')[1].split('</Section>')[0];
  assert.deepEqual([...section.matchAll(/<Field label="([^"]+)"/g)].map(match => match[1]), [
    'VAT classifier', 'Department', 'Cost center', 'Include VAT in debt',
  ]);
  assert.match(section, /sm:grid-cols-2 lg:grid-cols-4/);
  assert.match(section, /onToggle=\{\(\) => toggle\('defaults'\)\}/);
  assert.match(section, /value=\{String\(draft.includeVatInDebt\)\}/);
  assert.match(section, /updateDefault\('includeVatInDebt', value === 'true'\)/);
});

const defaultVatOptions = [{ code: 'PVM1', rate: '21%' }, { code: 'PVM2', rate: '9' }, { code: 'PVM5', rate: '0' }];

test('Accounting defaults populate the initial line and every newly added Quantity and Summary line', () => {
  const original = core.newInvoiceDraft('2026-11-05');
  const defaults = { vatClassifier: 'PVM2', department: 'OPS', costCenter: 'OFFICE', includeVatInDebt: false };
  const updated = core.updateInvoiceAccountingDefaults(original, defaults, defaultVatOptions);
  assert.equal(original.lines[0].vatClassifier, '');
  const quantity = core.appendInvoiceLine(updated, 'quantity', defaultVatOptions, 'q2');
  const summary = core.appendInvoiceLine(quantity, 'summary', defaultVatOptions, 's3');
  for (const line of [...summary.lines, ...summary.allocations]) {
    for (const [key, value] of Object.entries(defaults)) assert.equal(line[key], value, key);
    assert.equal(line.vatRate, '9');
    assert.equal(line.quantity, '1');
  }
  assert.equal(quantity.lines[1].price, '');
  assert.equal(summary.allocations.at(-1).price, '0');
  assert.equal(summary.lines.length, 2);
  assert.equal(summary.allocations.length, 3);
  assert.equal(updated.lines.length, 1);
});

test('changing defaults updates untouched rows and tax amounts in both views, never a row override', () => {
  let draft = core.updateInvoiceAccountingDefaults(core.newInvoiceDraft('2026-11-05'),
    { vatClassifier: 'PVM1', department: 'OPS', costCenter: 'OFFICE', includeVatInDebt: true }, defaultVatOptions);
  draft.lines = [core.updateInvoiceLine(draft.lines[0], { name: 'Service', price: '100' })];
  draft = core.appendInvoiceLine(draft, 'quantity', defaultVatOptions, 'q2');
  draft.lines[1] = core.updateInvoiceLine(draft.lines[1], { price: '100', vatClassifier: 'PVM5', vatRate: '0', department: 'SALES', costCenter: '', includeVatInDebt: false });
  draft.allocations = draft.lines.map(line => ({ ...line }));
  const updated = core.updateInvoiceAccountingDefaults(draft, { vatClassifier: 'PVM2', department: 'ADMIN', costCenter: 'CENTER-2', includeVatInDebt: false }, defaultVatOptions);
  for (const rows of [updated.lines, updated.allocations]) {
    assert.equal(rows[0].vatClassifier, 'PVM2'); assert.equal(rows[0].vatRate, '9');
    assert.equal(rows[0].department, 'ADMIN'); assert.equal(rows[0].costCenter, 'CENTER-2');
    assert.equal(rows[0].includeVatInDebt, false); assert.equal(core.invoiceLineAmounts(rows[0]).vat, 900);
    assert.equal(rows[1].vatClassifier, 'PVM5'); assert.equal(rows[1].vatRate, '0');
    assert.equal(rows[1].department, 'SALES'); assert.equal(rows[1].costCenter, '');
    assert.equal(rows[1].includeVatInDebt, false);
  }
  assert.equal(core.invoiceAllocationError(updated), '');
  assert.equal(draft.lines[0].vatRate, '21');
  assert.equal(draft.lines[0].department, 'OPS');
});

test('explicit blank, false and same-as-default row choices remain independent', () => {
  let draft = core.updateInvoiceAccountingDefaults(core.newInvoiceDraft('2026-11-05'),
    { vatClassifier: 'PVM1', department: 'OPS', costCenter: 'OFFICE', includeVatInDebt: false }, defaultVatOptions);
  draft.lines[0] = core.updateInvoiceLine(draft.lines[0], { vatClassifier: '', department: '', costCenter: 'OFFICE', includeVatInDebt: false });
  draft = core.updateInvoiceAccountingDefaults(draft, { vatClassifier: 'PVM2', department: 'ADMIN', costCenter: 'CENTER-2', includeVatInDebt: true }, defaultVatOptions);
  assert.equal(core.invoiceLineVatClassifier(draft.lines[0], draft.vatClassifier), '');
  assert.equal(draft.lines[0].department, ''); assert.equal(draft.lines[0].costCenter, 'OFFICE');
  assert.equal(draft.lines[0].includeVatInDebt, false);
  const withNew = core.appendInvoiceLine(draft, 'quantity', defaultVatOptions, 'q2');
  assert.equal(withNew.lines[1].vatClassifier, 'PVM2'); assert.equal(withNew.lines[1].department, 'ADMIN');
  assert.equal(withNew.lines[1].costCenter, 'CENTER-2'); assert.equal(withNew.lines[1].includeVatInDebt, true);
});

test('a manually edited VAT rate is retained and new rows never copy another row’s rate override', () => {
  let draft = core.updateInvoiceAccountingDefaults(core.newInvoiceDraft('2026-11-05'), { vatClassifier: 'PVM1' }, defaultVatOptions);
  draft.lines[0] = core.updateInvoiceLine(draft.lines[0], { vatRate: '5', vatAmount: '5.00' });
  draft = core.updateInvoiceAccountingDefaults(draft, { vatClassifier: 'PVM2', department: 'OPS' }, defaultVatOptions);
  assert.equal(draft.lines[0].vatRate, '5'); assert.equal(draft.lines[0].vatAmount, '5.00');
  const added = core.appendInvoiceLine(draft, 'quantity', defaultVatOptions, 'q2');
  assert.equal(added.lines[1].vatRate, '9');
  const noClassifier = core.appendInvoiceLine({ ...draft, vatClassifier: '' }, 'quantity', defaultVatOptions, 'q3');
  assert.equal(noClassifier.lines[1].vatRate, '21');
});

test('saving retains inherited accounting defaults and row-specific overrides, without form-only metadata', () => {
  const input = command();
  input.draft.lines = [core.updateInvoiceLine(core.newInvoiceLine('first'), { name: 'Service', price: '100' })];
  input.draft = core.updateInvoiceAccountingDefaults(input.draft,
    { vatClassifier: 'PVM2', department: 'OPS', costCenter: 'OFFICE', includeVatInDebt: false }, defaultVatOptions);
  input.draft = core.appendInvoiceLine(input.draft, 'quantity', defaultVatOptions, 'second');
  input.draft.lines[1] = core.updateInvoiceLine(input.draft.lines[1], { name: 'Second service', price: '50', vatClassifier: '', department: 'SALES', costCenter: '', includeVatInDebt: true });
  const saved = core.prepareInvoiceDocument(input, context);
  for (const rows of [saved.line_items, saved.summary_line_items]) {
    assert.equal(rows[0].vatClass, 'PVM2'); assert.equal(rows[0].vatPct, '9');
    assert.equal(rows[0].department, 'OPS'); assert.equal(rows[0].center, 'OFFICE');
    assert.equal(rows[0].include_vat_in_debt, false);
    assert.equal(rows[1].vatClass, ''); assert.equal(rows[1].department, 'SALES');
    assert.equal(rows[1].center, ''); assert.equal(rows[1].include_vat_in_debt, true);
    assert.ok(rows.every(row => !('accountingDefaultOverrides' in row)));
  }
});

test('Accounting defaults and Add line are wired through the shared inheritance logic with current React state', () => {
  const form = read('../src/components/invoices/CreateInvoiceForm.tsx');
  const editor = read('../src/components/invoices/InvoiceLinesEditor.tsx');
  for (const key of ['vatClassifier', 'department', 'costCenter', 'includeVatInDebt']) assert.ok(form.includes(`updateDefault('${key}'`));
  assert.match(form, /setDraft\(previous => updateInvoiceAccountingDefaults\(previous, \{ \[key\]: value \}, vatOptions\)\)/);
  assert.match(editor, /setDraft\(current => appendInvoiceLine\(current, allocation \? 'summary' : 'quantity', vatOptions, lineId\)\)/);
  assert.match(editor, /select\(invoiceLineVatClassifier\(line, draft.vatClassifier\)/);
});

test('Invoice options retain active OCR invoice types and custom names, excluding other documents, other groups and inactive records', () => {
  const custom = { code: 'CUSTOM_INVOICE', fullName: 'Custom supplier invoice', parentCode: 'INVOICES', status: 'Active' };
  const configured = [...invoiceTypes, custom, { ...custom, code: 'CONTRACT', parentCode: 'CONTRACTS' }, { ...custom, code: 'DISABLED', status: 'Inactive' }];
  assert.deepEqual(core.invoiceTypeOptions(configured), [...invoiceTypes.slice(1).filter(row => row.code !== 'OTHER_INVOICE_DOCUMENT'), custom].map(row => ({ value: row.code, label: row.fullName })));
  assert.deepEqual(core.invoiceTypeOptions(configured.filter(row => row.code !== 'INVOICES')), []);
  assert.deepEqual(core.invoiceTypeOptions(configured.map(row => row.code === 'INVOICES' ? { ...row, status: 'Inactive' } : row)), []);
  for (const option of core.invoiceTypeOptions(configured)) {
    const saved = core.prepareInvoiceDocument(command({ kind: option.value }), { ...context, invoiceTypes: configured });
    assert.equal(saved.document_type, 'INVOICES'); assert.equal(saved.document_subtype, option.value);
    assert.equal(saved.total_amount, option.value === 'CREDIT_INVOICE' ? '-121.00' : '121.00');
  }
  const renamed = configured.map(row => row.code === 'CREDIT_INVOICE' ? { ...row, fullName: 'Supplier credit correction' } : row);
  assert.equal(core.prepareInvoiceDocument(command({ kind: 'CREDIT_INVOICE' }), { ...context, invoiceTypes: renamed }).total_amount, '-121.00');
});

test('Other documents cannot be selected or saved as a new invoice without changing the OCR catalog', () => {
  const before = structuredClone(invoiceTypes);
  const renamed = invoiceTypes.map(row => row.code === 'OTHER_INVOICE_DOCUMENT' ? { ...row, fullName: 'Other documents' } : row);
  for (const records of [invoiceTypes, renamed]) {
    assert.equal(core.invoiceTypeOptions(records).some(option => option.value === 'OTHER_INVOICE_DOCUMENT'), false);
    assert.throws(() => core.prepareInvoiceDocument(command({ kind: 'OTHER_INVOICE_DOCUMENT' }), { ...context, invoiceTypes: records }), /active Invoice type/);
  }
  assert.deepEqual(invoiceTypes, before);
  assert.match(read('../src/components/OrganizationReferenceValuesView.tsx'), /\["OTHER_INVOICE_DOCUMENT",/);
});

test('save re-reads OCR types and rejects removed, deactivated or wrong-group selections', async () => {
  for (const types of [invoiceTypes.filter(row => row.code !== 'INVOICE'), invoiceTypes.map(row => row.code === 'INVOICE' ? { ...row, status: 'Inactive' } : row), invoiceTypes.map(row => row.code === 'INVOICE' ? { ...row, parentCode: 'CONTRACTS' } : row), []]) {
    const f = fixture(); f.setTypes(types);
    await assert.rejects(f.createInvoiceDocument(company.id, command()), /active Invoice type/);
    assert.equal(f.get('documents').length, 1);
  }
  const f = fixture();
  f.setTypes([...invoiceTypes, { code: 'CUSTOM_INVOICE', fullName: 'Custom invoice', status: 'Active', parentCode: 'INVOICES' }]);
  const saved = await f.createInvoiceDocument(company.id, command({ kind: 'CUSTOM_INVOICE' }));
  assert.equal(saved.document_subtype, 'CUSTOM_INVOICE');
});

test('new drafts require View + Create without granting Edit or Delete on existing documents', () => {
  const permissions = {}, roleStore = new Map(); let view = true, edit = false;
  const session = { email: 'accountant@example.test', roleNames: ['Draft creator'] };
  const require = name => {
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => edit, canViewCompanyDocuments: () => view };
    if (name === './accessControl') return { parseSession: () => session, isSystemAdministratorRole: () => false };
    if (name === './currentUser') return { AUTH_SESSION_KEY: 'session' };
    if (name === './recordLifecycle') return { isInactiveRecord: row => row.inactive };
    if (name === './documentStornoAccess') return { canStornoDocument: () => false };
    if (name === './linkedSettingsData') return { loadLinkedDirectoryUsers: audience => audience === 'Internal users' ? [{ email: session.email }] : [] };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', compile('../src/lib/documentRowActionAccess.ts'))(permissions, require, { localStorage: { getItem: key => roleStore.get(key) ?? null } });
  const key = 'finansu-harmonija:v7:settings:internal:roles';
  const role = { name: 'Draft creator', actionPermissions: JSON.stringify({ documents: ['VIEW', 'CREATE'] }) };
  roleStore.set(key, JSON.stringify([role]));
  assert.equal(permissions.canCreateCompanyDocument(company), true);
  assert.deepEqual(permissions.documentActionRights(company), { create: false, delete: false, storno: false });
  view = false; assert.equal(permissions.canCreateCompanyDocument(company), false);
  view = true; roleStore.set(key, JSON.stringify([{ ...role, inactive: true }]));
  assert.equal(permissions.canCreateCompanyDocument(company), false);
  roleStore.set(key, JSON.stringify([{ ...role, actionPermissions: JSON.stringify({ documents: ['VIEW', 'EDIT'] }) }]));
  edit = true; assert.equal(permissions.canCreateCompanyDocument(company), false);
});
