import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const account = { id: 'account-a', iban: 'LT123', bank: 'SEB', glAccount: '2710' };
const company = { id: 'company-a', organization_bank_accounts: JSON.stringify([account]) };
function fixture() {
  const api = {}, storage = new Map(); let allowed = true;
  const require = name => {
    if (name === './supabase') return { supabase: { from: () => ({ select: () => ({ eq: async (_, id) => ({ data: id === company.id ? [company] : [], error: null }) }) }) } };
    if (name === './accessControl') return { parseSession: () => ({}), canEditMenu: () => allowed };
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant', AUTH_SESSION_KEY: 'session' };
    if (name === './linkedSettingsData') return { canAccessAssignedOrganization: () => allowed };
    if (name === './recordLifecycle') return { isInactiveRecord: row => Boolean(row.inactive || row.active === false) };
    throw Error(name);
  };
  const code = ts.transpileModule(read('../src/lib/companyBankSetup.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', 'window', 'CustomEvent', code)(api, require, { localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) }, dispatchEvent() {} }, class {});
  return { ...api, storage, revoke: () => { allowed = false; } };
}
test('connection provider preference is scoped to the saved account and never claims bank authorization', async () => {
  const f = fixture(), before = JSON.stringify(company);
  const saved = await f.saveBankConnectionPreference(company.id, account, 'bank');
  assert.equal(saved.status, 'Setup required'); assert.equal(saved.provider, 'bank');
  assert.deepEqual(f.readBankConnectionPreference(company.id, account), saved);
  assert.equal(f.readBankConnectionPreference('company-b', account), null);
  assert.equal(f.readBankConnectionPreference(company.id, { ...account, iban: 'CHANGED' }), null);
  assert.equal(JSON.stringify(company), before);
  for (const key of ['password', 'username', 'token', 'authorizationUrl', 'connectedAt']) assert.equal(saved[key], undefined);
});
test('connection refuses unsaved accounts, foreign companies, invalid providers and revoked access', async () => {
  const f = fixture();
  await assert.rejects(f.saveBankConnectionPreference(company.id, { ...account, id: 'missing' }, 'bank'), /Save this/);
  await assert.rejects(f.saveBankConnectionPreference('company-b', account, 'bank'), /permission/);
  await assert.rejects(f.saveBankConnectionPreference(company.id, account, 'unknown'), /Select/);
  f.revoke(); await assert.rejects(f.saveBankConnectionPreference(company.id, account, 'bank'), /permission/);
  assert.equal(f.storage.size, 0);
});
test('Bank GL selections are company-scoped while an unchanged historical selection may remain', () => {
  const f = fixture();
  assert.doesNotThrow(() => f.validateBankGlAssignments([account], ['2710'], []));
  assert.throws(() => f.validateBankGlAssignments([{ ...account, glAccount: 'OTHER-COMPANY' }], ['2710'], [account]), /company/);
  assert.doesNotThrow(() => f.validateBankGlAssignments([account], [], [account]));
  assert.doesNotThrow(() => f.validateBankGlAssignments([{ ...account, glAccount: '' }], [], [account]));
});
test('connection states are independent of synchronization results and examples never mutate company accounts', () => {
  const f = fixture();
  assert.equal(f.bankAccountConnectionStatus({ lastSyncedAt: '2026-11-12', syncError: 'Synchronization failed' }), 'Not connected');
  assert.equal(f.bankAccountConnectionStatus({ connectionStatus: 'Connected', syncError: 'Synchronization failed' }), 'Connected');
  assert.equal(f.bankAccountConnectionStatus({ connectionStatus: 'Connection error', lastSyncedAt: '2026-11-12' }), 'Connection error');
  const rows = f.bankConnectionExamples('00000000-0000-4000-8000-000000000002');
  assert.deepEqual(rows.map(row => row.connectionStatus), ['Connected', 'Not connected', 'Connection error']);
  assert.ok(rows.every(row => row.demonstration)); assert.deepEqual(f.bankConnectionExamples('company-b'), []);
  assert.equal(f.storage.size, 0);
});
test('bank card reuses existing layout and shared dropdown, no bank credentials; list retains sync controls', () => {
  const card = read('../src/components/CompanyBankAccountSetup.tsx'), manage = read('../src/components/ManageCompanyView.tsx'), list = read('../src/components/CompanyBankAccountsView.tsx');
  assert.match(card, /loadCompanyGeneralLedgerAccountHierarchy\(company.id, company.general_ledger\)/);
  assert.match(card, /Bank GL account/); assert.match(card, /Bank \/ Gateway provider/);
  assert.match(card, /Continue to bank/); assert.match(card, /role="dialog"/); assert.match(card, /<CancelButton/);
  assert.doesNotMatch(card, /type="password"|name="username"|window\.open|location\.href/);
  assert.match(manage, /section === 'Bank setup' \|\| section === 'Bank GL account'/);
  for (const text of ['Connection status', 'Primary', 'Last synchronized', 'SYNC ALL']) assert.ok(list.includes(text));
  assert.match(list, /disabled=\{syncing \|\| isInactiveRecord\(row\) \|\| row.demonstration\}/);
});
