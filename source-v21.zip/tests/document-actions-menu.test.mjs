import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import test from 'node:test';
import ts from 'typescript';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(read(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX } }).outputText;

test('document toolbar retains all five actions and gives Save the same system button as the other controls', () => {
  const detail = read('../src/components/DocumentDetailPanel.tsx');
  const toolbar = detail.slice(detail.indexOf('data-document-toolbar="true"'), detail.indexOf('{(postingLocked || testStornoLocked)'));
  assert.match(toolbar, /<PageActionButton\s+onClick=\{handleSaveChanges\}/);
  for (const label of ['Exclude from export', 'Mark as exported', 'Add note', 'Report issue']) assert.ok(toolbar.includes(label));
  assert.match(toolbar, /<PageActionButton onClick=\{\(\) => setShowIssueDialog\(true\)\}/);
  assert.match(toolbar, /disabled=\{hasBlockingDocumentIssue/);
  assert.match(toolbar, /!hasUnsavedChanges[\s\S]*!documentLoaded[\s\S]*savingChanges[\s\S]*fixingIssue/);
  assert.match(toolbar, /documentManagementActions && <div className="ml-auto shrink-0"/);
  assert.match(toolbar, /flex w-full flex-wrap items-center gap-2/);
});

test('system menu trigger preserves the neutral action style and exposes expanded state to assistive technology', () => {
  const exports = {}, require = createRequire(import.meta.url);
  new Function('exports', 'require', compile('../src/components/PageHeader.tsx'))(exports, require);
  const html = renderToStaticMarkup(React.createElement(exports.PageActionButton, { ariaLabel: 'Document actions', ariaHasPopup: 'menu', ariaExpanded: true, ariaControls: 'document-menu' }, 'Actions'));
  assert.match(html, /aria-haspopup="menu"/); assert.match(html, /aria-expanded="true"/); assert.match(html, /aria-controls="document-menu"/);
  assert.match(html, /h-8/); assert.match(html, /rounded-md/); assert.match(html, /border-2/); assert.match(html, /bg-white/);
  assert.match(html, /data-button-family="page-action"/);
});

test('document menu checks fresh company, record and permissions; ordinary history is not a deletion blocker', () => {
  const menu = read('../src/components/DocumentActionsMenu.tsx');
  assert.match(menu, /Promise\.all\(/);
  assert.match(menu, /\.eq\('id', documentId\)\.eq\('company_id', companyId\)/);
  assert.match(menu, /canViewCompanyDocuments\(company\)/);
  assert.match(menu, /canCreateCompanyDocument\(company\)/);
  assert.match(menu, /documentActionRights\(company\)/);
  assert.match(menu, /testDocumentStornoBlocker\(source, rights.storno\)/);
  assert.match(menu, /documentRowAction\(source, rights\)/);
  assert.doesNotMatch(menu, /isRecordLinked|from\('document_history'\)/);
  assert.match(menu, /if \(busy \|\| unsavedChanges \|\| loading \|\| !loaded\) return/);
  assert.match(menu, /loaded.storno && <button/);
  assert.doesNotMatch(menu, /\.delete\(|\.update\(|\.insert\(|deleteUnconfirmedDocument\(|applyDocumentStorno\(/);
});

test('actions menu is a clipped-safe right-aligned portal with shared dismissal and keyboard navigation', () => {
  const menu = read('../src/components/DocumentActionsMenu.tsx'), portal = read('../src/components/DropdownPortal.tsx');
  assert.match(menu, /useDropdownDismiss\(open, anchor, \(\) => \{[\s\S]*?setOpen\(false\);[\s\S]*?\}, menu\)/);
  assert.match(menu, /menu.current\?\.contains\(document.activeElement\).*anchor.current\?\.querySelector\('button'\)\?\.focus\(\)/);
  assert.match(menu, /role="menu"[\s\S]*align="end"/);
  for (const key of ['Escape', 'ArrowDown', 'ArrowUp', 'Home', 'End', 'Tab']) assert.ok(menu.includes(`'${key}'`));
  assert.match(menu, /role="menuitem"/);
  assert.match(portal, /createPortal\(/);
  assert.match(portal, /rect.right - next.width/);
});

test('menu actions reuse the list workflows and cleanly close a card after deletion', () => {
  const documents = read('../src/components/Documents.tsx');
  assert.match(documents, /<DocumentActionsMenu documentId=\{activeDocument.id\} companyId=\{activeDocument.companyId\}/);
  assert.match(documents, /onAction=\{kind => openDocumentAction\(activeDocument, kind\)/);
  assert.match(documents, /onDuplicate=\{record => \{ closeDocument\(\); setDuplicateSource\(mapRow\(record\)\)/);
  assert.match(documents, /onDeleted=\{id => \{ if \(activeDocument\?\.id === id\) closeDocument\(\)/);
  assert.match(documents, /rowActionDocument\?\.kind === 'storno' && <DocumentStornoDialog/);
  assert.match(documents, /<DocumentRowActionDialog documentId=\{rowActionDocument.documentId\}/);
});

test('document Actions portal renders above the manual invoice dialog, not behind it', () => {
  const menu = read('../src/components/DocumentActionsMenu.tsx');
  const portal = read('../src/components/DropdownPortal.tsx');
  const invoice = read('../src/components/invoices/CreateInvoiceForm.tsx');
  const menuLayer = Number(menu.match(/<DropdownPortal[^>]*zIndex=\{(\d+)\}/)?.[1]);
  const dialogLayer = Number(invoice.match(/role="dialog"[^>]*z-\[(\d+)\]/)?.[1]);
  assert.ok(menuLayer > dialogLayer, `Actions layer ${menuLayer} must be above invoice layer ${dialogLayer}`);
  assert.match(portal, /zIndex = 1100/);
  assert.match(portal, /style=\{\{ \.\.\.position, zIndex, visibility:/);
  assert.doesNotMatch(portal, /className="[^"]*z-\[/);
});
