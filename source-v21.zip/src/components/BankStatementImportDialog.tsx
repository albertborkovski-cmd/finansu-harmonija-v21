import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, FileText, Upload, X } from 'lucide-react';
import { importBankStatement, type Company } from '../lib/supabase';
import { companyBankAccounts } from '../lib/bankTransaction';
import { BANK_STATEMENT_MAX_BYTES, BANK_STATEMENT_TEMPLATE, parseBankStatementCsv, type StatementRow } from '../lib/bankStatementImport';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import { CancelButton, SaveButton } from './ScopedActionButtons';

type Props = { company: Company; onClose: () => void; onImported: (result: { imported: number; duplicates: number }) => void };

export default function BankStatementImportDialog({ company, onClose, onImported }: Props) {
  const titleId = useId(), root = useRef<HTMLDivElement>(null), input = useRef<HTMLInputElement>(null);
  const pending = useRef(false), alive = useRef(true), dropdownEscape = useRef(false);
  const accounts = companyBankAccounts(company);
  const [bankAccount, setBankAccount] = useState(() => (accounts.find(row => row.primary) || accounts[0])?.iban || '');
  const [file, setFile] = useState<{ name: string; text: string; rows: StatementRow[] }>();
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => {
    alive.current = true;
    const previous = document.activeElement as HTMLElement | null;
    root.current?.focus();
    const remember = (event: KeyboardEvent) => {
      if (event.key === 'Escape') dropdownEscape.current = Boolean(root.current?.querySelector('[role="combobox"][aria-expanded="true"]'));
    };
    window.addEventListener('keydown', remember, true);
    return () => { alive.current = false; window.removeEventListener('keydown', remember, true); previous?.focus(); };
  }, []);
  const close = () => { if (!pending.current) onClose(); };
  async function chooseFile(selected?: File) {
    if (!selected || pending.current) return;
    pending.current = true; setBusy(true); setFile(undefined); setError('');
    try {
      if (!selected.name.toLowerCase().endsWith('.csv') || selected.size > BANK_STATEMENT_MAX_BYTES) throw new Error('Choose a CSV file up to 2 MB.');
      const text = await selected.text(), rows = parseBankStatementCsv(text);
      if (alive.current) setFile({ name: selected.name, text, rows });
    } catch (cause) { if (alive.current) setError(cause instanceof Error ? cause.message : 'Could not read the statement.'); }
    finally { pending.current = false; if (alive.current) setBusy(false); }
  }
  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (pending.current || !file || !bankAccount) return;
    pending.current = true; setBusy(true); setError('');
    try { const result = await importBankStatement(company.id, bankAccount, file.text, file.name); if (alive.current) onImported(result); }
    catch (cause) { if (alive.current) setError(cause instanceof Error ? cause.message : 'Could not import the statement.'); }
    finally { pending.current = false; if (alive.current) setBusy(false); }
  }
  function downloadTemplate() {
    const url = URL.createObjectURL(new Blob(['\uFEFF', BANK_STATEMENT_TEMPLATE], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = 'bank-statement-template.csv'; link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat" onClick={event => { if (event.target === event.currentTarget) close(); }} onKeyDown={event => {
    event.stopPropagation();
    if (event.key === 'Escape') { if (dropdownEscape.current) return; event.preventDefault(); close(); }
    if (event.key === 'Tab' && !document.querySelector('[role="listbox"]')) {
      const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled):not([type="file"]), [tabindex="0"]')].filter(node => node.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && (document.activeElement === first || document.activeElement === root.current)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === root.current)) { event.preventDefault(); first?.focus(); }
    }
  }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90vh] w-full max-w-[1000px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white text-[#10233A] shadow-xl outline-none">
      <header className="flex items-center justify-between gap-4 border-b border-[#D3E1EC] px-5 py-4"><div><h2 id={titleId} className="text-[18px] font-semibold">Import statement</h2><p className="mt-1 text-[11px] text-[#7288A3]">{company.name}</p></div><button type="button" aria-label="Close statement import" disabled={busy} onClick={close} className="rounded-md p-1 text-[#7288A3] hover:bg-[#F2F5F9] hover:text-[#007EA7] disabled:opacity-50"><X size={19} /></button></header>
      <form onSubmit={event => void save(event)} className="flex min-h-0 flex-col">
        <div className="space-y-4 overflow-y-auto p-5">
          <div className="space-y-1.5 text-[11px] font-medium text-[#7288A3]"><span>Bank account *</span><SearchableSelect ariaLabel="Statement bank account" value={bankAccount} onChange={setBankAccount} disabled={busy} options={accounts.map(account => ({ value: account.iban, label: `${account.bank || 'Bank'} · ${account.iban}` }))} portalMenu menuClassName="!z-[5500]" className="h-9 w-full rounded-md border border-[#D3E1EC] bg-white px-3 pr-9 text-[12px] text-[#10233A]" /></div>
          {!accounts.length && <p className="text-[12px] text-[#926317]">Add a bank account in this company’s Bank accounts settings before importing.</p>}
          <div className="rounded-lg border border-dashed border-[#A1B6C6] bg-[#F8FDFF] px-5 py-6 text-center" onDragOver={event => { event.preventDefault(); }} onDrop={event => { event.preventDefault(); if (event.dataTransfer.files.length > 1) setError('Choose one statement at a time.'); else void chooseFile(event.dataTransfer.files[0]); }}>
            <Upload size={24} className="mx-auto mb-2 text-[#007EA7]" /><p className="text-[12px] font-medium">Drop a CSV statement here or select a file</p><p className="mt-1 text-[11px] text-[#7288A3]">Up to 2 MB · 1,000 transactions · Use the template column headings</p>
            <div className="mt-4 flex flex-wrap justify-center gap-2"><PageActionButton icon={<Upload size={15} />} disabled={busy} onClick={() => input.current?.click()}>Select file</PageActionButton><PageActionButton icon={<Download size={15} />} onClick={downloadTemplate}>CSV template</PageActionButton></div>
            <input ref={input} type="file" accept=".csv,text/csv" aria-label="Bank statement file" className="hidden" disabled={busy} onChange={event => { void chooseFile(event.target.files?.[0]); event.target.value = ''; }} />
          </div>
          {file && <section aria-label="Statement preview" className="space-y-2"><div className="flex items-center gap-2 text-[12px]"><FileText size={16} className="shrink-0 text-[#007EA7]" /><span className="truncate font-semibold">{file.name}</span><span className="ml-auto shrink-0 text-[#7288A3]">{file.rows.length} transactions</span></div>
            <div className="max-h-[300px] overflow-auto rounded-lg border border-[#D3E1EC]"><table className="w-full min-w-[740px] border-collapse text-left text-[11px]"><thead className="sticky top-0 bg-[#F2F5F9] text-[#7288A3]"><tr>{['Date', 'Counterparty name', 'Purpose of payment', 'Amount', 'Currency', 'Reference No.'].map(name => <th key={name} className="whitespace-nowrap px-3 py-2.5 font-semibold">{name}</th>)}</tr></thead><tbody>{file.rows.slice(0, 50).map((row, index) => <tr key={index} className="border-t border-[#E5EDF9] odd:bg-[#F8FDFF]"><td className="whitespace-nowrap px-3 py-2">{row.date}</td><td className="max-w-[180px] truncate px-3 py-2" title={row.counterpartyName}>{row.counterpartyName}</td><td className="max-w-[240px] truncate px-3 py-2" title={row.paymentPurpose}>{row.paymentPurpose}</td><td className="whitespace-nowrap px-3 py-2 tabular-nums">{Number(row.amount) > 0 ? '+' : '−'}{Math.abs(Number(row.amount)).toFixed(2)}</td><td className="px-3 py-2">{row.currency}</td><td className="max-w-[140px] truncate px-3 py-2" title={row.referenceNo}>{row.referenceNo || '—'}</td></tr>)}</tbody></table></div>
            {file.rows.length > 50 && <p className="text-[11px] text-[#7288A3]">Showing the first 50 transactions. All {file.rows.length} will be imported.</p>}
          </section>}
          <p className="text-[11px] leading-5 text-[#7288A3]">Imported transactions are saved as New and Unmatched. Assign GL accounts and review them afterwards. Previously imported transactions are skipped.</p>
          {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{error}</p>}
        </div>
        <footer className="flex flex-wrap justify-end gap-3 border-t border-[#D3E1EC] px-5 py-4"><CancelButton onClick={close} className="!h-9 !text-[12px]" /><SaveButton type="submit" disabled={busy || !file || !bankAccount} className="!h-9 !gap-2 !text-[12px]"><Upload size={14} />{busy ? 'Processing…' : 'Import statement'}</SaveButton></footer>
      </form>
    </div>
  </div>, document.body);
}
