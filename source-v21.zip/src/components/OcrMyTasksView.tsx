import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { canEditMenu, canViewMenu } from '../lib/accessControl';
import { canReviewDocumentIssues, documentIssueSession } from '../lib/documentIssueAccess';
import { canEditCompanyDocuments } from '../lib/documentEditAccess';
import { canAccessAssignedOrganization } from '../lib/linkedSettingsData';
import { findSavedReviewDocumentTask, OCR_REVIEW_DOCUMENT_TASK_KEYS } from '../lib/ocrReviewDocuments';
import { myOcrTasks, assignedOcrDocumentIds, requireAssignedOcrTask, type MyOcrTask } from '../lib/ocrMyTasks';
import { OCR_DOCUMENT_WORK_LOG_KEY, type OcrDocumentWorkLog } from './ocrDocumentWorkTimeStore';
import { WorkspaceDocumentEditor, type WorkspaceTask } from './WorkspaceView';
import { ProcessedDocumentsTable, type ReviewDocumentReference } from './OcrProcessedDocumentsView';
import DocumentDetailPanel from './DocumentDetailPanel';
import { mapRow } from './Documents';
import { PageHeader } from './PageHeader';
import OcrBreadcrumb from './OcrBreadcrumb';

const WORKSPACE_TASKS_KEY = 'finansu-harmonija:v12:workspace:review-document-tasks';
const readCollection = <T,>(key: string, forWrite = false): Record<string, T> => {
  try {
    const value = JSON.parse(localStorage.getItem(key) || '{}');
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid task collection');
    return value;
  } catch {
    if (forWrite) throw new Error('Unable to read the saved tasks. No existing work has been overwritten.');
    return {};
  }
};

export default function OcrMyTasksView() {
  const [rows, setRows] = useState<MyOcrTask[]>([]);
  const [editing, setEditing] = useState<MyOcrTask | null>(null);
  const [documentQueue, setDocumentQueue] = useState<ReviewDocumentReference[]>([]);
  const [documentIndex, setDocumentIndex] = useState(-1);
  const [workspaceHeaderActions, setWorkspaceHeaderActions] = useState<HTMLDivElement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const opening = useRef(false);
  const load = useCallback(async () => {
    try {
      const [docs, organizations] = await Promise.all([supabase.from('documents').select('*'), supabase.from('companies').select('*')]);
      if (docs.error || organizations.error) throw new Error(docs.error?.message || organizations.error?.message);
      const session = documentIssueSession();
      if (!session || !canViewMenu(session, 'ocr-workspace-my-tasks')) { setRows([]); return []; }
      const allowed = (organizations.data as unknown as Company[] ?? []).filter(company => canAccessAssignedOrganization(company, session));
      const names = new Map(allowed.map(company => [company.id, company.name]));
      const documents = (docs.data as unknown as DbDocument[] ?? []).filter(document => names.has(document.company_id ?? ''));
      const collections = OCR_REVIEW_DOCUMENT_TASK_KEYS.map(key => readCollection<WorkspaceTask>(key));
      const tasks = new Map(documents.flatMap(document => {
        const task = findSavedReviewDocumentTask({ id: document.id, companyId: document.company_id }, collections);
        return task ? [[document.id, task] as const] : [];
      }));
      const workLog = readCollection<OcrDocumentWorkLog[string]>(OCR_DOCUMENT_WORK_LOG_KEY);
      const next = myOcrTasks(documents, names, session.email, tasks, workLog, {
        documents: canViewMenu(session, 'ocr-workspace') || canViewMenu(session, 'ocr-review-approve-documents'),
        issues: canReviewDocumentIssues(),
      });
      setRows(next); setError('');
      return next;
    } catch (reason) { setRows([]); setError(reason instanceof Error ? reason.message : 'Unable to load your tasks.'); return []; }
    finally { setLoading(false); }
  }, []);
  useEffect(() => {
    void load();
    const refresh = () => { void load(); };
    const events = ['storage', 'finansu-harmonija:persistent-state-changed', 'finansu-harmonija:data-changed', 'finansu-harmonija:settings-data-changed', 'document-issues-changed'];
    events.forEach(event => window.addEventListener(event, refresh));
    return () => events.forEach(event => window.removeEventListener(event, refresh));
  }, [load]);
  const documentIds = useMemo(() => assignedOcrDocumentIds(rows), [rows]);
  const requireEditAccess = async (task: MyOcrTask) => {
    const session = documentIssueSession();
    if (!session || !canViewMenu(session, 'ocr-workspace-my-tasks')) throw new Error('You no longer have access to My tasks.');
    if (task.issue) {
      const result = await supabase.from('companies').select('*').eq('id', task.document.company_id);
      const company = (result.data as unknown as Company[] | null)?.[0];
      if (result.error || !company || !canAccessAssignedOrganization(company, session) || !canReviewDocumentIssues() || !canEditCompanyDocuments(company))
        throw new Error('You no longer have Edit access to this task.');
    } else if (!canEditMenu(session, 'ocr-workspace') && !canEditMenu(session, 'ocr-review-approve-documents')) {
      throw new Error('You no longer have Edit access to this task.');
    }
  };
  const open = async (document: ReviewDocumentReference, index: number, queue: ReviewDocumentReference[]) => {
    if (opening.current) return;
    opening.current = true;
    try {
      const current = requireAssignedOcrTask(await load(), document);
      await requireEditAccess(current);
      setDocumentQueue(queue); setDocumentIndex(index); setEditing(current);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to open task.'); }
    finally { opening.current = false; }
  };
  const run = async (documents: ReviewDocumentReference[], status: 'Processing' | 'Accepted') => {
    try {
      const current = await load();
      for (const document of documents) await requireEditAccess(requireAssignedOcrTask(current, document));
      const result = await supabase.from('documents').update({ status }).in('id', documents.map(document => document.id));
      if (result.error) throw new Error(result.error.message);
      window.dispatchEvent(new CustomEvent('finansu-harmonija:data-changed'));
      setNotice(status === 'Processing' ? documents[0].name + ' started.' : documents.length + ' document(s) processed and approved.');
      await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to process these documents.'); }
  };
  const close = () => { setEditing(null); setDocumentQueue([]); setDocumentIndex(-1); void load(); };
  const hasNextFile = documentIndex >= 0 && documentIndex < documentQueue.length - 1;
  if (editing && !editing.issue) return <WorkspaceDocumentEditor key={editing.document.id}
    documentName={editing.document.file_case || editing.document.number} documentId={editing.document.id} companyId={editing.document.company_id}
    savedTask={editing.savedTask} filePosition={documentIndex + 1} fileTotal={documentQueue.length} onBack={close}
    onSave={task => {
      const tasks = readCollection<WorkspaceTask>(WORKSPACE_TASKS_KEY, true);
      localStorage.setItem(WORKSPACE_TASKS_KEY, JSON.stringify({ ...tasks, [editing.document.id]: task }));
      window.dispatchEvent(new CustomEvent('finansu-harmonija:persistent-state-changed', { detail: { storageKey: WORKSPACE_TASKS_KEY } }));
    }}
    onNextFile={hasNextFile ? () => open(documentQueue[documentIndex + 1], documentIndex + 1, documentQueue) : undefined} />;
  return <div className="relative flex min-h-full min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
    <PageHeader title="My tasks" actions={<div ref={setWorkspaceHeaderActions} className="flex items-center" />} />
    <OcrBreadcrumb items={['Workspace', 'My tasks']} />
    {error && <p role="alert" className="rounded-lg bg-[#FFF0F0] px-3 py-2 text-sm text-[#B42318]">{error}</p>}
    <ProcessedDocumentsTable embedded showAllDocuments selectable documentIds={documentIds}
      importActionContainer={workspaceHeaderActions} selectionActionVariant="run"
      onRefreshDocuments={load} onImportDocuments={documents => run(documents, 'Accepted')}
      onEditDocument={(document, index, queue) => void open(document, index, queue)} onRunDocument={document => run([document], 'Processing')}
      emptyMessage={loading ? 'Loading your tasks…' : 'No active assigned documents match the selected filters.'} />
    {notice && <div role="status" className="fixed bottom-6 right-6 z-[240] rounded-lg bg-[#E7F7EF] px-5 py-3 font-montserrat text-[13px] font-semibold text-[#237A50] shadow-lg">{notice}</div>}
    {editing?.issue && <DocumentDetailPanel key={editing.id} doc={mapRow(editing.document)} reportedIssueId={editing.issue.id}
      companyName={editing.cells.organization} onClose={close} onSaved={() => void load()} onIssueFixed={close} />}
  </div>;
}
