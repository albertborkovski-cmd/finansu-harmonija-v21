import { useEffect, useId, useRef, useState } from 'react';
import { History } from 'lucide-react';
import { loadDocumentActionHistory, loadHistoryRelatedDocument, type DbDocument } from '../lib/supabase';
import type { DocumentActionHistoryRow, DocumentHistoryReference } from '../lib/documentActionHistory';
import { SETTINGS_DATA_CHANGED_EVENT } from '../lib/linkedSettingsData';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import { DocumentStornoDialog } from './DocumentStornoAction';

type Props = {
  documentId: string;
  companyId: string;
  onOpenRelatedDocument?: (document: DbDocument) => void;
  unsavedChanges?: boolean;
  busy?: boolean;
};
const dateLabel = (value: string) => {
  const date = new Date(value);
  return Number.isFinite(date.getTime()) ? date.toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Not recorded';
};

export default function DocumentActionHistory({ documentId, companyId, onOpenRelatedDocument, unsavedChanges = false, busy = false }: Props) {
  const titleId = useId(), scrollRef = useRef<HTMLDivElement>(null), navigation = useRef(0);
  const [rows, setRows] = useState<DocumentActionHistoryRow[]>([]);
  const [loading, setLoading] = useState(true), [opening, setOpening] = useState(false), [error, setError] = useState('');
  const [stornoDocumentId, setStornoDocumentId] = useState<string>();
  useEffect(() => {
    let current = true, request = 0;
    setRows([]); setError(''); setLoading(true); setOpening(false); setStornoDocumentId(undefined);
    const refresh = async () => {
      const version = ++request;
      try {
        const result = await loadDocumentActionHistory(documentId, companyId);
        if (current && request === version) { setRows(result); setError(''); }
      } catch (cause) {
        if (current && request === version) { setRows([]); setError(cause instanceof Error ? cause.message : 'Could not load action history.'); }
      } finally { if (current && request === version) setLoading(false); }
    };
    const onDataChange = (event: Event) => {
      const table = (event as CustomEvent<{ table?: string }>).detail?.table;
      if (!table || ['documents', 'document_history', 'companies'].includes(table)) void refresh();
    };
    const onStorage = () => { void refresh(); };
    void refresh();
    window.addEventListener('finansu-harmonija:data-changed', onDataChange);
    window.addEventListener(SETTINGS_DATA_CHANGED_EVENT, onStorage);
    window.addEventListener('storage', onStorage);
    return () => {
      current = false; navigation.current += 1;
      window.removeEventListener('finansu-harmonija:data-changed', onDataChange);
      window.removeEventListener(SETTINGS_DATA_CHANGED_EVENT, onStorage);
      window.removeEventListener('storage', onStorage);
    };
  }, [documentId, companyId]);

  async function openReference(reference: DocumentHistoryReference) {
    if (busy || opening || !reference.available) return;
    if (unsavedChanges) { setError('Save or cancel your changes before opening a related document.'); return; }
    const version = ++navigation.current;
    setOpening(true); setError('');
    try {
      const document = await loadHistoryRelatedDocument(documentId, reference.documentId, companyId);
      if (version !== navigation.current) return;
      if (reference.kind === 'storno') {
        if (!document.document_storno && !document.accounting_storno) throw new Error('The Storno record is no longer available.');
        setStornoDocumentId(document.id);
      } else onOpenRelatedDocument?.(document);
    } catch (cause) { if (version === navigation.current) setError(cause instanceof Error ? cause.message : 'Could not open the related document.'); }
    finally { if (version === navigation.current) setOpening(false); }
  }

  return <section aria-labelledby={titleId} className="min-w-0 overflow-hidden rounded-lg border border-[#D3E1EC] bg-white font-montserrat">
    <h3 id={titleId} className="flex items-center gap-2 border-b border-[#D3E1EC] bg-[#F2F5F9] px-4 py-3 text-[12px] font-semibold text-[#10233A]"><History size={15} aria-hidden="true" />Action history</h3>
    {error && <p role="alert" className="m-3 rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{error}</p>}
    <div ref={scrollRef} className="max-h-[320px] overflow-auto" tabIndex={0} aria-label="Document action history" aria-busy={loading}>
      <table className="w-full min-w-[850px] border-collapse text-left text-[12px] leading-[18px]">
        <thead className="sticky top-0 z-10 bg-white text-[#7288A3]"><tr>{['Date', 'User', 'Action', 'Details', 'Related documents'].map(label => <th key={label} scope="col" className="border-b border-[#D3E1EC] px-4 py-2.5 font-medium whitespace-nowrap">{label}</th>)}</tr></thead>
        <tbody className="text-[#10233A]">
          {!rows.length && <tr><td colSpan={5} className="px-4 py-6 text-center text-[#7288A3]">{loading ? 'Loading action history…' : 'No actions recorded yet'}</td></tr>}
          {rows.map(row => <tr key={`${row.documentId}:${row.id}`} className="border-b border-[#E5EDF9] last:border-0 odd:bg-[#F8FDFF]">
            <td className="w-[160px] whitespace-nowrap px-4 py-3 align-top"><time dateTime={Number.isFinite(Date.parse(row.at)) ? row.at : undefined}>{dateLabel(row.at)}</time></td>
            <td className="w-[155px] px-4 py-3 align-top">{row.actor}</td>
            <td className="w-[160px] px-4 py-3 align-top font-medium">{row.action}</td>
            <td className="min-w-[200px] px-4 py-3 align-top whitespace-pre-wrap break-words">{row.details || '—'}</td>
            <td className="w-[170px] px-4 py-3 align-top"><div className="flex flex-col items-start gap-1.5">{row.related.length ? row.related.map(reference => reference.available && (reference.kind === 'storno' || onOpenRelatedDocument)
              ? <button key={`${reference.kind}:${reference.documentId}`} type="button" aria-label={`View document ${reference.label}`} disabled={busy || opening} onClick={() => void openReference(reference)} className="text-left font-medium text-[#007EA7] hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] disabled:opacity-50">{reference.label}</button>
              : <span key={`${reference.kind}:${reference.documentId}`} className="text-[#7288A3]">{reference.label}{reference.deleted ? ' (Deleted)' : ''}</span>) : '—'}</div></td>
          </tr>)}
        </tbody>
      </table>
    </div>
    <HorizontalTableScrollbar scrollRef={scrollRef} fixed={false} expandable={false} className="px-3 py-2" />
    {stornoDocumentId && <DocumentStornoDialog documentId={stornoDocumentId} companyId={companyId} onClose={() => setStornoDocumentId(undefined)} />}
  </section>;
}
