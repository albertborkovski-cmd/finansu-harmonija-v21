import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, X } from 'lucide-react';
import { isOcrAdditionalInformationShortcut, ocrAdditionalInformationKey, readOcrAdditionalInformation, type OcrAdditionalInformation as AdditionalInformation } from '../lib/ocrAdditionalInformation';

const fields = [
  ['departmentCode', 'Department code', 'Enter department code'],
  ['object', 'Object', 'Enter object'],
  ['project', 'Project', 'Enter project'],
  ['costCenter', 'Cost center', 'Enter cost center'],
  ['glAccount', 'GL account', 'Enter GL account'],
  ['accountablePerson', 'Accountable person', 'Enter accountable person'],
  ['productGroup', 'Product group', 'Enter product group'],
  ['vatClassifier', 'VAT classifier', 'Enter VAT classifier'],
  ['source', 'Source', 'Email or SharePoint folder'],
] as const;
const options = [
  { key: 'detailedSplitting', label: 'Detailed document splitting', description: 'Send the OCR system an instruction to split the document into individual lines.' },
  { key: 'duplicatesAccepted', label: 'Accept duplicate documents', description: 'Allow documents identified as duplicates to continue through OCR processing.' },
] as const;

/** One company-scoped shortcut and form for Dashboard and every All documents tab. */
export default function OcrAdditionalInformation({ companyId, companyName }: { companyId: string; companyName: string }) {
  const [draft, setDraft] = useState<AdditionalInformation | null>(null);
  const [error, setError] = useState('');
  const root = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const open = draft !== null;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target instanceof Element ? event.target : null;
      const typing = Boolean(target?.closest('input, textarea, select, [contenteditable]:not([contenteditable="false"]), [role="textbox"], [role="combobox"]'));
      if (open || !isOcrAdditionalInformationShortcut(event, typing)) return;
      const otherDialog = [...document.querySelectorAll<HTMLElement>('[role="dialog"], [aria-modal="true"]')].some(element => element.getClientRects().length && getComputedStyle(element).visibility !== 'hidden');
      if (otherDialog) return;
      event.preventDefault();
      setError('');
      setDraft(readOcrAdditionalInformation(window.localStorage, companyId));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [companyId, open]);

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    root.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopImmediatePropagation();
        setDraft(null);
      } else if (event.key === 'Tab') {
        const controls = [...(root.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), [tabindex="0"]') || [])].filter(element => element.getClientRects().length);
        const first = controls[0], last = controls.at(-1);
        if (event.shiftKey && (document.activeElement === first || document.activeElement === root.current)) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && (document.activeElement === last || document.activeElement === root.current)) { event.preventDefault(); first?.focus(); }
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => {
      window.removeEventListener('keydown', onKey, true);
      document.body.style.overflow = overflow;
      if (previous?.isConnected) previous.focus();
    };
  }, [open]);

  if (!draft) return null;
  const save = () => {
    try {
      const storageKey = ocrAdditionalInformationKey(companyId);
      window.localStorage.setItem(storageKey, JSON.stringify(draft));
      window.dispatchEvent(new CustomEvent('finansu-harmonija:persistent-state-changed', { detail: { storageKey } }));
      setDraft(null);
    } catch { setError('Additional information could not be saved. Please try again.'); }
  };

  return createPortal(
    <div className="fixed inset-0 z-[5001] flex items-center justify-center bg-[#10233A]/10 p-4 sm:p-8" onMouseDown={event => { if (event.target === event.currentTarget) setDraft(null); }}>
      <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[calc(100vh-64px)] w-full max-w-[760px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white text-[#10233A] shadow-[0_18px_50px_rgba(16,35,58,0.18)] outline-none">
        <header className="flex min-h-20 shrink-0 items-center justify-between border-b border-[#D3E1EC] px-6 py-4">
          <div><h2 id={titleId} className="font-montserrat text-[22px] font-semibold leading-8">Additional information</h2><p className="font-montserrat text-[11px] font-medium leading-4 text-[#7288A3]">{companyName} · Data for OCR digitization</p></div>
          <button type="button" aria-label="Close additional information" onClick={() => setDraft(null)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded text-[#7288A3] transition-colors hover:bg-[#F2F7FC] hover:text-[#10233A]"><X size={22} /></button>
        </header>
        <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
          {error && <p role="alert" className="mb-4 font-montserrat text-sm text-[#B42318]">{error}</p>}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {fields.map(([key, label, placeholder]) => <label key={key} className="flex min-w-0 flex-col gap-2"><span className="font-montserrat text-[13px] font-semibold leading-5">{label}</span><input value={draft[key]} onChange={event => { const value = event.target.value; setDraft(current => current ? { ...current, [key]: value } : null); }} placeholder={placeholder} className="h-[38px] w-full rounded-lg border border-[#D3E1EC] bg-white px-3 font-montserrat text-[13px] font-medium text-[#10233A] outline-none transition-colors placeholder:text-[#A1B6C6] focus:border-[#007EA7]" /></label>)}
            {options.map(option => <button key={option.key} type="button" aria-pressed={draft[option.key]} data-static-selection="true" onClick={() => setDraft(current => current ? { ...current, [option.key]: !current[option.key] } : null)} className={`flex min-h-[72px] w-full items-center gap-3 rounded-lg border border-[#D3E1EC] px-4 py-3 text-left transition-colors hover:border-[#007EA7] md:col-span-2 ${draft[option.key] ? 'bg-[#E5EDF9]' : 'bg-white hover:bg-[#F8FDFF]'}`}>
              <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${draft[option.key] ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6] bg-white'}`}>{draft[option.key] && <Check size={12} strokeWidth={2.5} className="text-white" />}</span>
              <span className="min-w-0 flex-1"><span className="block font-montserrat text-[13px] font-semibold leading-5">{option.label}</span><span className="mt-1 block whitespace-normal break-words font-montserrat text-[11px] font-medium leading-[17px] text-[#7288A3]">{option.description}</span></span>
            </button>)}
          </div>
        </div>
        <footer className="flex shrink-0 gap-4 border-t border-[#D3E1EC] bg-white px-6 py-4">
          <button type="button" onClick={save} className="flex h-[42px] flex-1 items-center justify-center rounded-lg bg-[#007EA7] font-montserrat text-[16px] font-semibold text-white transition-colors hover:bg-[#006B8E]">Save</button>
          <button type="button" onClick={() => setDraft(null)} className="flex h-[42px] flex-1 items-center justify-center rounded-lg border-2 border-[#D3E1EC] bg-white font-montserrat text-[16px] font-semibold text-[#7288A3] transition-colors hover:bg-[#F8FDFF]">Cancel</button>
        </footer>
      </div>
    </div>, document.body,
  );
}
