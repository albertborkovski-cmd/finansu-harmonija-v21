import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { companyBankAccounts } from '../lib/bankTransaction';
import { canCreateCompanyBankTransaction } from '../lib/bankTransactionCreation';
import { newPaymentDraft, paymentRelatedDocuments, saveCompanyPaymentDraft, type CompanyPayment, type PaymentDraft } from '../lib/companyPayments';
import BackNavigationButton from './BackNavigationButton';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import { PageHeader } from './PageHeader';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import SearchableSelect from './SearchableSelect';
import { loadOrganizationReferenceValues } from './OrganizationReferenceValuesView';

const control = 'h-[42px] w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3 text-[14px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10 disabled:bg-[#F2F5F9]';
function PaymentField({ label, optional = false, children }: { label: string; optional?: boolean; children: ReactNode }) {
  return <div className="min-w-0 space-y-2"><div className="text-[12px] font-medium text-[#7288A3]">{label}{optional ? <span className="ml-1">(optional)</span> : <span className="ml-1 text-[#DC2626]">*</span>}</div>{children}</div>;
}

export default function NewPaymentForm({ company, onCancel, onSaved }: { company: Company; onCancel: () => void; onSaved: (record: CompanyPayment) => void }) {
  const [draft, setDraft] = useState(() => newPaymentDraft(company.base_currency || 'EUR'));
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [discard, setDiscard] = useState(false);
  const [requestId] = useState(() => crypto.randomUUID());
  const baseline = useRef(JSON.stringify(draft)), pending = useRef(false), errorRef = useRef<HTMLParagraphElement>(null);
  const accounts = useMemo(() => companyBankAccounts(company), [company]);
  const currencies = useMemo(() => [...new Set([company.base_currency || 'EUR', ...loadOrganizationReferenceValues('Base currency')])], [company.base_currency]);
  const relatedOptions = useMemo(() => [{ value: '', label: 'None' }, ...paymentRelatedDocuments(documents, company.id).map(row => ({ value: row.id,
    label: `${row.number || row.file_case || row.id} · ${row.client_counterparty || row.document_type}`, description: `${row.document_date || ''} · ${row.total_amount || ''} ${row.currency || ''}` }))], [documents, company.id]);
  const disabled = busy || !canCreateCompanyBankTransaction(company);

  useEffect(() => {
    let active = true;
    void supabase.from('documents').select('*').eq('company_id', company.id).then(result => {
      if (!active) return;
      if (result.error) setError('Related documents could not be loaded. You can still save a draft without a related document.');
      else setDocuments(result.data as unknown as DbDocument[]);
      setLoading(false);
    }).catch(() => { if (active) { setLoading(false); setError('Related documents could not be loaded. You can still save a draft without a related document.'); } });
    return () => { active = false; };
  }, [company.id]);
  useEffect(() => { if (error) errorRef.current?.focus(); }, [error]);

  const update = (key: keyof PaymentDraft, value: string) => setDraft(previous => ({ ...previous, [key]: value }));
  const close = () => { if (!pending.current) { if (baseline.current !== JSON.stringify(draft)) setDiscard(true); else onCancel(); } };
  const save = async (event: FormEvent) => {
    event.preventDefault();
    if (pending.current || disabled) return;
    pending.current = true; setBusy(true); setError('');
    try { onSaved(await saveCompanyPaymentDraft(company.id, requestId, draft)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Payment draft could not be saved.'); }
    finally { pending.current = false; setBusy(false); }
  };

  return <div data-new-payment-screen className="flex min-w-0 flex-col gap-6 bg-white px-4 py-14 font-montserrat text-[#10233A] sm:px-8 lg:px-[72px]">
    <PageHeader title="New payment" leading={<BackNavigationButton iconOnly label="Back to Payments" onClick={close} disabled={busy} />}
      afterTitle={<span className="shrink-0 rounded-full bg-[#E5EDF9] px-3 py-1 text-[11px] font-semibold text-[#007EA7]">Draft</span>} />
    <CompanyBreadcrumb companyName={company.name} items={['Bank', 'Payments', 'New payment']} />
    <form onSubmit={save} className="min-w-0 space-y-5">
      {error && <p ref={errorRef} tabIndex={-1} role="alert" className="rounded-lg border border-[#F0CAC7] bg-[#FFF5F4] px-4 py-3 text-[12px] text-[#B42318]">{error}</p>}
      <section className="overflow-visible rounded-lg border border-[#D3E1EC]">
        <h2 className="rounded-t-lg bg-[#F2F5F9] px-4 py-3 text-[14px] font-semibold">1. Payment details</h2>
        <fieldset disabled={disabled} className="m-0 grid min-w-0 grid-cols-1 gap-5 border-0 p-4 sm:grid-cols-2 xl:grid-cols-4">
          <PaymentField label="Debtor bank account"><SearchableSelect ariaLabel="Debtor bank account" value={draft.debtorAccount} options={accounts.map(account => ({ value: account.iban, label: `${account.bank || 'Bank'} · ${account.iban}` }))}
            placeholder="Select bank account" disabled={disabled} onChange={value => update('debtorAccount', value)} portalMenu className={`${control} pr-9`} />
            {!accounts.length && <p className="text-[11px] text-[#926317]">Add a company bank account in Bank → Bank accounts.</p>}</PaymentField>
          <PaymentField label="Execution date"><input aria-label="Execution date" type="date" required value={draft.executionDate} onChange={event => update('executionDate', event.target.value)} className={control} /></PaymentField>
          <PaymentField label="Amount"><input aria-label="Payment amount" inputMode="decimal" required maxLength={20} placeholder="0.00" value={draft.amount} onChange={event => update('amount', event.target.value)} className={`${control} tabular-nums`} /></PaymentField>
          <PaymentField label="Currency"><SearchableSelect ariaLabel="Payment currency" value={draft.currency} options={currencies} onChange={value => update('currency', value)} disabled={disabled} portalMenu className={`${control} pr-9`} /></PaymentField>
        </fieldset>
      </section>
      <section className="overflow-visible rounded-lg border border-[#D3E1EC]">
        <h2 className="rounded-t-lg bg-[#F2F5F9] px-4 py-3 text-[14px] font-semibold">2. Beneficiary & payment purpose</h2>
        <fieldset disabled={disabled} className="m-0 grid min-w-0 grid-cols-1 gap-5 border-0 p-4 sm:grid-cols-2">
          <PaymentField label="Beneficiary"><input aria-label="Beneficiary" required maxLength={300} value={draft.counterparty} onChange={event => update('counterparty', event.target.value)} className={control} /></PaymentField>
          <PaymentField label="Beneficiary IBAN"><input aria-label="Beneficiary IBAN" required maxLength={42} autoCapitalize="characters" value={draft.creditorAccount} onChange={event => update('creditorAccount', event.target.value)} className={control} /></PaymentField>
          <PaymentField label="Purpose of payment"><input aria-label="Purpose of payment" required maxLength={2000} value={draft.purpose} onChange={event => update('purpose', event.target.value)} className={control} /></PaymentField>
          <PaymentField label="Related document" optional><SearchableSelect ariaLabel="Related document" value={draft.relatedDocumentId} options={relatedOptions} placeholder={loading ? 'Loading documents…' : 'Select document'}
            onChange={value => update('relatedDocumentId', value)} disabled={disabled || loading} portalMenu className={`${control} pr-9`} /></PaymentField>
        </fieldset>
      </section>
      <footer className="flex flex-wrap items-center justify-end gap-3 border-t border-[#D3E1EC] pt-5">
        {discard ? <><p className="mr-auto text-[12px]">Discard unsaved payment?</p><CancelButton onClick={() => setDiscard(false)}>Keep editing</CancelButton><SaveButton onClick={onCancel}>Discard changes</SaveButton></>
          : <><CancelButton onClick={close}>Cancel</CancelButton><SaveButton type="submit" disabled={disabled}>{busy ? 'Saving…' : 'Save draft'}</SaveButton></>}
      </footer>
    </form>
  </div>;
}
