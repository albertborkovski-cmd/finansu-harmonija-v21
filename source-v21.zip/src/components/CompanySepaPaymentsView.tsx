import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Landmark, Plus } from "lucide-react";
import type { Company } from "../lib/supabase";
import { usePersistentState } from "../hooks/usePersistentState";
import ColumnSettingsPanel, { type ColConfig } from "./ColumnSettingsPanel";
import ColumnSortButton, { useMultiColumnSort } from "./ColumnSortButton";
import CompanyBreadcrumb from "./CompanyBreadcrumb";
import HorizontalTableScrollbar from "./HorizontalTableScrollbar";
import OcrSearchField from "./OcrSearchField";
import { PageActionButton, PageHeader } from "./PageHeader";
import RefreshAllButton from "./RefreshAllButton";
import { ColumnSettingsButton } from "./ScopedActionButtons";
import SystemAddFilters from "./SystemAddFilters";
import TablePagination from "./TablePagination";
import { ResizeHandle, useColumnResize } from "./useColumnResize";
import { canCreateCompanyBankTransaction } from '../lib/bankTransactionCreation';
import { companyPaymentsKey, loadCompanyPayments, PAYMENTS_CHANGED, type CompanyPayment } from '../lib/companyPayments';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import NewPaymentForm from './NewPaymentForm';

const DEFAULT_COLUMNS: ColConfig[] = [
  { key: "paymentId", label: "Payment ID", width: 170, visible: true },
  { key: "executionDate", label: "Execution date", width: 160, visible: true },
  { key: "debtorAccount", label: "Debtor account", width: 210, visible: true },
  { key: "counterparty", label: "Counterparty", width: 220, visible: true },
  { key: "creditorAccount", label: "Creditor account", width: 210, visible: true },
  { key: "amount", label: "Amount", width: 140, visible: true },
  { key: "currency", label: "Currency", width: 110, visible: true },
  { key: "purpose", label: "Purpose of payment", width: 250, visible: true },
  { key: "status", label: "Status", width: 140, visible: true },
];

export default function CompanySepaPaymentsView({ company }: { company: Company }) {
  const [creating, setCreating] = useState(false);
  const [records, setRecords] = useState<CompanyPayment[]>([]);
  const [error, setError] = useState(''), [message, setMessage] = useState('');
  const [page, setPage] = useState(1);
  const [query, setQuery] = useState("");
  const [filterKeys, setFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const [showColumns, setShowColumns] = useState(false);
  const [columns, setColumns] = usePersistentState<ColConfig[]>(
    `finansu-harmonija:v12:sepa-payment-columns:${company.id}`,
    DEFAULT_COLUMNS,
  );
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const visibleColumns = columns.filter((column) => column.visible);
  const { startResize } = useColumnResize(columns, setColumns);
  const refresh = useCallback(() => {
    try { setRecords(loadCompanyPayments(company.id)); setError(''); }
    catch (cause) { setRecords([]); setError(cause instanceof Error ? cause.message : 'Payments could not be loaded.'); }
  }, [company.id]);
  useEffect(() => {
    refresh();
    const storageChanged = (event: StorageEvent) => { if (event.key === null || event.key === companyPaymentsKey(company.id)) refresh(); };
    window.addEventListener(PAYMENTS_CHANGED, refresh);
    window.addEventListener('storage', storageChanged);
    return () => { window.removeEventListener(PAYMENTS_CHANGED, refresh); window.removeEventListener('storage', storageChanged); };
  }, [company.id, refresh]);
  useEffect(() => { setCreating(false); setMessage(''); }, [company.id]);
  useEffect(() => setPage(1), [query, filterKeys, filterValues, company.id]);
  const rows = useMemo(() => records.filter(row => row.companyId === company.id), [records, company.id]);
  const filterColumns = useMemo(() => DEFAULT_COLUMNS.map(column => ({ key: column.key, label: column.label,
    options: [...new Set(rows.map(row => String(row[column.key as keyof CompanyPayment] || '—')))] })), [rows]);
  const filteredRows = useMemo(() => rows.filter(row => {
    const values = DEFAULT_COLUMNS.map(column => String(row[column.key as keyof CompanyPayment] || '—'));
    return (!query.trim() || values.some(value => value.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())))
      && filterKeys.every(key => !filterValues[key]?.length || filterValues[key].includes(String(row[key as keyof CompanyPayment] || '—')));
  }), [rows, query, filterKeys, filterValues]);
  const { sortedRows, changeSort, directionFor } = useMultiColumnSort<CompanyPayment, keyof CompanyPayment>(filteredRows,
    (row, key) => key === 'amount' ? Number(row.amount) : row[key]);
  const totalPages = Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE));
  const currentPage = Math.min(page, totalPages);
  const visibleRows = sortedRows.slice(0, currentPage * TABLE_BATCH_SIZE);
  const openNewPayment = () => {
    if (!canCreateCompanyBankTransaction(company)) { setError('You do not have permission to create payments.'); return; }
    setMessage(''); setCreating(true);
  };
  if (creating) return <NewPaymentForm key={company.id} company={company} onCancel={() => setCreating(false)} onSaved={() => {
    setCreating(false); setQuery(''); setFilterKeys([]); setFilterValues({}); setPage(1); refresh(); setMessage('Payment draft saved.');
  }} />;

  return (
    <div className="flex min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
      <PageHeader title="Payments" actions={<PageActionButton icon={<Plus size={16} />} onClick={openNewPayment} disabled={!canCreateCompanyBankTransaction(company)}>New payment</PageActionButton>} />
      <CompanyBreadcrumb companyName={company.name} items={["Bank", "Payments"]} />
      {error && <p role="alert" className="rounded-lg bg-[#FFF5F4] p-3 text-[12px] text-[#B42318]">{error}</p>}
      {message && <p role="status" className="rounded-lg bg-[#E4F4EF] p-3 text-[12px] text-[#21866A]">{message}</p>}

      <div className="flex flex-wrap items-center gap-2">
        <OcrSearchField ariaLabel="Search payments" value={query} onChange={setQuery} />
        <SystemAddFilters columns={filterColumns} activeKeys={filterKeys} values={filterValues} onActiveKeysChange={setFilterKeys} onValuesChange={setFilterValues} persistenceKey={`finansu-harmonija:v12:sepa-payment-filters:${company.id}`} />
        <div className="ml-auto flex items-center gap-4">
          <ColumnSettingsButton onClick={() => setShowColumns(true)} />
          <RefreshAllButton onRefresh={refresh} />
        </div>
      </div>

      <div ref={tableScrollRef} className="min-h-0 max-h-[65vh] flex-1 overflow-auto scrollbar-hide" tabIndex={0} aria-label="Payments table">
        <table className="w-full table-fixed border-collapse text-left font-montserrat text-[12px]" style={{ minWidth: visibleColumns.reduce((sum, column) => sum + column.width, 0) }}>
          <colgroup>{visibleColumns.map(column => <col key={column.key} style={{ width: column.width }} />)}</colgroup>
          <thead className="sticky top-0 z-10 bg-white"><tr className="system-table-header-row">
            {visibleColumns.map((column) => {
              const realIndex = columns.findIndex((item) => item.key === column.key);
              return <th scope="col" key={column.key} className="relative border-b border-[#D3E1EC] px-3 py-3 font-medium">
                <div className="flex items-center gap-1"><span>{column.label}</span>
                <ColumnSortButton columnLabel={column.label} direction={directionFor(column.key as keyof CompanyPayment)} onDirectionChange={direction => changeSort(column.key as keyof CompanyPayment, direction)} /></div>
                <ResizeHandle onMouseDown={(event) => startResize(realIndex, event)} />
              </th>;
            })}
          </tr></thead>
          <tbody>{visibleRows.map(row => <tr key={row.id} className="border-b border-[#E5EDF9] odd:bg-[#F8FDFF] hover:bg-[#E5EDF9]">
            {visibleColumns.map(column => <td key={column.key} className="px-3 py-3 text-[#10233A]">
              {column.key === 'status' ? <span className="rounded-full bg-[#E5EDF9] px-2 py-1 text-[11px] font-semibold text-[#007EA7]">{row.status}</span>
                : <span className={`block truncate ${column.key === 'amount' ? 'tabular-nums' : ''}`} title={String(row[column.key as keyof CompanyPayment] || '—')}>{String(row[column.key as keyof CompanyPayment] || '—')}</span>}
            </td>)}
          </tr>)}</tbody>
        </table>
        {!visibleRows.length && <div className="flex min-h-[260px] flex-col items-center justify-center gap-3 font-montserrat text-[#7288A3]">
            <Landmark size={30} />
            <span className="text-[14px] font-semibold">{rows.length ? 'No matching payments' : 'No payments'}</span>
            <span className="text-[12px]">{rows.length ? 'Adjust your search or filters.' : 'Create a new payment to save your first draft.'}</span>
          </div>}
      </div>

      <HorizontalTableScrollbar scrollRef={tableScrollRef} />
      <TablePagination scrollRef={tableScrollRef} currentPage={currentPage} totalPages={totalPages} itemCount={sortedRows.length} onPageChange={setPage} />
      {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={DEFAULT_COLUMNS} onSave={(next) => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
    </div>
  );
}
