import { documentEditStateError, type InlineDocumentSource } from './documentInlineEditing';
import { documentStatusOptions } from './documentProcessingStatus';

export const DOCUMENT_PURPOSE_OPTIONS = ['Purchase', 'Sale'];

export const DOCUMENT_DETAIL_HEADER_FIELDS = {
  documentType: 'document_type', type: 'type', status: 'status',
  documentDate: 'document_date', documentPurpose: 'document_purpose',
  validForm: 'valid_form', note: 'notes',
} as const;
export type DocumentDetailHeader = Record<keyof typeof DOCUMENT_DETAIL_HEADER_FIELDS, string>;

const DETAIL_FIELDS = [
  ...Object.values(DOCUMENT_DETAIL_HEADER_FIELDS), 'document_subtype',
  'client_counterparty', 'counterparty_id', 'counterparty_code', 'accountable_responsible',
  'invoice_contract_date', 'operation_date', 'due_end_date', 'number', 'order_no', 'currency',
  'amount_without_vat', 'vat', 'total_amount', 'department_code', 'object_project', 'series',
  'cost_center', 'expense_account', 'vat_classifier', 'vat_percent', 'debit', 'credit',
  'line_items', 'summary_line_items',
] as const;

export function documentDetailSnapshot(document: Record<string, unknown>) {
  return JSON.stringify({ ...Object.fromEntries(DETAIL_FIELDS.map(key => [key, document[key] ?? null])), accountable_responsible_id: document.accountable_responsible_id ?? '' });
}

export function documentDetailHeaderPatch(header: DocumentDetailHeader, previousType: string) {
  return {
    ...Object.fromEntries(Object.entries(DOCUMENT_DETAIL_HEADER_FIELDS).map(([key, db]) => [db, header[key as keyof DocumentDetailHeader]])),
    ...(header.documentType !== previousType ? { document_subtype: '' } : {}),
  };
}

/** Card edits are scoped to the document; they never modify the company or a
 * counterparty's master record, and recheck rights/state before persistence. */
export function validateDocumentDetailEdit(document: InlineDocumentSource, patch: Record<string, unknown>, expected: string, allowed: boolean) {
  if (!allowed) throw new Error('You need View and Edit access to Documents and access to this company.');
  const stateError = documentEditStateError(document);
  if (stateError) throw new Error(stateError);
  if (documentDetailSnapshot(document) !== expected) throw new Error('The document changed. Reopen it before saving your changes.');
  if (Object.keys(patch).some(key => !(DETAIL_FIELDS as readonly string[]).includes(key))) throw new Error('This field cannot be changed in the document card.');
  if ('document_type' in patch && !String(patch.document_type ?? '').trim()) throw new Error('Document type is required.');
  if ('document_purpose' in patch && patch.document_purpose !== document.document_purpose
    && !DOCUMENT_PURPOSE_OPTIONS.includes(String(patch.document_purpose ?? ''))) throw new Error('Select Purchase or Sale for Document purpose.');
  if ('status' in patch && patch.status !== document.status && !documentStatusOptions().some(option => option.value === patch.status)) throw new Error('Select a valid document status from the active options.');
}

export function documentLineNumber(value: string) {
  const numeric = value.replace(/[^\d.,-]/g, '');
  const normalized = numeric.includes('.') ? numeric.replace(/,/g, '') : numeric.replace(',', '.');
  const result = Number(normalized);
  return Number.isFinite(result) ? result : 0;
}

type FinancialLine = { qty: string; price: string; subtotal: string; discount: string; vat: string; vatPct: string; total: string };
export function recalculateDocumentLine<T extends FinancialLine>(row: T, field: 'qty' | 'price' | 'discount' | 'vatPct' | 'vat' | 'subtotal', value: string, currency: string): T {
  const next = { ...row, [field]: value };
  const baseChanged = field === 'qty' || field === 'price' || field === 'discount';
  const subtotal = baseChanged
    ? Math.round((documentLineNumber(next.qty) * documentLineNumber(next.price) - documentLineNumber(next.discount)) * 100) / 100
    : documentLineNumber(next.subtotal);
  const vat = field === 'vat' ? documentLineNumber(value) : Math.round(subtotal * documentLineNumber(next.vatPct)) / 100;
  return { ...next, subtotal: subtotal.toFixed(2), vat: `${vat.toFixed(2)} ${currency}`, total: `${(subtotal + vat).toFixed(2)} ${currency}` };
}

/** Distribute a header VAT correction proportionally, retaining every row and
 * exact cent totals. Amount stays calculated, never a directly editable input. */
export function distributeDocumentVat<T extends FinancialLine>(rows: T[], value: string, currency: string): T[] {
  const cents = Math.round(documentLineNumber(value) * 100);
  const weights = rows.map(row => Math.abs(documentLineNumber(row.subtotal)));
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  let cumulativeWeight = 0;
  let allocated = 0;
  return rows.map((row, index) => {
    cumulativeWeight += totalWeight ? weights[index] / totalWeight : 1 / rows.length;
    const cumulative = index === rows.length - 1 ? cents : Math.round(cents * cumulativeWeight);
    const vat = (cumulative - allocated) / 100;
    allocated = cumulative;
    const subtotal = documentLineNumber(row.subtotal);
    return { ...row, vat: `${vat.toFixed(2)} ${currency}`, vatPct: subtotal ? `${Number((vat / subtotal * 100).toFixed(4))}%` : row.vatPct, total: `${(subtotal + vat).toFixed(2)} ${currency}` };
  });
}
