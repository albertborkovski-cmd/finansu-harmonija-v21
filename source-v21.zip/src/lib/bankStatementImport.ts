import type { Company, DbDocument } from './supabase';
import { companyBankAccounts } from './bankTransaction';
import { newBankTransactionDocument } from './bankTransactionCreation';

export const BANK_STATEMENT_MAX_BYTES = 2 * 1024 * 1024;
export const BANK_STATEMENT_HEADERS = ['Date', 'Counterparty name', 'Purpose of payment', 'Amount', 'Currency', 'Reference No.', 'Counterparty IBAN', 'Booking date', 'Original statement text'];
export const BANK_STATEMENT_TEMPLATE = `${BANK_STATEMENT_HEADERS.join(';')}\n2026-11-01;Example customer;Payment for invoice ADV-004;894.19;EUR;REF-001;;2026-11-01;Payment for invoice ADV-004\n2026-11-02;Example supplier;Payment for invoice EXP-003;-684.86;EUR;REF-002;;2026-11-02;Payment for invoice EXP-003\n`;
export type StatementRow = { date: string; counterpartyName: string; paymentPurpose: string; amount: string; currency: string; referenceNo: string; counterpartyIban: string; bookingDate: string; originalStatement: string };
const normalize = (text: string) => text.trim().toLowerCase().replace(/[\s_.-]+/g, '');
const validDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;

/** Strict CSV reader: quoted separators/newlines are supported; no spreadsheet formulas are evaluated. */
function csvRows(text: string, separator: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], cell = '', quoted = false, closed = false;
  const finishCell = () => { row.push(cell.trim()); cell = ''; closed = false; };
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (char === '"') { quoted = false; closed = true; }
      else cell += char;
    } else if (char === separator) finishCell();
    else if (char === '\n' || char === '\r') {
      if (char === '\r' && text[i + 1] === '\n') i++;
      finishCell(); if (row.some(Boolean)) rows.push(row); row = [];
    } else if (char === '"' && !cell && !closed) quoted = true;
    else if (char === '"' || (closed && char.trim())) throw new Error('Invalid CSV quoting. Use the CSV template.');
    else if (!closed) cell += char;
    if (rows.length > 1001) throw new Error('Import a maximum of 1,000 transactions at a time.');
  }
  if (quoted) throw new Error('The CSV contains an unclosed quoted value.');
  finishCell(); if (row.some(Boolean)) rows.push(row);
  return rows;
}

export function parseBankStatementCsv(text: string): StatementRow[] {
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > BANK_STATEMENT_MAX_BYTES) throw new Error('Choose a CSV file up to 2 MB.');
  const source = text.replace(/^\uFEFF/, '');
  const firstLine = source.split(/\r?\n/, 1)[0];
  const separator = firstLine.includes(';') ? ';' : firstLine.includes('\t') ? '\t' : ',';
  const [header, ...rows] = csvRows(source, separator);
  if (!header || !rows.length) throw new Error('The statement has no transactions.');
  if (rows.length > 1000) throw new Error('Import a maximum of 1,000 transactions at a time.');
  const names = header.map(normalize);
  if (new Set(names).size !== names.length) throw new Error('The CSV contains duplicate column headings.');
  for (const name of BANK_STATEMENT_HEADERS.slice(0, 5)) if (!names.includes(normalize(name))) throw new Error(`Missing column: ${name}. Use the CSV template.`);
  return rows.map((cells, index) => {
    const fail = (message: string): never => { throw new Error(`Row ${index + 2}: ${message}`); };
    if (cells.length !== header.length) fail('column count does not match the header.');
    if (cells.some(value => value.length > 5000)) fail('a value is too long.');
    const get = (name: string) => cells[names.indexOf(normalize(name))] || '';
    for (const name of ['Counterparty name', 'Reference No.', 'Counterparty IBAN']) if (get(name).length > 500) fail(`${name} is too long.`);
    const rawAmount = get('Amount').replace(/\u2212/g, '-').replace(',', '.');
    if (!/^[+-]?\d+(?:\.\d{1,2})?$/.test(rawAmount) || !Number.isSafeInteger(Math.round(Number(rawAmount) * 100)) || Number(rawAmount) === 0) fail('enter a non-zero signed amount with up to two decimal places.');
    const date = get('Date'), bookingDate = get('Booking date');
    if (!validDate(date) || (bookingDate && !validDate(bookingDate))) fail('use valid YYYY-MM-DD dates.');
    const currency = get('Currency').toUpperCase();
    if (!/^[A-Z]{3}$/.test(currency)) fail('use a three-letter currency code.');
    if (!get('Counterparty name') || !get('Purpose of payment')) fail('counterparty name and purpose of payment are required.');
    return { date, counterpartyName: get('Counterparty name'), paymentPurpose: get('Purpose of payment'), amount: Number(rawAmount).toFixed(2), currency,
      referenceNo: get('Reference No.'), counterpartyIban: get('Counterparty IBAN'), bookingDate,
      originalStatement: get('Original statement text') || get('Purpose of payment') };
  });
}

/** Builds imported bank facts, never accounting postings or matching batches. */
export async function prepareBankStatement(company: Company, bankAccount: string, text: string, at: string, actor: string): Promise<DbDocument[]> {
  if (!companyBankAccounts(company).some(account => account.iban === bankAccount)) throw new Error('Select an active bank account belonging to this company.');
  const occurrences = new Map<string, number>();
  return Promise.all(parseBankStatementCsv(text).map(async row => {
    // Stable per-transaction identity also detects reimports with a changed filename or row order.
    const identity = JSON.stringify([company.id, bankAccount, row.date, row.counterpartyName, row.counterpartyIban, row.paymentPurpose, row.amount, row.currency, row.referenceNo]);
    const occurrence = (occurrences.get(identity) || 0) + 1; occurrences.set(identity, occurrence);
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${identity}:${occurrence}`));
    const fingerprint = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
    const id = `bank-statement-${fingerprint}`;
    const base = newBankTransactionDocument(company, id, row.date);
    const number = row.referenceNo || `BANK-${fingerprint.slice(0, 10).toUpperCase()}`;
    return { ...base, source: 'Bank import', created_at: at, created_by: actor, number, order_no: number,
      client_counterparty: row.counterpartyName, currency: row.currency, total_amount: row.amount, amount_without_vat: row.amount,
      document_purpose: row.paymentPurpose,
      bank_transaction: { ...base.bank_transaction!, ...row, bankAccount, exchangeRateDate: row.date, transferNo: number,
        allocations: [{ id: `${id}:allocation:1`, description: 'Other transaction', glAccount: '', department: '', project: '', costCenter: '', amount: row.amount }] } };
  }));
}
