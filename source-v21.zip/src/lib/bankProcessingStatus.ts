export const BANK_PROCESSING_STATUSES = ['New', 'Invalid', 'Corrected', 'Approved'] as const;
export type BankProcessingStatus = typeof BANK_PROCESSING_STATUSES[number];
type StatusSource = { id: string; bank_processing_status?: unknown };
export function isBankProcessingStatus(value: unknown): value is BankProcessingStatus {
  return typeof value === 'string' && (BANK_PROCESSING_STATUSES as readonly string[]).includes(value);
}

/** FH bank-operation workflow only: never derive this from invoice approval,
 * payment or reconciliation status. Keep the original second demo approved. */
export function bankProcessingStatus(source: StatusSource): BankProcessingStatus {
  if (isBankProcessingStatus(source.bank_processing_status)) return source.bank_processing_status;
  return source.id === '10000000-0000-4000-8000-000000000003' ? 'Approved' : 'New';
}

type MutableStatusSource = StatusSource & { company_id?: unknown; document_deletion?: unknown; inactive?: unknown; active?: unknown; is_active?: unknown };
export function bankProcessingStatusEditError(source: MutableStatusSource, allowed: boolean): string {
  if (!allowed) return 'You do not have permission to edit this company’s bank entries.';
  if (source.document_deletion) return 'The bank entry is no longer available.';
  if (source.inactive || source.active === false || source.is_active === false) return 'Inactive bank entries cannot be edited.';
  return '';
}

export function bankProcessingStatusPatch(source: MutableStatusSource, companyId: string, value: unknown, expected: string, allowed: boolean) {
  const error = bankProcessingStatusEditError(source, allowed);
  if (error) throw new Error(error);
  if (source.company_id !== companyId) throw new Error('The bank entry is no longer in this company.');
  if (!isBankProcessingStatus(value)) throw new Error('Select New, Invalid, Corrected or Approved.');
  if (bankProcessingStatus(source) !== expected) throw new Error('The bank status changed. Refresh before saving.');
  return { bank_processing_status: value };
}
