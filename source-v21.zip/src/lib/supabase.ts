import { getCurrentUserName, getCurrentUserIdentity } from './currentUser';
import { rememberLedgerTableUsage } from './generalLedgerUsage';
import { removeOrDeactivateRecords } from './recordLifecycle';
import { guardDocumentMutation, transitionDocumentIssue, type DocumentIssue, type DocumentIssueCommand, type DocumentIssueOcrRequest } from './documentIssues';
import { accountingToday, createTestDocumentStorno, guardPostedDocumentMutation as guardAccountingDocumentMutation, type TestStornoCommand, type TestDocumentStorno, type PostedDocumentOperation, type DocumentStorno, type StornoDocument } from './documentStorno';
import type { InlineDocumentField, InlineDocumentSource } from './documentInlineEditing';
import { createDocumentTestingExamples } from './documentTestingExamples';
import type { DocumentTestDelivery, TestDeliveryCommand } from './documentTestDelivery';
import type { DocumentCorrectionCommand } from './documentRowActions';
import type { CreateInvoiceCommand } from './invoiceCreation';
import type { ApprovalCancellationEvent, CancelDocumentApprovalCommand } from './documentApproval';

let administrativeWrite: Promise<void> = Promise.resolve();
// Use the existing Action history store, not a separate audit system.
export function recordAdministrativeAction(organizationId: string, category: string, action: string, details: string) {
  const user = getCurrentUserName();
  const createdAt = new Date().toISOString();
  administrativeWrite = administrativeWrite.then(async () => {
    const history = await readTable('document_history');
    const organizations = await readTable('companies');
    history.push({ id: crypto.randomUUID(), organization_id: organizationId, organization_name: organizations.find(row => row.id === organizationId)?.name || organizationId, category, action, details, user_name: user, created_at: createdAt });
    await writeTable('document_history', history);
    window.dispatchEvent(new Event('administrative-history-changed'));
  }).catch(error => { console.error('Unable to save administrative action history', error); });
  return administrativeWrite;
}

export interface Company {
  id: string;
  name: string;
  company_code: string;
  vat_code: string;
  client_since: number;
  action_required: number;
  company_status?: string;
  primary_accountant_id?: string;
  company_status_reason?: string;
  company_status_changed_at?: string;
  company_status_changed_by?: string;
  organization_status_history?: string;
  logo_url?: string;
  client_type?: string;
  address?: string;
  email?: string;
  phone?: string;
  country?: string;
  website?: string;
  assigned_accountant?: string;
  company_type?: string;
  service_scope?: string;
  kyc_status?: string;
  client_notes?: string;
  tax_country?: string;
  legal_form?: string;
  base_currency?: string;
  saas_settings?: string;
  vat_classification_template?: string;
  general_ledger?: string;
  department_codes?: string;
  objects?: string;
  projects?: string;
  document_series?: string;
  cost_centers?: string;
  product_groups?: string;
  allow_document_duplicates?: string;
  invoice_digitization?: string;
  document_splitting?: string;
  reject_non_invoices?: string;
  primary_export_format?: string;
  accounting_destination_id?: string;
  two_factor_authentication?: string;
  sharepoint_client_id?: string;
  sharepoint_client_secret?: string;
  sharepoint_tenant_id?: string;
  sharepoint_urls?: string;
  sharepoint_sync_schedule?: string;
  sharepoint_sync_time?: string;
  counterparties_settings?: string;
  organization_bank_accounts?: string;
  counterparty_country?: string;
  counterparty_legal_status?: string;
  counterparty_kind?: string;
  counterparty_vat_rate?: string;
  counterparty_vat_classification?: string;
  counterparty_notes?: string;
  counterparty_bank_accounts?: string;
  counterparty_gl_template?: string;
  counterparty_gl_accounts?: string;
  counterparty_gl_settings?: string;
  counterparty_created_by?: string;
  counterparty_created_at?: string;
  counterparty_activity_log?: string;
}

export interface DbDocument {
  bank_transaction?: import('./bankTransaction').BankTransaction;
  bank_processing_status?: import('./bankProcessingStatus').BankProcessingStatus;
  copied_from_document_id?: string;
  approval_cancellation_history?: ApprovalCancellationEvent[];
  document_deletion?: { at: string; actor: string };
  id: string;
  accounting_test_deliveries?: DocumentTestDelivery[];
  accounting_posting?: PostedDocumentOperation;
  accounting_storno?: DocumentStorno;
  document_storno?: TestDocumentStorno;
  digitization_issues?: DocumentIssue[];
  ocr_rerun_request?: DocumentIssueOcrRequest;
  ocr_rerun_requests?: DocumentIssueOcrRequest[];
  company_id?: string;
  receive_date: string;
  client_counterparty: string;
  counterparty_id?: string;
  counterparty_code?: string;
  document_type: string;
  document_subtype?: string;
  source: string;
  total_amount: string;
  due_end_date: string;
  file_case: string;
  order_no: string;
  number: string;
  type: string;
  document_date: string;
  document_purpose: string;
  invoice_contract_date: string;
  operation_date: string;
  expense_account: string;
  vat_classifier: string;
  currency: string;
  amount_without_vat: string;
  vat: string;
  vat_percent: string;
  department_code: string;
  object_project: string;
  valid_form: string;
  accountable_responsible: string;
  accountable_responsible_id?: string;
  cost_center: string;
  series: string;
  status: string;
  accounting_note_status?: string;
  debit?: string;
  credit?: string;
  created_at: string;
  created_by?: string;
  image_url: string | null;
  line_items?: Array<{
    id: string;
    barcode: string;
    systemId?: string;
    product: string;
    description?: string;
    productGroup?: string;
    unit: string;
    qty: string;
    code: string;
    price: string;
    subtotal: string;
    discount: string;
    vat: string;
    vatPct: string;
    total: string;
    department: string;
    object: string;
    series: string;
    center: string;
    expense: string;
    vatClass: string;
  }>;
  notes?: string;
  summary_line_items?: Array<{
    id: string;
    barcode: string;
    systemId?: string;
    product: string;
    productGroup?: string;
    unit: string;
    qty: string;
    code: string;
    price: string;
    subtotal: string;
    discount: string;
    vat: string;
    vatPct: string;
    total: string;
    department: string;
    object: string;
    series: string;
    center: string;
    expense: string;
    vatClass: string;
  }>;
}

type LocalRow = Record<string, unknown>;

/** Deleted documents retain their original data for audit and linked records,
 * but are never returned to working registers or accepted by write commands. */
function isAvailableDocument(row: LocalRow) { return !row.document_deletion; }
function guardPostedDocumentMutation(document: LocalRow, patch: LocalRow) {
  if (!isAvailableDocument(document)) throw new Error('This document has already been deleted.');
  if ('document_deletion' in patch) throw new Error('Use the document Delete action. Deletion history cannot be changed.');
  guardAccountingDocumentMutation(document, patch);
}
type LocalResult = {
  data: LocalRow[] | null;
  error: { message: string } | null;
};

let documentWrite: Promise<unknown> = Promise.resolve();
function serializeDocumentWrite<T>(action: () => Promise<T>): Promise<T> {
  const run = () => typeof navigator !== 'undefined' && navigator.locks
    ? navigator.locks.request('fh-v20-document-write', action) : action();
  const result = documentWrite.then(run, run);
  documentWrite = result.catch(() => undefined);
  return result;
}

/** Remember the destination immediately, independently of sending documents. */
export function saveCompanyAccountingDestination(companyId: string, destinationId: string): Promise<Company> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { canEditCompanyDocuments } = await import('./documentEditAccess');
    const { documentDeliveryDestinations } = await import('./documentExport');
    const companies = await readTable('companies');
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!company || !canEditCompanyDocuments(company)) throw new Error('You no longer have Edit access to this company’s documents.');
    if (!documentDeliveryDestinations(company.counterparties_settings).some(option => option.value === destinationId)) throw new Error('The selected accounting system is unavailable for this company.');
    if (company.accounting_destination_id === destinationId) return company;
    const saved = { ...company, accounting_destination_id: destinationId };
    await writeTable('companies', companies.map(row => row.id === companyId ? saved as unknown as LocalRow : row));
    return saved;
  });
}

/** Test-only adapter command. Uses the normal document write lock and fresh
 * access checks, but never calls an ERP connector or alters accounting state. */
export function applyDocumentTestDelivery(command: TestDeliveryCommand) {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    if (!/^[\w-]{8,80}$/.test(command.requestId) || !['accepted', 'rejected'].includes(command.scenario)) throw new Error('Invalid test transfer request.');
    const { canEditCompanyDocuments } = await import('./documentEditAccess');
    const { selectedDocumentRecords, documentDeliveryDestinations, primaryDocumentDeliveryDestination } = await import('./documentExport');
    const { createDocumentTestDelivery } = await import('./documentTestDelivery');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const company = companies.find(row => row.id === command.companyId) as unknown as Company | undefined;
    if (!company || !canEditCompanyDocuments(company)) throw new Error('You no longer have Edit access to this company’s documents.');
    if (command.destinationSource && command.destinationSource !== 'primary-export-format') throw new Error('Invalid accounting destination source.');
    const destination = command.destinationSource === 'primary-export-format'
      ? primaryDocumentDeliveryDestination(company)
      : documentDeliveryDestinations(company.counterparties_settings).find(item => item.value === command.destinationId);
    if (!destination) throw new Error('The selected accounting system is unavailable for this company.');
    if (destination.value !== command.destinationId) throw new Error('Primary export format has changed. Refresh the document list and try again.');
    const selected = selectedDocumentRecords(documents.filter(isAvailableDocument) as unknown as DbDocument[], command.ids, command.companyId);
    const previous = selected.map(document => document.accounting_test_deliveries?.find(attempt => attempt.requestId === command.requestId));
    if (previous.some(Boolean)) {
      if (!previous.every((attempt, index) => attempt?.destinationId === command.destinationId && attempt.scenario === command.scenario && attempt.sourceSnapshot === command.snapshots[selected[index].id])) throw new Error('This test request was already used for different data. Reopen the dialog.');
      return selected;
    }
    const at = new Date().toISOString(), actor = getCurrentUserName();
    const next = selected.map(document => ({ ...document, accounting_test_deliveries: [...(document.accounting_test_deliveries ?? []), createDocumentTestDelivery(document, command, destination.label, actor, at)] }));
    const byId = new Map(next.map(document => [document.id, document]));
    await writeTable('documents', documents.map(document => byId.get(String(document.id)) ?? document));
    try {
      const history = await readTable('document_history');
      const events = next.map(document => {
        const receipt = document.accounting_test_deliveries.at(-1)!;
        return { id: `${receipt.requestId}:${document.id}`, document_id: document.id, organization_id: company.id, organization_name: company.name, category: 'Accounting transfer test', action: `Test transfer ${receipt.outcome.toLowerCase()}`, user_name: actor, created_at: at, details: `${destination.label} · ${receipt.reference} · ${receipt.message} Original document status unchanged.` };
      });
      await writeTable('document_history', [...history, ...events.filter(event => !history.some(row => row.id === event.id))]);
    } catch (error) { console.error('Test receipts saved with documents; history mirror unavailable.', error); }
    return next;
  });
}

/** List edits recheck the current allocation count, state, scope and permissions
 * inside the same serialization boundary as card edits and posting commands. */
export function applyDocumentInlineEdit(documentId: string, companyId: string, field: InlineDocumentField, value: string, expectedSnapshot: string) {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { documentInlinePatch, documentInlineValue } = await import('./documentInlineEditing');
    const { canEditCompanyDocuments } = await import('./documentEditAccess');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const document = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!document || !company) throw new Error('The document has moved or is no longer available. Refresh before editing.');
    const source = document as InlineDocumentSource;
    const patch = documentInlinePatch(source, field, value, expectedSnapshot, canEditCompanyDocuments(company));
    if (field === 'accountableResponsible') {
      const { loadLinkedDirectoryUsers } = await import('./linkedSettingsData');
      const { documentResponsiblePatch } = await import('./documentResponsibleUsers');
      Object.assign(patch, documentResponsiblePatch(value, loadLinkedDirectoryUsers('Internal users')));
    }
    guardPostedDocumentMutation(document, patch);
    const actor = getCurrentUserName();
    const at = new Date().toISOString();
    const before = documentInlineValue(source, field);
    const after = documentInlineValue({ ...source, ...patch }, field);
    if (before === after && (field !== 'accountableResponsible' || document.accountable_responsible_id === patch.accountable_responsible_id)) return document as unknown as DbDocument;
    const personReference = field === 'accountableResponsible' && value ? ` [${value}]` : '';
    const event = { id: crypto.randomUUID(), document_id: documentId, organization_id: companyId, action: 'Updated', user_name: actor, created_at: at, details: `${field}: ${before || '—'} → ${after || '—'}${personReference} (document list)` };
    const next = { ...guardDocumentMutation(document, patch, actor), updated_at: at, inline_edit_history: [...(Array.isArray(document.inline_edit_history) ? document.inline_edit_history : []), event] };
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    try {
      const history = await readTable('document_history');
      await writeTable('document_history', [...history, event]);
    } catch (error) { console.error('Document saved; its inline audit is retained on the document.', error); }
    window.dispatchEvent(new CustomEvent('document-inline-edited', { detail: { documentId, companyId } }));
    return next as unknown as DbDocument;
  });
}

/** Change FH bank processing metadata only; this neither approves source
 * invoices nor posts, exports or reconciles an accounting operation. */
export function saveBankProcessingStatus(documentId: string, companyId: string, value: string, expected: string) {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const [{ bankProcessingStatusPatch, bankProcessingStatus }, { canEditCompanyBankEntries }] = await Promise.all([
      import('./bankProcessingStatus'), import('./companyBankEditing'),
    ]);
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const document = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!document || !company) throw new Error('The bank entry is no longer available in this company.');
    const source = document as unknown as DbDocument;
    const patch = bankProcessingStatusPatch(source, companyId, value, expected, canEditCompanyBankEntries(company));
    const before = bankProcessingStatus(source);
    if (before === value) return source;
    const at = new Date().toISOString(), actor = getCurrentUserName();
    const event = { id: crypto.randomUUID(), document_id: documentId, organization_id: companyId, category: 'Bank',
      action: 'Bank processing status changed', user_name: actor, created_at: at,
      details: `${document.number || documentId} · ${before} → ${value}`,
      changes: [{ field: 'bank_processing_status', before, after: value }] };
    const next = { ...document, ...patch, updated_at: at,
      detail_edit_history: [...(Array.isArray(document.detail_edit_history) ? document.detail_edit_history : []), event] };
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    try { const history = await readTable('document_history'); await writeTable('document_history', [...history, event]); }
    catch (error) { console.error('Bank status saved; authoritative history remains on the entry.', error); }
    return next as unknown as DbDocument;
  });
}

/** A manual bank transaction is saved as New, without posting or reconciliation. */
export function createBankTransaction(companyId: string, id: string, draft: import('./bankTransaction').BankTransaction): Promise<DbDocument> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const [{ canCreateCompanyBankTransaction, prepareNewBankTransaction }, { companyBankAccounts }, { loadCompanyGeneralLedgerAccountHierarchy }, { loadInvoiceCounterparties }] = await Promise.all([
      import('./bankTransactionCreation'), import('./bankTransaction'), import('../components/GeneralLedgerView'), import('./invoiceCreation'),
    ]);
    const [companies, documents] = await Promise.all([readTable('companies'), readTable('documents')]);
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!company || !canCreateCompanyBankTransaction(company)) throw new Error('You do not have permission to create this company’s bank transactions.');
    if (documents.some(row => row.id === id)) throw new Error('This bank transaction has already been saved. Refresh the list.');
    const at = new Date().toISOString(), actor = getCurrentUserName();
    const saved = prepareNewBankTransaction(company, id, draft, {
      allowed: true, accountIbans: companyBankAccounts(company).map(row => row.iban),
      counterparties: loadInvoiceCounterparties(companyId).filter(row => !(row as unknown as LocalRow).inactive && (row as unknown as LocalRow).active !== false),
      glAccounts: loadCompanyGeneralLedgerAccountHierarchy(companyId, company.general_ledger).map(row => row.code), reconciled: false,
    }, at, actor);
    const event = { id: crypto.randomUUID(), document_id: id, organization_id: companyId, category: 'Bank', action: 'Bank transaction created',
      user_name: actor, created_at: at, details: `${saved.number} · ${draft.amount} ${draft.currency}` };
    const next = { ...saved, detail_edit_history: [event] };
    await writeTable('documents', [...documents, next]);
    try { const history = await readTable('document_history'); await writeTable('document_history', [...history, event]); }
    catch (error) { console.error('Bank transaction saved; authoritative history remains on the entry.', error); }
    return next;
  });
}

/** Validate the whole statement before one atomic document-store write. */
export function importBankStatement(companyId: string, bankAccount: string, text: string, fileName: string): Promise<{ imported: number; duplicates: number }> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const [{ canCreateCompanyBankTransaction }, { prepareBankStatement }] = await Promise.all([import('./bankTransactionCreation'), import('./bankStatementImport')]);
    const [companies, documents] = await Promise.all([readTable('companies'), readTable('documents')]);
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!company || !canCreateCompanyBankTransaction(company)) throw new Error('You do not have permission to import this company’s bank transactions.');
    if (typeof fileName !== 'string' || !fileName.toLowerCase().endsWith('.csv') || fileName.length > 255) throw new Error('Choose a CSV statement file.');
    const at = new Date().toISOString(), actor = getCurrentUserName();
    const prepared = await prepareBankStatement(company, bankAccount, text, at, actor);
    const existingIds = new Set(documents.map(row => row.id));
    const added = prepared.filter(row => !existingIds.has(row.id)).map(row => ({ ...row,
      detail_edit_history: [{ id: crypto.randomUUID(), document_id: row.id, organization_id: companyId, category: 'Bank', action: 'Bank statement imported',
        user_name: actor, created_at: at, details: `${fileName} · ${row.number} · ${row.total_amount} ${row.currency}` }],
    }));
    if (added.length) {
      await writeTable('documents', [...documents, ...added]);
      try { const history = await readTable('document_history'); await writeTable('document_history', [...history, ...added.flatMap(row => row.detail_edit_history)]); }
      catch (error) { console.error('Statement imported; authoritative history remains on the entries.', error); }
    }
    return { imported: added.length, duplicates: prepared.length - added.length };
  });
}

/** Store bank details separately from the source invoice/OCR fields. */
export function saveBankTransaction(documentId: string, companyId: string, draft: import('./bankTransaction').BankTransaction, expectedSnapshot: string) {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const [{ validateBankTransaction, companyBankAccounts, bankReconciliation, bankReconciliationKey }, { canEditCompanyBankEntries }, { loadInvoiceCounterparties }, { loadCompanyGeneralLedgerAccountHierarchy }] = await Promise.all([
      import('./bankTransaction'), import('./companyBankEditing'), import('./invoiceCreation'), import('../components/GeneralLedgerView'),
    ]);
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const document = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!document || !company) throw new Error('The bank entry is no longer available in this company.');
    const reconciliation = bankReconciliation(documentId, companyId, window.localStorage.getItem(bankReconciliationKey(companyId)));
    if (reconciliation.status === 'Unavailable') throw new Error('Reconciliation data could not be checked. Refresh before saving.');
    const bank_transaction = validateBankTransaction(document as unknown as DbDocument, company, draft, expectedSnapshot, {
      allowed: canEditCompanyBankEntries(company), accountIbans: companyBankAccounts(company).map(row => row.iban),
      counterparties: loadInvoiceCounterparties(companyId).filter(row => !(row as unknown as LocalRow).inactive && (row as unknown as LocalRow).active !== false),
      glAccounts: loadCompanyGeneralLedgerAccountHierarchy(companyId, company.general_ledger).map(row => row.code), reconciled: reconciliation.matched,
    });
    const patch = { bank_transaction };
    guardPostedDocumentMutation(document, patch);
    const at = new Date().toISOString(), actor = getCurrentUserName();
    const event = { id: crypto.randomUUID(), document_id: documentId, organization_id: companyId, action: 'Bank transaction updated', user_name: actor, created_at: at,
      details: `${draft.transferNo || draft.referenceNo || documentId} · ${draft.amount} ${draft.currency} · ${draft.allocations.length} accounting allocation(s).`,
      changes: [{ field: 'bank_transaction', before: document.bank_transaction ?? null, after: bank_transaction }] };
    const next = { ...guardDocumentMutation(document, patch, actor), updated_at: at, detail_edit_history: [...(Array.isArray(document.detail_edit_history) ? document.detail_edit_history : []), event] };
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    try { const history = await readTable('document_history'); await writeTable('document_history', [...history, event]); }
    catch (error) { console.error('Bank details saved; authoritative history remains on the entry.', error); }
    return next as unknown as DbDocument;
  });
}

export function applyDocumentDetailEdit(documentId: string, companyId: string, patch: Record<string, unknown>, expectedSnapshot: string, details: string) {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { validateDocumentDetailEdit } = await import('./documentDetailEditing');
    const { canEditCompanyDocuments } = await import('./documentEditAccess');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const document = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!document || !company) throw new Error('The document has moved or is no longer available.');
    validateDocumentDetailEdit(document as InlineDocumentSource, patch, expectedSnapshot, canEditCompanyDocuments(company));
    // Legacy card fields store names. A changed name cannot keep the previous user's ID.
    if ('accountable_responsible' in patch && patch.accountable_responsible !== document.accountable_responsible) patch = { ...patch, accountable_responsible_id: '' };
    guardPostedDocumentMutation(document, patch);
    const actor = getCurrentUserName();
    const at = new Date().toISOString();
    const event = { id: crypto.randomUUID(), document_id: documentId, organization_id: companyId, action: 'Updated', user_name: actor, created_at: at, details };
    const next = { ...guardDocumentMutation(document, patch, actor), updated_at: at, detail_edit_history: [...(Array.isArray(document.detail_edit_history) ? document.detail_edit_history : []), event] };
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    try {
      const history = await readTable('document_history');
      await writeTable('document_history', [...history, event]);
    } catch (error) { console.error('Document saved; its card edit audit is retained on the document.', error); }
    return { document: next as unknown as DbDocument, history: event };
  });
}

/** One document per command, serialized with all other document mutations. The
 * reversal and its authoritative audit are persisted in the same write. */
export function applyDocumentStorno(documentId: string, companyId: string, command: TestStornoCommand) {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable. No Storno was created.');
    const { canStornoDocument, loadStornoPeriodPolicy } = await import('./documentStornoAccess');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const document = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!document || !company) throw new Error('The document is no longer in this company. Refresh before continuing.');
    const now = new Date();
    const next = createTestDocumentStorno(document as StornoDocument, command, {
      allowed: canStornoDocument(company), actor: getCurrentUserName(), now: now.toISOString(), today: accountingToday(now),
      period: loadStornoPeriodPolicy(companyId),
    });
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    const event = next.document_storno!.history[0];
    try {
      const history = await readTable('document_history');
      if (!history.some(row => row.id === event.id)) await writeTable('document_history', [...history, {
        id: event.id, document_id: documentId, organization_id: companyId, organization_name: company.name,
        category: 'Documents', action: event.action, details: event.details, user_name: event.actor, created_at: event.at,
      }]);
    } catch (error) { console.error('Storno saved; history mirror unavailable. The authoritative history remains with the reversal.', error); }
    window.dispatchEvent(new CustomEvent('document-storno-changed', { detail: { documentId, companyId } }));
    return next as unknown as DbDocument;
  });
}

/** Single-document delete, with fresh rights, approval and snapshot checks.
 * Keep an audit tombstone instead of destroying references or editing history. */
export function deleteUnconfirmedDocument(documentId: string, companyId: string, expectedSnapshot: string) {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { documentActionRights } = await import('./documentRowActionAccess');
    const { documentRowAction, documentActionSnapshot } = await import('./documentRowActions');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const document = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!document || !company) throw new Error('The document is no longer in this company.');
    const action = documentRowAction(document as StornoDocument, documentActionRights(company));
    if (action.kind !== 'delete' || action.disabledReason) throw new Error(action.disabledReason || 'Confirmed documents cannot be deleted.');
    if (documentActionSnapshot(document as StornoDocument) !== expectedSnapshot) throw new Error('The document changed. Reopen Delete before continuing.');
    const document_deletion = { at: new Date().toISOString(), actor: getCurrentUserName() };
    await writeTable('documents', documents.map(row => row.id === documentId ? { ...row, document_deletion } : row));
    try {
      const history = await readTable('document_history');
      await writeTable('document_history', [...history, { id: `${documentId}:deleted:${document_deletion.at}`,
        document_id: documentId, organization_id: companyId, organization_name: company.name, category: 'Documents',
        action: 'Unconfirmed document deleted', created_at: document_deletion.at, user_name: document_deletion.actor,
        details: `${String(document.number || document.file_case || documentId)} · ${documentId}`,
        ...(document.correction_of_document_id ? { original_document_id: document.correction_of_document_id } : {}),
      }]);
    } catch (error) { console.error('Deletion saved; its audit remains on the document tombstone.', error); }
  });
}

async function assertDocumentHistoryAccess(companyId: string) {
  const companies = await readTable('companies');
  const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
  const { canViewCompanyDocuments } = await import('./documentEditAccess');
  if (company && canViewCompanyDocuments(company)) return;
  const { canReviewDocumentIssues, canAccessIssueOrganization } = await import('./documentIssueAccess');
  if (!company || !canReviewDocumentIssues() || !canAccessIssueOrganization(company)) throw new Error('You no longer have access to this company’s document history.');
}

/** Include retained deletion tombstones in history only, never in the document register. */
export async function loadDocumentActionHistory(documentId: string, companyId: string) {
  await assertDocumentHistoryAccess(companyId);
  const { buildDocumentActionHistory } = await import('./documentActionHistory');
  const [documents, history] = await Promise.all([readTable('documents'), readTable('document_history')]);
  return buildDocumentActionHistory(documentId, companyId, documents, history);
}

export async function loadHistoryRelatedDocument(currentDocumentId: string, relatedDocumentId: string, companyId: string): Promise<DbDocument> {
  await assertDocumentHistoryAccess(companyId);
  const documents = await readTable('documents');
  const current = documents.find(row => row.id === currentDocumentId && row.company_id === companyId);
  const related = documents.find(row => row.id === relatedDocumentId && row.company_id === companyId && isAvailableDocument(row));
  if (!current || !related || !(current.id === related.id || current.correction_of_document_id === related.id || related.correction_of_document_id === current.id))
    throw new Error('The related document is unavailable or no longer belongs to this company.');
  return related as unknown as DbDocument;
}

/** Recheck approval, company scope, period and transfer state under the same
 * document write lock. The original fields and audit stay on the record. */
export function cancelDocumentApproval(documentId: string, companyId: string, command: CancelDocumentApprovalCommand): Promise<DbDocument> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { canEditCompanyDocuments } = await import('./documentEditAccess');
    const { loadStornoPeriodPolicy } = await import('./documentStornoAccess');
    const { prepareDocumentApprovalCancellation } = await import('./documentApproval');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const source = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!source || !company) throw new Error('The document is no longer available in this company.');
    const actor = getCurrentUserName(), now = new Date();
    const { event, patch } = prepareDocumentApprovalCancellation(source as StornoDocument, command, {
      allowed: canEditCompanyDocuments(company), period: loadStornoPeriodPolicy(companyId), today: accountingToday(now),
      hasCorrections: documents.some(row => isAvailableDocument(row) && row.correction_of_document_id === documentId),
      id: crypto.randomUUID(), actor, now: now.toISOString(),
    });
    const next = { ...guardDocumentMutation(source, patch, actor), updated_at: event.at,
      approval_cancellation_history: [...(Array.isArray(source.approval_cancellation_history) ? source.approval_cancellation_history : []), event] };
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    try {
      const history = await readTable('document_history');
      await writeTable('document_history', [...history, { id: event.id, document_id: documentId, organization_id: companyId,
        organization_name: company.name, category: 'Documents', action: event.action, user_name: actor, created_at: event.at,
        details: `${event.fromStatus || event.fromAccountingStatus} → Draft${event.reason ? `. ${event.reason}` : ''}` }]);
    } catch (error) { console.error('Approval cancellation saved; its audit remains on the document.', error); }
    return next as unknown as DbDocument;
  });
}

export function createCorrectiveDocument(documentId: string, companyId: string, command: DocumentCorrectionCommand): Promise<DbDocument> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { documentActionRights } = await import('./documentRowActionAccess');
    const { prepareDocumentCorrection } = await import('./documentRowActions');
    const { loadStornoPeriodPolicy } = await import('./documentStornoAccess');
    const { stornoPeriodError } = await import('./documentStorno');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const original = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!original || !company) throw new Error('The original invoice is no longer in this company.');
    if (documents.some(row => row.company_id === companyId && String(row.number).trim().toLowerCase() === command.number.trim().toLowerCase())) throw new Error('This document number already exists in the company.');
    const now = new Date(), today = accountingToday(now);
    const saved = prepareDocumentCorrection(original as StornoDocument, command, { allowed: documentActionRights(company).create, today, now: now.toISOString(), actor: getCurrentUserName(), id: crypto.randomUUID() });
    const periodError = stornoPeriodError(command.date, String(original.document_date || command.date), today, loadStornoPeriodPolicy(companyId));
    if (periodError) throw new Error(periodError);
    await writeTable('documents', [...documents, saved]);
    const event = saved.correction_history[0];
    try {
      const history = await readTable('document_history');
      await writeTable('document_history', [...history, { id: event.id, document_id: saved.id, original_document_id: documentId,
        organization_id: companyId, organization_name: company.name, category: 'Documents', action: event.action, details: event.details, user_name: event.actor, created_at: event.at }]);
    } catch (error) { console.error('Correction saved; its authoritative history remains with the corrective document.', error); }
    return saved as unknown as DbDocument;
  });
}

/** New types share Settings → General settings → Type; legacy company types remain readable. */
export function createInvoiceLineType(companyId: string, name: string): Promise<{ type: string; value: string }> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { canCreateCompanyDocument } = await import('./documentRowActionAccess');
    const { isInactiveRecord } = await import('./recordLifecycle');
    const { prepareInvoiceLineType, loadInvoiceLineTypeCatalog, INVOICE_LINE_TYPE_CATALOG_KEY } = await import('./invoiceLineTypes');
    const { assertGeneralReferenceStorageReadable } = await import('./generalReferenceCatalogs');
    const [companies, records] = await Promise.all([readTable('companies'), readTable('lookup_values')]);
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!company || isInactiveRecord(company) || !canCreateCompanyDocument(company)) throw new Error('You need Create access to this company’s invoices.');
    const prepared = prepareInvoiceLineType(companyId, name, records);
    if (prepared.create) {
      assertGeneralReferenceStorageReadable(INVOICE_LINE_TYPE_CATALOG_KEY);
      const current = loadInvoiceLineTypeCatalog();
      window.localStorage.setItem(INVOICE_LINE_TYPE_CATALOG_KEY, JSON.stringify([...current, { code: prepared.value, fullName: prepared.value, description: '', country: '', status: 'Active', parentCode: '' }]));
      window.dispatchEvent(new CustomEvent('organization-reference-updated'));
    }
    return { type: prepared.type, value: prepared.value };
  });
}

/** Save invoices into the shared Documents register, never a second invoice store. */
export function createInvoiceDocument(companyId: string, command: CreateInvoiceCommand): Promise<DbDocument> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    const { canCreateCompanyDocument, documentActionRights } = await import('./documentRowActionAccess');
    const { prepareInvoiceDocument, loadInvoiceCounterparties } = await import('./invoiceCreation');
    const { loadInvoiceWarehouse } = await import('./invoiceLineExtras');
    const { invoiceLineTypeValues } = await import('./invoiceLineTypes');
    const { isInactiveRecord } = await import('./recordLifecycle');
    const { loadLinkedDirectoryUsers } = await import('./linkedSettingsData');
    const { documentResponsiblePatch } = await import('./documentResponsibleUsers');
    const { loadOrganizationReferenceRecords } = await import('../components/OrganizationReferenceValuesView');
    const [documents, companies, lookups] = await Promise.all([readTable('documents'), readTable('companies'), readTable('lookup_values')]);
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!company || isInactiveRecord(company) || !canCreateCompanyDocument(company)) throw new Error('You no longer have Create access to this company’s documents.');
    const previous = documents.find(row => row.creation_request_id === command.requestId && row.company_id === companyId);
    if (previous && !isAvailableDocument(previous)) throw new Error('This invoice has been deleted. Start a new invoice.');
    if (previous) return previous as unknown as DbDocument;
    let parties = loadInvoiceCounterparties(companyId);
    if (command.creditNoteSource) {
      if (command.copySourceDocumentId) throw new Error('Credit note creation cannot also copy an unrelated document.');
      const { validateCreditNoteCreation } = await import('./invoiceCreditNote');
      const { invoiceFormCounterparties } = await import('./invoiceDocumentForm');
      const { loadStornoPeriodPolicy } = await import('./documentStornoAccess');
      const { accountingToday } = await import('./documentStorno');
      const source = documents.find(row => row.id === command.creditNoteSource!.documentId && row.company_id === companyId);
      validateCreditNoteCreation(source, command.creditNoteSource, command.draft, {
        companyId, allowed: documentActionRights(company).create, today: accountingToday(), period: loadStornoPeriodPolicy(companyId),
      });
      parties = invoiceFormCounterparties(source, parties);
    }
    const counterparty = parties.find(row => row.id === command.draft.counterpartyId && !isInactiveRecord(row));
    if (!counterparty) throw new Error('Select an active counterparty from this company’s Counterparties list.');
    if (documents.some(row => row.company_id === companyId && String(row.number).trim().toLowerCase() === command.draft.number.trim().toLowerCase())) throw new Error('This invoice number already exists in the company.');
    const responsibleUsers = loadLinkedDirectoryUsers('Internal users');
    const saved = prepareInvoiceDocument(command, { company, counterparty, allowed: true, actor: getCurrentUserName(), now: new Date().toISOString(),
      invoiceTypes: loadOrganizationReferenceRecords('Document type'), documents: documents.filter(isAvailableDocument) as unknown as DbDocument[],
      lineTypes: invoiceLineTypeValues(companyId, lookups),
      responsible: documentResponsiblePatch(command.draft.responsibleId, responsibleUsers), responsibleUsers, warehouse: loadInvoiceWarehouse(company) });
    await writeTable('documents', [...documents, saved]);
    try {
      const history = await readTable('document_history');
      await writeTable('document_history', [...history, { id: `${command.requestId}:created`, document_id: saved.id, organization_id: companyId,
        category: 'Documents', action: saved.creation_history[0].action, details: `${saved.number} · ${saved.type} · ${saved.document_subtype} · Status: ${saved.status}${saved.correction_of_document_id ? ` · Original document: ${saved.correction_of_document_id}` : ''}${saved.copied_from_document_id ? ` · Copied from: ${saved.copied_from_document_id}` : ''}`,
        ...(saved.correction_of_document_id ? { original_document_id: saved.correction_of_document_id } : {}), user_name: saved.created_by, created_at: saved.created_at }]);
    } catch (error) { console.error('Invoice saved; its creation history remains with the document.', error); }
    return saved as unknown as DbDocument;
  });
}

/** Manual-invoice edits update the original register record; never create a copy
 * or replace origin, posting/issue links and existing history. */
export function updateInvoiceDocument(documentId: string, companyId: string, command: CreateInvoiceCommand, expectedSnapshot: string): Promise<DbDocument> {
  return serializeDocumentWrite(async () => {
    if (!storageAvailable()) throw new Error('Persistent storage is unavailable.');
    if (command.creditNoteSource) throw new Error('A credit note must be created as a new document.');
    const { canEditCompanyDocuments } = await import('./documentEditAccess');
    const { prepareInvoiceDocument, loadInvoiceCounterparties } = await import('./invoiceCreation');
    const { validateInvoiceDocumentEdit, invoiceFormCounterparties, invoiceDocumentEditPatch } = await import('./invoiceDocumentForm');
    const { loadInvoiceWarehouse } = await import('./invoiceLineExtras');
    const { invoiceLineTypeValues } = await import('./invoiceLineTypes');
    const { isInactiveRecord } = await import('./recordLifecycle');
    const { loadLinkedDirectoryUsers } = await import('./linkedSettingsData');
    const { documentResponsiblePatch } = await import('./documentResponsibleUsers');
    const { loadOrganizationReferenceRecords } = await import('../components/OrganizationReferenceValuesView');
    const [documents, companies, lookups] = await Promise.all([readTable('documents'), readTable('companies'), readTable('lookup_values')]);
    const document = documents.find(row => row.id === documentId && row.company_id === companyId && isAvailableDocument(row));
    const company = companies.find(row => row.id === companyId) as unknown as Company | undefined;
    if (!document || !company) throw new Error('The document has moved or is no longer available.');
    validateInvoiceDocumentEdit(document, companyId, expectedSnapshot, !isInactiveRecord(company) && canEditCompanyDocuments(company));
    const parties = invoiceFormCounterparties(document, loadInvoiceCounterparties(companyId));
    const counterparty = parties.find(row => row.id === command.draft.counterpartyId);
    if (!counterparty || isInactiveRecord(counterparty)) throw new Error('Select an active counterparty from this company.');
    if (documents.some(row => row.id !== documentId && row.company_id === companyId && String(row.number).trim().toLowerCase() === command.draft.number.trim().toLowerCase())) throw new Error('This invoice number already exists in the company.');
    const responsibleUsers = loadLinkedDirectoryUsers('Internal users');
    const actor = getCurrentUserName(), at = new Date().toISOString();
    const prepared = prepareInvoiceDocument(command, { company, counterparty, allowed: true, actor, now: at,
      existingDocument: document, invoiceTypes: loadOrganizationReferenceRecords('Document type'), documents: documents.filter(isAvailableDocument) as unknown as DbDocument[],
      lineTypes: invoiceLineTypeValues(companyId, lookups), responsible: documentResponsiblePatch(command.draft.responsibleId, responsibleUsers),
      responsibleUsers, warehouse: loadInvoiceWarehouse(company) });
    const patch = invoiceDocumentEditPatch(document, prepared, command.draft);
    guardPostedDocumentMutation(document, patch);
    const changes = Object.keys(patch).filter(key => JSON.stringify(document[key]) !== JSON.stringify(patch[key]));
    if (!changes.length) return document as unknown as DbDocument;
    const event = { id: crypto.randomUUID(), document_id: documentId, organization_id: companyId, action: 'Updated',
      user_name: actor, created_at: at, details: `Manual invoice updated: ${changes.map(key => key.replaceAll('_', ' ')).join(', ')}.`,
      changes: changes.map(field => ({ field, before: document[field] ?? null, after: patch[field] ?? null })) };
    const next = { ...guardDocumentMutation(document, patch, actor), updated_at: at,
      detail_edit_history: [...(Array.isArray(document.detail_edit_history) ? document.detail_edit_history : []), event] };
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    try { await writeTable('document_history', [...await readTable('document_history'), event]); }
    catch (error) { console.error('Invoice saved; its edit history remains with the document.', error); }
    return next as unknown as DbDocument;
  });
}

/** Prototype command boundary. Production must enforce these same checks on the server. */
export function applyDocumentIssueAction(documentId: string, expectedCompanyId: string, command: DocumentIssueCommand) {
  return serializeDocumentWrite(async () => {
    const { canAccessIssueOrganization, canReviewDocumentIssues } = await import('./documentIssueAccess');
    const [documents, companies] = await Promise.all([readTable('documents'), readTable('companies')]);
    const document = documents.find(row => row.id === documentId && isAvailableDocument(row));
    if (!document || String(document.company_id ?? '') !== expectedCompanyId) throw new Error('The document organization has changed. Refresh before continuing.');
    const company = companies.find(row => row.id === document.company_id) as unknown as Company | undefined;
    if (!company || !canAccessIssueOrganization(company, true)) throw new Error('You do not have access to this organization.');
    if (command.type !== 'report' && !canReviewDocumentIssues()) throw new Error('Only MESO Worker with OCR review access can process reported issues.');
    if (command.type === 'organization') {
      if (document.accounting_posting) throw new Error('A document with a confirmed GL posting cannot be moved to another company. Retain the original and create a corrected document.');
      const target = companies.find(row => row.id === command.organizationId) as unknown as Company | undefined;
      if (!target || !canAccessIssueOrganization(target, true)) throw new Error('You do not have access to the selected organization.');
    }
    const next = transitionDocumentIssue(document, command, getCurrentUserName(), command.type === 'start' ? getCurrentUserIdentity().email : '');
    if (command.type === 'organization') {
      const target = companies.find(row => row.id === command.organizationId)!;
      const issue = (next.digitization_issues as DocumentIssue[]).find(item => item.id === command.issueId)!;
      const event = issue.events.at(-1)!;
      event.details = event.details.replace(`${document.company_id} → ${command.organizationId}`, `${company.name} → ${String(target.name)}`);
      event.changes = [{ field: 'company_id', before: document.company_id, after: command.organizationId }];
    }
    await writeTable('documents', documents.map(row => row.id === documentId ? next : row));
    // The immutable issue events are saved atomically with the document. Also expose
    // the action in the existing document history view.
    const latestIssue = (next.digitization_issues as DocumentIssue[]).find(issue => command.type === 'report'
      ? issue.id === (next.digitization_issues as DocumentIssue[]).at(-1)?.id : issue.id === command.issueId);
    const event = latestIssue?.events.at(-1);
    if (event) {
      try {
        const history = await readTable('document_history');
        if (!history.some(row => row.id === event.id)) await writeTable('document_history', [...history, { id: event.id, document_id: documentId, organization_id: document.company_id, organization_name: company.name, category: 'Document issue', action: event.action, details: event.details, user_name: event.actor, created_at: event.at }]);
      } catch (error) {
        // Do not report a failed command after the authoritative document + audit
        // have already been saved: retrying would create duplicate reports.
        console.error('Issue saved; document history mirror unavailable', error);
      }
    }
    window.dispatchEvent(new CustomEvent('document-issues-changed', { detail: { documentId } }));
    return next as unknown as DbDocument;
  });
}

const STORAGE_PREFIX = "finansu-harmonija-v4:data:";
const FILE_PREFIX = "finansu-harmonija-v4:file:";
const SHARED_DATA_REQUEST_TIMEOUT_MS = 2000;

const COMPANY_SEED: Company[] = [
  ["John Brick", "ec6940fg5698", 2019, 0],
  ["Alice Stone", "ab1234cd5678", 2021, 3],
  ["Bob Morris", "xy9876zw5432", 2020, 1],
  ["Carol White", "mn3456op7890", 2022, 0],
  ["David Lane", "qr2345st6789", 2018, 2],
  ["Emma Clarke", "gh5678ij9012", 2023, 0],
  ["Frank Hughes", "cd3456ef7890", 2017, 5],
  ["Grace Kim", "wx8901yz2345", 2022, 0],
  ["Henry Ford", "op4567qr8901", 2020, 1],
  ["Iris Taylor", "ij0123kl4567", 2021, 0],
  ["James Wilson", "ef7890gh1234", 2019, 3],
  ["Karen Scott", "st2345uv6789", 2023, 0],
  ["Leo Nolan", "uv6789wx0123", 2018, 2],
  ["Mia Turner", "yz4567ab8901", 2022, 0],
  ["Noah Reed", "bc8901de2345", 2016, 7],
].map(([name, code, since, action], index) => ({
  id: `00000000-0000-4000-8000-${String(index + 1).padStart(12, "0")}`,
  name: String(name),
  company_code: String(code),
  vat_code: String(code),
  client_since: Number(since),
  action_required: Number(action),
}));

const COUNTERPARTIES = [
  "UAB Robolabs",
  "MB Technologijos",
  "UAB Sprendimų grupė",
  "UAB IT Sprendimai",
];
const DOCUMENT_TYPES = [
  "VAT invoice",
  "Credit note",
  "Receipt",
  "Advance invoice",
];
const STATUSES = ["Pending", "Paid", "Overdue", "Draft"];

const DOCUMENT_SEED: DbDocument[] = [...COMPANY_SEED.flatMap(
  (company, companyIndex) =>
    [0, 1].map((offset) => {
      const index = companyIndex * 2 + offset;
      const day = String((index % 27) + 1).padStart(2, "0");
      const month = String((Math.floor(index / 5) % 9) + 1).padStart(2, "0");
      const net = 220 + index * 173;
      const vat = Math.round(net * 0.21 * 100) / 100;
      const series = ["TTP", "CR", "EXP", "ADV"][index % 4];
      return {
        id: `10000000-0000-4000-8000-${String(index + 1).padStart(12, "0")}`,
        company_id: company.id,
        receive_date: `${day}.${month}.2025`,
        client_counterparty: COUNTERPARTIES[index % COUNTERPARTIES.length],
        document_type: DOCUMENT_TYPES[index % DOCUMENT_TYPES.length],
        source: ["Email", "Upload", "Manual"][index % 3],
        total_amount: `${(net + vat).toFixed(2)} €`,
        due_end_date: `${String(((index + 14) % 27) + 1).padStart(2, "0")}.${month}.2025`,
        file_case: `${series}947${String(index).padStart(4, "0")}.pdf`,
        order_no: `ORD-${String(941 - index).padStart(4, "0")}`,
        number: `${series}-${String(index + 1).padStart(3, "0")}`,
        type: index % 2 ? "Expense" : "Income",
        document_date: `${day}.${month}.2025`,
        document_purpose: [
          "Services",
          "Consulting",
          "Correction",
          "Office supplies",
        ][index % 4],
        invoice_contract_date: `01.${month}.2025`,
        operation_date: `${day}.${month}.2025`,
        expense_account: index % 2 ? "5000" : "6000",
        vat_classifier: "PVM1",
        currency: "EUR",
        amount_without_vat: `${net.toFixed(2)} €`,
        vat: `${vat.toFixed(2)} €`,
        vat_percent: "21%",
        department_code: `DEP-0${(index % 3) + 1}`,
        object_project: `PROJ-${["A", "B", "C"][index % 3]}`,
        valid_form: "Standard",
        accountable_responsible: [
          "J. Pavardenis",
          "A. Varduonis",
          "K. Jonaitis",
        ][index % 3],
        cost_center: `CC-${((index % 3) + 1) * 100}`,
        series,
        status: STATUSES[index % STATUSES.length],
        created_at: new Date(
          2025,
          Number(month) - 1,
          Number(day),
          12,
          index,
        ).toISOString(),
        image_url: null,
      };
    }),
), ...createDocumentTestingExamples(COMPANY_SEED.find(company => company.name === 'Alice Stone')!.id)];

const TABLE_SEEDS: Record<string, LocalRow[]> = {
  companies: COMPANY_SEED as unknown as LocalRow[],
  documents: DOCUMENT_SEED as unknown as LocalRow[],
  lookup_values: [],
  document_history: [],
};

function storageAvailable() {
  return (
    typeof window !== "undefined" && typeof window.localStorage !== "undefined"
  );
}

async function readTable(table: string): Promise<LocalRow[]> {
  const seed = TABLE_SEEDS[table] ?? [];
  if (!storageAvailable()) return structuredClone(seed);
  const key = `${STORAGE_PREFIX}${table}`;
  const stored = window.localStorage.getItem(key);
  let localRows = structuredClone(seed);
  if (stored) {
    try {
      localRows = JSON.parse(stored) as LocalRow[];
      if (!Array.isArray(localRows)) throw new Error('Invalid stored records');
    } catch {
      if (table === 'documents') throw new Error('Document storage could not be read. Existing issue history was not overwritten.');
      if (table === 'lookup_values') throw new Error('Reference values could not be read. Existing values were not overwritten.');
      /* restore the seed below */
    }
  }

  const controller = new AbortController();
  const timeoutId = window.setTimeout(
    () => controller.abort(),
    SHARED_DATA_REQUEST_TIMEOUT_MS,
  );
  try {
    const response = await fetch(`/__meso_shared_data/${encodeURIComponent(table)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fallback: localRows }),
      cache: "no-store",
      signal: controller.signal,
    });
    if (response.ok) {
      const payload = (await response.json()) as { rows?: LocalRow[] };
      if (Array.isArray(payload.rows)) {
        if (stored) rememberLedgerTableUsage(table, localRows);
        rememberLedgerTableUsage(table, payload.rows);
        window.localStorage.setItem(key, JSON.stringify(payload.rows));
        return payload.rows;
      }
    }
  } catch {
    /* Static deployments keep the browser-local fallback. */
  } finally {
    window.clearTimeout(timeoutId);
  }

  rememberLedgerTableUsage(table, localRows);
  window.localStorage.setItem(key, JSON.stringify(localRows));
  return localRows;
}

async function writeTable(table: string, rows: LocalRow[]) {
  if (storageAvailable()) {
    const previous = window.localStorage.getItem(`${STORAGE_PREFIX}${table}`);
    rememberLedgerTableUsage(table, previous ? JSON.parse(previous) : []);
    rememberLedgerTableUsage(table, rows);
    window.localStorage.setItem(
      `${STORAGE_PREFIX}${table}`,
      JSON.stringify(rows),
    );
    const controller = new AbortController();
    const timeoutId = window.setTimeout(
      () => controller.abort(),
      SHARED_DATA_REQUEST_TIMEOUT_MS,
    );
    try {
      await fetch(`/__meso_shared_data/${encodeURIComponent(table)}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rows }),
        cache: "no-store",
        signal: controller.signal,
      });
    } catch {
      /* Static deployments keep the browser-local fallback. */
    } finally {
      window.clearTimeout(timeoutId);
    }
    window.dispatchEvent(
      new CustomEvent("finansu-harmonija:data-changed", {
        detail: { table },
      }),
    );
  }
}

function createId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

class LocalQuery {
  private operation: "select" | "insert" | "update" | "delete" | "upsert" =
    "select";
  private values: LocalRow | LocalRow[] | null = null;
  private filters: Array<
    | { kind: "eq"; key: string; value: unknown }
    | { kind: "in"; key: string; values: readonly unknown[] }
  > = [];
  private columns = "*";
  private orderBy: { key: string; ascending: boolean } | null = null;
  private conflictColumns: string[] = [];

  constructor(private table: string) {}

  select(columns = "*") {
    this.operation = "select";
    this.columns = columns;
    return this;
  }
  insert(values: LocalRow | LocalRow[]) {
    this.operation = "insert";
    this.values = values;
    return this;
  }
  update(values: LocalRow) {
    this.operation = "update";
    this.values = values;
    return this;
  }
  delete() {
    this.operation = "delete";
    return this;
  }
  upsert(values: LocalRow | LocalRow[], options?: { onConflict?: string }) {
    this.operation = "upsert";
    this.values = values;
    this.conflictColumns =
      options?.onConflict
        ?.split(",")
        .map((value) => value.trim())
        .filter(Boolean) ?? [];
    return this;
  }
  eq(key: string, value: unknown) {
    this.filters.push({ kind: "eq", key, value });
    return this;
  }
  in(key: string, values: readonly unknown[]) {
    this.filters.push({ kind: "in", key, values: [...values] });
    return this;
  }
  order(key: string, options?: { ascending?: boolean }) {
    this.orderBy = { key, ascending: options?.ascending !== false };
    return this;
  }

  private matches(row: LocalRow) {
    if (this.table === 'documents' && !isAvailableDocument(row)) return false;
    return this.filters.every((filter) =>
      filter.kind === "eq"
        ? row[filter.key] === filter.value
        : filter.values.includes(row[filter.key]),
    );
  }

  private async execute(): Promise<LocalResult> {
    try {
      let rows = await readTable(this.table);
      if (this.table === 'documents' && this.operation !== 'select' && this.values) {
        const incoming = Array.isArray(this.values) ? this.values : [this.values];
        for (const value of incoming) {
          if ('document_deletion' in value) throw new Error('Use the document Delete action. Deletion history cannot be changed.');
          if (value.id && rows.some(row => row.id === value.id && !isAvailableDocument(row))) throw new Error('This document has already been deleted.');
        }
      }
      if (this.operation === "select") {
        let selected = rows.filter((row) => this.matches(row));
        if (this.orderBy) {
          const { key, ascending } = this.orderBy;
          selected = [...selected].sort((left, right) => {
            const a = String(left[key] ?? "");
            const b = String(right[key] ?? "");
            return (
              (ascending ? 1 : -1) *
              a.localeCompare(b, undefined, { numeric: true })
            );
          });
        }
        if (this.columns !== "*") {
          const keys = this.columns
            .split(",")
            .map((value) => value.trim())
            .filter(Boolean);
          selected = selected.map((row) =>
            Object.fromEntries(keys.map((key) => [key, row[key]])),
          );
        }
        return { data: structuredClone(selected), error: null };
      }

      if (this.operation === "insert") {
        const created = (
          Array.isArray(this.values) ? this.values : [this.values]
        )
          .filter(Boolean)
          .map((value) => ({
            id: (value as LocalRow).id ?? createId(),
            created_at:
              (value as LocalRow).created_at ?? new Date().toISOString(),
            ...(value as LocalRow),
          }));
        if (this.table === 'documents' && created.some(row => 'digitization_issues' in row)) throw new Error('Report issues on a saved document.');
        if (this.table === 'documents') created.forEach(row => guardPostedDocumentMutation({}, row));
        rows = [...rows, ...created];
        await writeTable(this.table, rows);
        return { data: created, error: null };
      }

      if (this.operation === "update") {
        const previousRows = rows.filter(row => this.matches(row));
        const updated: LocalRow[] = [];
        rows = rows.map((row) => {
          if (!this.matches(row)) return row;
          if (this.table === 'documents') guardPostedDocumentMutation(row, this.values as LocalRow);
          const next = {
            ...row,
            ...(this.table === 'documents' ? guardDocumentMutation(row, this.values as LocalRow, getCurrentUserName()) : this.values as LocalRow),
            updated_at: new Date().toISOString(),
          };
          updated.push(next);
          return next;
        });
        await writeTable(this.table, rows);
        if (this.table === 'companies') {
          for (const previous of previousRows) {
            const next = updated.find(row => row.id === previous.id)!;
            const fields = Object.keys(this.values as LocalRow).filter(key => JSON.stringify(previous[key]) !== JSON.stringify(next[key]));
            for (const [category, matching] of Object.entries({ Services: fields.filter(key => key === 'service_scope'), 'Setup / integration': fields.filter(key => /sharepoint|sync|integration|portfolio|source_system/i.test(key)), Accountants: fields.filter(key => /accountant/.test(key)) })) {
              if (matching.length) await recordAdministrativeAction(String(next.id), category, 'Updated', `Changed fields: ${matching.join(', ')}.`);
            }
          }
        }
        return { data: updated, error: null };
      }

      if (this.operation === "delete") {
        const deleted = rows.filter((row) => this.matches(row));
        if (this.table === 'documents' && deleted.some(row => row.accounting_posting || row.accounting_storno || row.document_storno)) throw new Error('Confirmed postings and Storno history cannot be deleted or deactivated.');
        if (this.table === 'documents' && deleted.some(row => (row.digitization_issues as DocumentIssue[] | undefined)?.length)) throw new Error('Documents with reported issues retain their action history and cannot be deleted.');
        if (this.table === 'documents' && deleted.some(row => row.correction_of_document_id || (row.correction_history as unknown[] | undefined)?.length)) throw new Error('Corrective documents retain their links and action history and cannot be deleted.');
        const retained = removeOrDeactivateRecords(rows, new Set(deleted.map(row => String(row.id))), `${STORAGE_PREFIX}${this.table}`);
        await writeTable(
          this.table,
          retained,
        );
        return { data: deleted.map(row => retained.find(item => item.id === row.id) ?? row), error: null };
      }

      const incoming = (
        Array.isArray(this.values) ? this.values : [this.values]
      ).filter(Boolean) as LocalRow[];
      const saved: LocalRow[] = [];
      for (const value of incoming) {
        const existingIndex = rows.findIndex(
          (row) =>
            this.conflictColumns.length > 0 &&
            this.conflictColumns.every((key) => row[key] === value[key]),
        );
        if (existingIndex >= 0) {
          if (this.table === 'documents') guardPostedDocumentMutation(rows[existingIndex], value);
          rows[existingIndex] = this.table === 'documents' ? guardDocumentMutation(rows[existingIndex], value, getCurrentUserName()) : { ...rows[existingIndex], ...value };
          saved.push(rows[existingIndex]);
        } else {
          if (this.table === 'documents') guardPostedDocumentMutation({}, value);
          if (this.table === 'documents' && 'digitization_issues' in value) throw new Error('Report issues on a saved document.');
          const created = {
            id: value.id ?? createId(),
            created_at: value.created_at ?? new Date().toISOString(),
            ...value,
          };
          rows.push(created);
          saved.push(created);
        }
      }
      await writeTable(this.table, rows);
      return { data: saved, error: null };
    } catch (error) {
      return {
        data: null,
        error: {
          message: error instanceof Error ? error.message : "Local data error",
        },
      };
    }
  }

  then(
    onFulfilled?: (result: LocalResult) => unknown,
    onRejected?: (reason: unknown) => unknown,
  ) {
    return (this.table === 'documents' && this.operation !== 'select'
      ? serializeDocumentWrite(() => this.execute()) : this.execute()).then(onFulfilled, onRejected);
  }
}

const uploadedFiles = new Map<string, string>();

async function fileToDataUrl(file: File): Promise<string> {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () =>
      reject(reader.error ?? new Error("File could not be read"));
    reader.readAsDataURL(file);
  });
}

function localBucket(bucket: string) {
  return {
    async upload(path: string, file: File) {
      try {
        const dataUrl = await fileToDataUrl(file);
        const key = `${bucket}:${path}`;
        uploadedFiles.set(key, dataUrl);
        try {
          window.localStorage.setItem(`${FILE_PREFIX}${key}`, dataUrl);
        } catch {
          /* large files remain available for this session */
        }
        return { data: { path }, error: null };
      } catch (error) {
        return {
          data: null,
          error: {
            message: error instanceof Error ? error.message : "Upload failed",
          },
        };
      }
    },
    getPublicUrl(path: string) {
      const key = `${bucket}:${path}`;
      const publicUrl =
        uploadedFiles.get(key) ??
        (storageAvailable()
          ? window.localStorage.getItem(`${FILE_PREFIX}${key}`)
          : null) ??
        "";
      return { data: { publicUrl } };
    },
  };
}

/**
 * Local Supabase-compatible adapter. Data is stored in this browser profile on
 * this computer, so the prototype keeps working without an external service.
 */
export const supabase = {
  from(table: string) {
    return new LocalQuery(table);
  },
  storage: {
    from(bucket: string) {
      return localBucket(bucket);
    },
  },
  auth: {
    async signOut() {
      return { error: null };
    },
  },
};
