import { invoiceLineAmounts, isCreditInvoiceKind, type InvoiceDraft, type InvoiceLineDraft } from './invoiceCreation';
import { warehouseLedger, type WarehouseStore, type StockBalance } from './warehouse';
import { loadWarehouse, warehousePermissions, warehouseStorageKey } from './warehouseStore';
import type { Company } from './supabase';

/** Do not manufacture stock data for companies that have never saved Warehouse data. */
export function loadInvoiceWarehouse(company: Company): WarehouseStore | null {
  try {
    if (!warehousePermissions(company).view || localStorage.getItem(warehouseStorageKey(company.id)) === null) return null;
    return loadWarehouse(company.id);
  } catch { return null; }
}

export function invoiceAccountingCurrency(line: InvoiceLineDraft, draft: InvoiceDraft, baseCurrency: string) {
  const amounts = invoiceLineAmounts(line);
  const text = draft.exchangeRate.trim().replace(',', '.');
  const rate = draft.currency === baseCurrency ? 1 : /^\d+(?:\.\d+)?$/.test(text) ? Number(text) : NaN;
  if (!amounts.valid || !Number.isFinite(rate) || rate <= 0) return null;
  const amount = Math.round(amounts.net * rate) * (isCreditInvoiceKind(draft.kind) ? -1 : 1);
  const unitPrice = Number(line.price.replace(',', '.')) * rate;
  return Number.isSafeInteger(amount) && Number.isFinite(unitPrice) ? { amount, unitPrice } : null;
}

export type InvoiceWarehouseSnapshot = {
  locations: WarehouseStore['locations']; items: WarehouseStore['items']; balances: StockBalance[]; ledgerAvailable: boolean; costsAvailable: boolean;
};
export function invoiceWarehouseSnapshot(store: WarehouseStore | null, companyId: string, date: string, baseCurrency: string): InvoiceWarehouseSnapshot {
  const empty = { locations: [], items: [], balances: [], ledgerAvailable: false, costsAvailable: false };
  if (!store || store.companyId !== companyId) return empty;
  const locations = store.locations.filter(row => row.companyId === companyId && !row.inactive);
  const items = store.items.filter(row => row.companyId === companyId && !row.inactive && row.type === 'Product');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date)) || new Date(date).toISOString().slice(0, 10) !== date) return { ...empty, locations, items };
  try {
    const balances = warehouseLedger(store, date).balances.filter(balance => locations.some(row => row.id === balance.warehouseId) && items.some(row => row.id === balance.itemId));
    return { locations, items, balances, ledgerAvailable: true,
      // The current Warehouse ledger is explicitly denominated in EUR.
      costsAvailable: baseCurrency === 'EUR' && balances.some(row => row.quantity > 0 && Number.isFinite(row.unitCost)) };
  } catch { return { ...empty, locations, items }; }
}

export function invoiceLineUsesWarehouse(line: InvoiceLineDraft, snapshot: InvoiceWarehouseSnapshot) {
  return line.type === 'Product' && snapshot.locations.length > 0 && Boolean(line.itemCode?.trim())
    && snapshot.items.filter(item => item.code === line.itemCode?.trim()).length === 1;
}

export function invoiceWarehouseColumnAvailable(key: string, snapshot: InvoiceWarehouseSnapshot, lines: readonly InvoiceLineDraft[] = []) {
  if (['warehouseId', 'stockQuantity', 'costPrice', 'costAmount', 'profit'].includes(key) && !lines.some(line => invoiceLineUsesWarehouse(line, snapshot))) return false;
  if (key === 'warehouseId') return snapshot.locations.length > 0;
  if (key === 'stockQuantity') return snapshot.ledgerAvailable && snapshot.balances.length > 0;
  if (['costPrice', 'costAmount', 'profit'].includes(key)) return snapshot.costsAvailable;
  return true;
}

/** Reference values only: saving an invoice does not post a warehouse movement. */
export function invoiceLineStock(line: InvoiceLineDraft, draft: InvoiceDraft, snapshot: InvoiceWarehouseSnapshot, baseCurrency: string) {
  if (!invoiceLineUsesWarehouse(line, snapshot) || !snapshot.ledgerAvailable || !snapshot.locations.some(row => row.id === line.warehouseId)) return null;
  const matches = snapshot.items.filter(item => line.itemCode?.trim() && item.code === line.itemCode.trim());
  if (matches.length !== 1) return null;
  const balance = snapshot.balances.find(row => row.itemId === matches[0].id && row.warehouseId === line.warehouseId);
  const stockQuantity = balance?.quantity ?? 0;
  if (!snapshot.costsAvailable || !balance || balance.quantity <= 0 || !Number.isFinite(balance.unitCost)) return { stockQuantity, costPrice: null, costAmount: null, profit: null };
  const amounts = invoiceLineAmounts(line), converted = invoiceAccountingCurrency(line, draft, baseCurrency);
  const sign = isCreditInvoiceKind(draft.kind) ? -1 : 1;
  const computedCost = amounts.valid ? sign * Math.round(balance.unitCost * Number(line.quantity.replace(',', '.')) * 100) : NaN;
  const costAmount = Number.isSafeInteger(computedCost) ? computedCost : null;
  return { stockQuantity, costPrice: balance.unitCost, costAmount,
    profit: draft.purpose === 'Sale' && converted && costAmount !== null ? converted.amount - costAmount : null };
}
