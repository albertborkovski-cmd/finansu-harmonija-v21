import { invoiceCreditCounterparty, newInvoiceDraft, type InvoiceDraft, type InvoiceLineDraft } from './invoiceCreation';
import { invoiceFormFromDocument, type InvoiceRecord } from './invoiceDocumentForm';
import type { Company } from './supabase';

type CopyContext = {
  companyId: string; baseCurrency: string; today: string;
  counterparties: Company[];
  invoiceOptions: readonly { value: string; label: string }[];
  users: readonly { value: string; label: string }[];
  newId?: () => string;
};
const text = (value: unknown) => String(value ?? '').trim();
const normalize = (value: unknown) => text(value).toLocaleLowerCase().replace(/[\s-]+/g, '_');
function invoiceDate(value: unknown, fallback: string) {
  const raw = text(value), legacy = /^(\d{2})[./](\d{2})[./](\d{4})$/.exec(raw);
  const date = legacy ? `${legacy[3]}-${legacy[2]}-${legacy[1]}` : raw.slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(date) && Number.isFinite(Date.parse(date))
    && new Date(date).toISOString().slice(0, 10) === date ? date : fallback;
}

/** Copy content into Create invoice, never the source record's lifecycle.
 * Source PDFs, approval/transfer history, issues and accounting links are not
 * inherited. Every editable line receives a new identity. */
export function invoiceCopyFromDocument(source: InvoiceRecord, context: CopyContext): InvoiceDraft {
  if (source.company_id !== context.companyId || source.document_deletion) throw new Error('The source document is no longer available in this company.');
  const normalizeRows = (value: unknown) => Array.isArray(value) ? value.map(row => row && typeof row === 'object'
    ? { ...row, qty: text(row.qty) || '1' } : row) : value;
  const { draft } = invoiceFormFromDocument({ ...source, line_items: normalizeRows(source.line_items),
    summary_line_items: normalizeRows(source.summary_line_items) }, context.counterparties, context.baseCurrency);
  const copy = structuredClone(draft);
  const defaults = newInvoiceDraft(context.today, context.baseCurrency);
  const aliases: Record<string, string> = { credit_note: 'CREDIT_INVOICE', debit_note: 'DEBIT_INVOICE',
    advance_invoice: 'ADVANCE_INVOICE', vat_advance_invoice: 'VAT_ADVANCE_INVOICE', vat_invoice: 'VAT_INVOICE' };
  const subtype = text(source.document_subtype);
  const type = normalize(subtype || source.document_type);
  const candidate = aliases[type] || (subtype ? subtype : type === 'credit_invoice' ? 'CREDIT_INVOICE' : 'INVOICE');
  const kind = context.invoiceOptions.find(option => normalize(option.value) === normalize(candidate)
    || subtype && normalize(option.label) === normalize(subtype))?.value || '';
  const userId = (id: unknown, name: unknown) => {
    if (text(id)) return context.users.find(user => user.value === text(id))?.value || '';
    const matches = context.users.filter(user => text(name) && normalize(user.label) === normalize(name));
    return matches.length === 1 ? matches[0].value : '';
  };
  const responsibleId = userId(source.accountable_responsible_id, source.accountable_responsible);
  const newId = context.newId || (() => crypto.randomUUID());
  const lines = (values: InvoiceLineDraft[], originals: unknown): InvoiceLineDraft[] => values.map((line, index) => {
    const { allocationId: _allocationId, ...content } = line;
    const original = Array.isArray(originals) ? originals[index] as InvoiceRecord | undefined : undefined;
    return { ...content, id: newId(),
      responsibleId: original && ('accountable_responsible_id' in original || 'accountable_responsible' in original)
        ? userId(original.accountable_responsible_id, original.accountable_responsible) : responsibleId };
  });
  const quantity = Array.isArray(source.line_items) && source.line_items.length ? source.line_items : source.summary_line_items;
  const explicitPurpose = normalize(source.document_purpose);
  return { ...copy, status: defaults.status, number: '', kind,
    purpose: ['purchase', 'sale'].includes(explicitPurpose) ? explicitPurpose === 'sale' ? 'Sale' : 'Purchase'
      : /sale|income/.test(normalize(source.type) || normalize(source.document_type)) ? 'Sale' : 'Purchase',
    counterpartyId: invoiceCreditCounterparty(source as never, context.counterparties)?.id || '',
    creditSourceDocumentId: '', responsibleId,
    customerManagerId: userId(source.invoice_customer_manager_id, source.invoice_customer_manager),
    invoiceDate: invoiceDate(source.document_date || source.invoice_contract_date, context.today),
    operationDate: invoiceDate(source.operation_date, context.today),
    dueDate: invoiceDate(source.due_end_date, context.today),
    lines: lines(copy.lines, quantity),
    ...(copy.allocations ? { allocations: lines(copy.allocations, source.summary_line_items) } : {}),
  };
}
