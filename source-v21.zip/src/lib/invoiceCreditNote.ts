import { invoiceCopyFromDocument } from './invoiceCopy';
import { isCreditInvoiceKind, type InvoiceDraft } from './invoiceCreation';
import { documentActionSnapshot, documentRowAction } from './documentRowActions';
import { stornoPeriodError, testStornoOriginalDate, type StornoDocument, type StornoPeriodPolicy } from './documentStorno';
import type { InvoiceRecord } from './invoiceDocumentForm';

export type CreditNoteSourceCommand = { documentId: string; expectedSnapshot: string; reason: string };

export function creditNoteSourceError(source: InvoiceRecord | undefined, companyId: string, allowed: boolean): string {
  if (!source || source.company_id !== companyId || source.document_deletion) return 'The original invoice is no longer available in this company.';
  const action = documentRowAction(source as StornoDocument, { create: allowed, delete: false, storno: false });
  if (action.kind !== 'correction' || action.label !== 'Create credit note') return 'Only a confirmed invoice eligible for crediting can be used.';
  return action.disabledReason;
}

/** Initialize the existing invoice form; opening or cancelling creates no record. */
export function invoiceCreditNoteFromDocument(source: InvoiceRecord, context: Parameters<typeof invoiceCopyFromDocument>[1] & { allowed: boolean }): InvoiceDraft {
  const error = creditNoteSourceError(source, context.companyId, context.allowed);
  if (error) throw new Error(error);
  const kind = context.invoiceOptions.find(option => isCreditInvoiceKind(option.value))?.value;
  if (!kind) throw new Error('Enable a Credit invoice type in OCR → Administration → Document type → Invoices.');
  return { ...invoiceCopyFromDocument(source, context), kind, status: 'Draft', number: '', series: '',
    invoiceDate: context.today, operationDate: context.today, dueDate: context.today, paymentTerms: '0', notes: '',
    creditSourceDocumentId: String(source.id) };
}

/** Recheck the original and correction permissions immediately before saving. */
export function validateCreditNoteCreation(source: InvoiceRecord | undefined, command: CreditNoteSourceCommand, draft: InvoiceDraft,
  context: { companyId: string; allowed: boolean; today: string; period: StornoPeriodPolicy }) {
  const error = creditNoteSourceError(source, context.companyId, context.allowed);
  if (error || !source) throw new Error(error);
  if (source.id !== command.documentId || command.expectedSnapshot !== documentActionSnapshot(source as StornoDocument))
    throw new Error('The original invoice changed. Reopen Create credit note before continuing.');
  if (!isCreditInvoiceKind(draft.kind) || draft.creditSourceDocumentId !== source.id)
    throw new Error('The credit note must retain its original invoice link and credit type.');
  if (!command.reason.trim() || command.reason.length > 2000) throw new Error('Enter a credit note reason (up to 2,000 characters).');
  for (const date of [draft.invoiceDate, draft.operationDate]) {
    const periodError = stornoPeriodError(date, testStornoOriginalDate(source as StornoDocument), context.today, context.period);
    if (periodError) throw new Error(periodError.replace(/reversal date/g, 'credit note date').replace(/original posting date/g, 'original invoice date'));
  }
}
