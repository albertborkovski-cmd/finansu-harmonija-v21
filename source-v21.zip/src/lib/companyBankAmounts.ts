type BankAmountSource = {
  id: string;
  total_amount?: string;
  amount_without_vat?: string;
  type?: string;
  document_purpose?: string;
  bank_transaction?: { amount: string };
};

/** Cash-flow directions for the two original synthetic Bank examples only.
 * A saved bank transaction always takes precedence; invoice values stay intact. */
const EXAMPLE_DIRECTIONS: Record<string, 1 | -1> = {
  '10000000-0000-4000-8000-000000000004': 1,
  '10000000-0000-4000-8000-000000000003': -1,
};

export function parseBankAmount(value: string | undefined): number | null {
  if (!value?.trim()) return null;
  let text = value.trim().replace(/\u2212/g, '-').replace(/[\s\u00a0\u202f]/g, '')
    .replace(/[A-Z]{3}|[€$£¥]/g, '');
  if (/^\(.*\)$/.test(text)) text = `-${text.slice(1, -1)}`;
  if (text.includes('.') && text.includes(',')) {
    text = text.lastIndexOf(',') > text.lastIndexOf('.')
      ? text.replace(/\./g, '').replace(',', '.') : text.replace(/,/g, '');
  } else text = text.replace(',', '.');
  if (!/^[+-]?\d+(?:\.\d+)?$/.test(text)) return null;
  const amount = Number(text);
  return Number.isFinite(amount) ? amount : null;
}

export function companyBankAmount(source: BankAmountSource): number | null {
  // Bank imports and edited bank records already carry the cash-flow sign.
  if (source.bank_transaction) return parseBankAmount(source.bank_transaction.amount);
  const amount = parseBankAmount(source.total_amount || source.amount_without_vat);
  if (amount === null) return null;
  const exampleDirection = EXAMPLE_DIRECTIONS[source.id];
  if (exampleDirection && amount >= 0) return amount * exampleDirection;
  // Legacy document-backed rows are a projection only. A negative purchase is
  // a supplier refund; a negative sale is a refund paid to the customer.
  const purpose = source.document_purpose?.trim().toLowerCase();
  const type = source.type?.trim().toLowerCase();
  const direction = ['purchase', 'sale'].includes(purpose || '') ? purpose : type;
  return ['purchase', 'expense', 'outgoing'].includes(direction || '') ? -amount : amount;
}

export function formatBankAmount(amount: number | null): string {
  if (amount === null || !Number.isFinite(amount)) return '—';
  const absolute = Math.abs(amount).toFixed(2);
  if (absolute === '0.00') return absolute;
  return `${amount < 0 ? '−' : '+'}${absolute}`;
}
