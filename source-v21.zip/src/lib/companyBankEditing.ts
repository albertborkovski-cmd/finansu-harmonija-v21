import { supabase, type Company, type DbDocument } from './supabase';
import { canEditMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canEditCompanyDocuments } from './documentEditAccess';

export function canEditCompanyBankEntries(company: Company) {
  try {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    return Boolean(session && canEditMenu(session, 'bank') && canEditCompanyDocuments(company));
  } catch { return false; }
}

/** Bank rows currently reference document records. Opening their bank-details
 * editor never copies or updates source invoice/OCR data. */
export async function loadCompanyBankDocument(documentId: string, companyId: string): Promise<DbDocument> {
  const [documents, companies] = await Promise.all([
    supabase.from('documents').select('*').eq('id', documentId).eq('company_id', companyId),
    supabase.from('companies').select('*').eq('id', companyId),
  ]);
  const document = documents.data?.[0] as unknown as DbDocument | undefined;
  const company = companies.data?.[0] as unknown as Company | undefined;
  if (documents.error || companies.error || !document || !company || document.company_id !== companyId || document.document_deletion)
    throw new Error('The bank entry is no longer available in this company. Refresh the list.');
  if (!canEditCompanyBankEntries(company)) throw new Error('You do not have permission to edit this company’s bank entries.');
  return document;
}
